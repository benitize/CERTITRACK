const express = require('express');
const router = express.Router();
const path = require('path');
const Certificate = require('../models/Certificate');
const User = require('../models/User');
const { authenticate, authorizeRole } = require('../middleware/auth');
const upload = require('../middleware/upload');
const nlpService = require('../services/nlpService');
const path = require('path');

// @route   POST /api/certificates/upload
// @desc    Upload a certificate (Student only)
// @access  Private
router.post('/upload', authenticate, authorizeRole('student'), upload.single('certificate'), async (req, res) => {
  try {
    const { title, description } = req.body;

    if (!title || !description) {
      return res.status(400).json({ message: 'Please provide title and description' });
    }

    if (!req.file) {
      return res.status(400).json({ message: 'Please upload a certificate file' });
    }

    // Extract keywords using NLP
    const combinedText = `${title} ${description}`;
    const keywords = nlpService.extractKeywords(combinedText);

    // Create certificate
    const certificate = new Certificate({
      student: req.user._id,
      title,
      description,
      fileUrl: `/uploads/certificates/${req.file.filename}`,
      fileName: req.file.originalname,
      fileType: req.file.mimetype,
      keywords
    });

    await certificate.save();

    // Populate student info
    await certificate.populate('student', 'name email rollNumber');

    // Notify all teachers
    const teachers = await User.find({ role: 'teacher' });
    
    for (const teacher of teachers) {
      teacher.notifications.push({
        studentId: req.user._id,
        studentName: req.user.name,
        certificateId: certificate._id,
        certificateTitle: title,
        read: false
      });
      await teacher.save();
    }

    // Emit socket event for real-time notification
    const io = req.app.get('io');
    if (io) {
      io.emit('new-certificate', {
        studentName: req.user.name,
        certificateTitle: title,
        certificateId: certificate._id
      });
    }

    res.status(201).json({
      message: 'Certificate uploaded successfully',
      certificate
    });
  } catch (error) {
    console.error('Upload error:', error);
    res.status(500).json({ message: 'Server error during upload' });
  }
});

// @route   GET /api/certificates/student
// @desc    Get all certificates for logged-in student
// @access  Private (Student)
router.get('/student', authenticate, authorizeRole('student'), async (req, res) => {
  try {
    const certificates = await Certificate.find({ student: req.user._id })
      .sort({ uploadDate: -1 });

    res.json({ certificates });
  } catch (error) {
    console.error('Get certificates error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// @route   GET /api/certificates/students
// @desc    Get all students with their certificate counts (Teacher only)
// @access  Private (Teacher)
router.get('/students', authenticate, authorizeRole('teacher'), async (req, res) => {
  try {
    // Aggregate to get students and their certificate counts
    const studentsWithCounts = await Certificate.aggregate([
      {
        $group: {
          _id: '$student',
          certificateCount: { $sum: 1 },
          lastUpload: { $max: '$uploadDate' }
        }
      },
      {
        $lookup: {
          from: 'users',
          localField: '_id',
          foreignField: '_id',
          as: 'studentInfo'
        }
      },
      {
        $unwind: '$studentInfo'
      },
      {
        $match: {
          'studentInfo.role': 'student'
        }
      },
      {
        $project: {
          _id: 1,
          name: '$studentInfo.name',
          email: '$studentInfo.email',
          rollNumber: '$studentInfo.rollNumber',
          department: '$studentInfo.department',
          certificateCount: 1,
          lastUpload: 1
        }
      },
      {
        $sort: { lastUpload: -1 }
      }
    ]);

    res.json({ 
      students: studentsWithCounts,
      totalStudents: studentsWithCounts.length
    });
  } catch (error) {
    console.error('Get students error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// @route   GET /api/certificates/student/:studentId
// @desc    Get all certificates for a specific student (Teacher only)
// @access  Private (Teacher)
router.get('/student/:studentId', authenticate, authorizeRole('teacher'), async (req, res) => {
  try {
    const { search } = req.query;
    
    // Get all certificates for the specific student
    let certificates = await Certificate.find({ student: req.params.studentId })
      .populate('student', 'name email rollNumber department')
      .sort({ uploadDate: -1 });

    // Apply NLP search if query provided
    if (search && search.trim() !== '') {
      certificates = nlpService.searchCertificates(search, certificates);
    }

    res.json({ 
      certificates,
      count: certificates.length,
      searchQuery: search || null
    });
  } catch (error) {
    console.error('Get student certificates error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// @route   GET /api/certificates/all
// @desc    Get all certificates with NLP search (Teacher only)
// @access  Private (Teacher)
router.get('/all', authenticate, authorizeRole('teacher'), async (req, res) => {
  try {
    const { search } = req.query;

    // Get all certificates with student info
    let certificates = await Certificate.find()
      .populate('student', 'name email rollNumber department')
      .sort({ uploadDate: -1 });

    // Apply NLP search if query provided
    if (search && search.trim() !== '') {
      certificates = nlpService.searchCertificates(search, certificates);
    }

    res.json({ 
      certificates,
      count: certificates.length,
      searchQuery: search || null
    });
  } catch (error) {
    console.error('Get all certificates error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// @route   GET /api/certificates/search-suggestions
// @desc    Get search term suggestions
// @access  Private (Teacher)
router.get('/search-suggestions', authenticate, authorizeRole('teacher'), async (req, res) => {
  try {
    const { query } = req.query;

    if (!query || query.trim() === '') {
      return res.json({ suggestions: [] });
    }

    const suggestions = nlpService.suggestSearchTerms(query);
    
    res.json({ suggestions });
  } catch (error) {
    console.error('Search suggestions error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// @route   GET /api/certificates/:id/download
// @desc    Download a certificate file
// @access  Private
router.get('/:id/download', authenticate, async (req, res) => {
  try {
    const certificate = await Certificate.findById(req.params.id)
      .populate('student', 'name email rollNumber department');

    if (!certificate) {
      return res.status(404).json({ message: 'Certificate not found' });
    }

    // Check authorization
    if (req.user.role === 'student' && certificate.student._id.toString() !== req.user._id.toString()) {
      return res.status(403).json({ message: 'Not authorized to download this certificate' });
    }

    const filePath = path.join(__dirname, '..', certificate.fileUrl);
    
    // Check if file exists
    const fs = require('fs');
    if (!fs.existsSync(filePath)) {
      return res.status(404).json({ message: 'File not found' });
    }

    // Set headers for download
    res.download(filePath, certificate.fileName, (err) => {
      if (err) {
        console.error('Download error:', err);
        res.status(500).json({ message: 'Error downloading file' });
      }
    });
  } catch (error) {
    console.error('Download certificate error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// @route   GET /api/certificates/:id
// @desc    Get single certificate
// @access  Private
router.get('/:id', authenticate, async (req, res) => {
  try {
    const certificate = await Certificate.findById(req.params.id)
      .populate('student', 'name email rollNumber department');

    if (!certificate) {
      return res.status(404).json({ message: 'Certificate not found' });
    }

    // Check authorization
    if (req.user.role === 'student' && certificate.student._id.toString() !== req.user._id.toString()) {
      return res.status(403).json({ message: 'Not authorized to view this certificate' });
    }

    res.json({ certificate });
  } catch (error) {
    console.error('Get certificate error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// @route   DELETE /api/certificates/:id
// @desc    Delete a certificate
// @access  Private (Student - own certificates only)
router.delete('/:id', authenticate, authorizeRole('student'), async (req, res) => {
  try {
    const certificate = await Certificate.findById(req.params.id);

    if (!certificate) {
      return res.status(404).json({ message: 'Certificate not found' });
    }

    // Check if the certificate belongs to the student
    if (certificate.student.toString() !== req.user._id.toString()) {
      return res.status(403).json({ message: 'Not authorized to delete this certificate' });
    }

    await certificate.deleteOne();

    res.json({ message: 'Certificate deleted successfully' });
  } catch (error) {
    console.error('Delete certificate error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;
