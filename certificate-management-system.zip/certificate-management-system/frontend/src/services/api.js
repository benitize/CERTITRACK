import axios from 'axios';

const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000/api';

// Create axios instance
const api = axios.create({
  baseURL: API_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Add token to requests
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Auth API
export const authAPI = {
  register: (userData) => api.post('/auth/register', userData),
  login: (credentials) => api.post('/auth/login', credentials),
  getCurrentUser: () => api.get('/auth/me'),
};

// Certificate API
export const certificateAPI = {
  upload: (formData) => {
    return api.post('/certificates/upload', formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    });
  },
  getStudentCertificates: () => api.get('/certificates/student'),
  getAllCertificates: (searchQuery) => {
    const params = searchQuery ? { search: searchQuery } : {};
    return api.get('/certificates/all', { params });
  },
  getCertificate: (id) => api.get(`/certificates/${id}`),
  deleteCertificate: (id) => api.delete(`/certificates/${id}`),
  getSearchSuggestions: (query) => api.get('/certificates/search-suggestions', { params: { query } }),
};

// Notification API
export const notificationAPI = {
  getNotifications: () => api.get('/notifications'),
  markAsRead: (id) => api.put(`/notifications/${id}/read`),
  markAllAsRead: () => api.put('/notifications/mark-all-read'),
  deleteNotification: (id) => api.delete(`/notifications/${id}`),
};

export default api;
