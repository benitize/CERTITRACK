import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { certificateAPI, notificationAPI } from '../services/api';
import socketService from '../services/socket';
import { 
  FiSearch, FiLogOut, FiUser, FiBell, FiFile, 
  FiX, FiCheck, FiFilter 
} from 'react-icons/fi';
import './TeacherDashboard.css';

const TeacherDashboard = () => {
  const { user, logout } = useAuth();
  const [certificates, setCertificates] = useState([]);
  const [filteredCertificates, setFilteredCertificates] = useState([]);
  const [notifications, setNotifications] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [loading, setLoading] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const [unreadCount, setUnreadCount] = useState(0);

  useEffect(() => {
    fetchCertificates();
    fetchNotifications();
    
    // Connect to socket for real-time notifications
    socketService.connect();
    socketService.on('new-certificate', handleNewCertificateNotification);

    return () => {
      socketService.off('new-certificate', handleNewCertificateNotification);
    };
  }, []);

  const handleNewCertificateNotification = (data) => {
    // Play notification sound or show toast
    console.log('New certificate uploaded:', data);
    fetchNotifications();
  };

  const fetchCertificates = async (search = '') => {
    setLoading(true);
    try {
      const response = await certificateAPI.getAllCertificates(search);
      setCertificates(response.data.certificates);
      setFilteredCertificates(response.data.certificates);
    } catch (error) {
      console.error('Error fetching certificates:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchNotifications = async () => {
    try {
      const response = await notificationAPI.getNotifications();
      setNotifications(response.data.notifications);
      setUnreadCount(response.data.unreadCount);
    } catch (error) {
      console.error('Error fetching notifications:', error);
    }
  };

  const handleSearch = async (e) => {
    e.preventDefault();
    await fetchCertificates(searchQuery);
  };

  const handleSearchChange = (e) => {
    setSearchQuery(e.target.value);
  };

  const clearSearch = () => {
    setSearchQuery('');
    fetchCertificates('');
  };

  const markNotificationAsRead = async (notificationId) => {
    try {
      await notificationAPI.markAsRead(notificationId);
      fetchNotifications();
    } catch (error) {
      console.error('Error marking notification as read:', error);
    }
  };

  const markAllAsRead = async () => {
    try {
      await notificationAPI.markAllAsRead();
      fetchNotifications();
    } catch (error) {
      console.error('Error marking all as read:', error);
    }
  };

  return (
    <div className="dashboard-container">
      <header className="dashboard-header">
        <div className="container">
          <div className="header-content">
            <div className="logo">
              <span className="logo-icon">🎓</span>
              <h2>CertifyHub</h2>
            </div>
            <div className="header-actions">
              <div className="notification-btn-wrapper">
                <button
                  onClick={() => setShowNotifications(!showNotifications)}
                  className="notification-btn"
                >
                  <FiBell size={20} />
                  {unreadCount > 0 && (
                    <span className="notification-badge">{unreadCount}</span>
                  )}
                </button>
                
                {showNotifications && (
                  <div className="notifications-dropdown">
                    <div className="notifications-header">
                      <h3>Notifications</h3>
                      {unreadCount > 0 && (
                        <button onClick={markAllAsRead} className="mark-all-btn">
                          <FiCheck /> Mark all read
                        </button>
                      )}
                    </div>
                    <div className="notifications-list">
                      {notifications.length === 0 ? (
                        <p className="no-notifications">No notifications</p>
                      ) : (
                        notifications.map((notif) => (
                          <div
                            key={notif._id}
                            className={`notification-item ${notif.read ? 'read' : 'unread'}`}
                            onClick={() => !notif.read && markNotificationAsRead(notif._id)}
                          >
                            <div className="notif-icon">
                              <FiFile />
                            </div>
                            <div className="notif-content">
                              <p className="notif-title">
                                <strong>{notif.studentName}</strong> uploaded a certificate
                              </p>
                              <p className="notif-cert">{notif.certificateTitle}</p>
                              <p className="notif-time">
                                {new Date(notif.createdAt).toLocaleString()}
                              </p>
                            </div>
                            {!notif.read && <div className="unread-indicator"></div>}
                          </div>
                        ))
                      )}
                    </div>
                  </div>
                )}
              </div>
              
              <div className="user-info">
                <FiUser />
                <span>{user?.name}</span>
                <span className="role-badge teacher">Teacher</span>
              </div>
              <button onClick={logout} className="btn btn-secondary">
                <FiLogOut /> Logout
              </button>
            </div>
          </div>
        </div>
      </header>

      <main className="dashboard-main">
        <div className="container">
          <div className="dashboard-intro">
            <h1>Teacher Dashboard</h1>
            <p>View and search student certificates using natural language</p>
          </div>

          <div className="search-section card">
            <div className="search-header">
              <FiSearch size={24} />
              <h2>NLP-Powered Search</h2>
            </div>
            <form onSubmit={handleSearch} className="search-form">
              <div className="search-input-wrapper">
                <FiSearch className="search-icon" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={handleSearchChange}
                  placeholder='Try searching: "Java Internship", "Machine Learning", "Web Development Course"...'
                  className="search-input"
                />
                {searchQuery && (
                  <button
                    type="button"
                    onClick={clearSearch}
                    className="clear-search-btn"
                  >
                    <FiX />
                  </button>
                )}
              </div>
              <button type="submit" className="btn btn-primary search-btn">
                <FiFilter /> Search
              </button>
            </form>
            <p className="search-hint">
              💡 Use natural language like "Java Internship" or "Python programming certificate"
            </p>
          </div>

          <div className="certificates-section">
            <div className="section-header">
              <h2>
                {searchQuery 
                  ? `Search Results (${filteredCertificates.length})` 
                  : `All Certificates (${certificates.length})`}
              </h2>
              {searchQuery && (
                <span className="search-query-display">
                  Searching for: <strong>{searchQuery}</strong>
                </span>
              )}
            </div>

            {loading ? (
              <div className="loading-state">
                <span className="loading"></span>
                <p>Loading certificates...</p>
              </div>
            ) : filteredCertificates.length === 0 ? (
              <div className="empty-state card">
                <FiFile size={48} />
                <h3>{searchQuery ? 'No matching certificates found' : 'No certificates yet'}</h3>
                <p>
                  {searchQuery 
                    ? 'Try a different search query or clear the search'
                    : 'Students haven\'t uploaded any certificates yet'}
                </p>
                {searchQuery && (
                  <button onClick={clearSearch} className="btn btn-secondary">
                    Clear Search
                  </button>
                )}
              </div>
            ) : (
              <div className="certificates-grid">
                {filteredCertificates.map((cert) => (
                  <div key={cert._id} className="certificate-card card">
                    <div className="cert-header">
                      <div className="cert-icon">
                        <FiFile size={32} />
                      </div>
                      <div className="student-badge">
                        <FiUser size={14} />
                        <span>{cert.student?.name}</span>
                      </div>
                    </div>
                    
                    <div className="cert-content">
                      <h3>{cert.title}</h3>
                      <p className="cert-description">{cert.description}</p>
                      
                      <div className="cert-student-info">
                        <p><strong>Student:</strong> {cert.student?.name}</p>
                        {cert.student?.rollNumber && (
                          <p><strong>Roll No:</strong> {cert.student.rollNumber}</p>
                        )}
                        {cert.student?.department && (
                          <p><strong>Department:</strong> {cert.student.department}</p>
                        )}
                      </div>

                      <div className="cert-meta">
                        <span>Uploaded: {new Date(cert.uploadDate).toLocaleDateString()}</span>
                      </div>

                      {cert.keywords && cert.keywords.length > 0 && (
                        <div className="cert-keywords">
                          {cert.keywords.slice(0, 6).map((keyword, idx) => (
                            <span key={idx} className="keyword-tag">{keyword}</span>
                          ))}
                        </div>
                      )}
                    </div>
                    
                    <div className="cert-actions">
                      <a
                        href={`http://localhost:5000${cert.fileUrl}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="btn btn-primary btn-sm"
                      >
                        View Certificate
                      </a>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  );
};

export default TeacherDashboard;
