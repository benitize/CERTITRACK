/**
 * verificationService.js  — v3
 *
 * REAL automatic verification pipeline:
 *  1. Extract text from PDF or image (Tesseract with preprocessing)
 *  2. Scan QR code from image at multiple scales (jimp + jsQR)
 *  3. If QR URL found → HTTP GET to the issuer page → verified if reachable (2xx/3xx)
 *  4. If no QR → parse cert ID from OCR text → build issuer verify URL → HTTP GET
 *  5. Mark as VERIFIED if issuer page is reachable
 *
 * All OCR packages are lazy-loaded (server starts even without npm install).
 */

const axios = require('axios');
const fs    = require('fs');
const path  = require('path');

/* ── Issuer verification URL builders ── */
const ISSUER_VERIFY_URLS = {
  Coursera:  id => `https://www.coursera.org/verify/${id}`,
  Udemy:     id => `https://www.udemy.com/certificate/${id}/`,
  LinkedIn:  id => `https://www.linkedin.com/learning/certificates/${id}`,
  Google:    id => `https://skillshop.credential.net/verify/${id}`,
  Microsoft: id => `https://learn.microsoft.com/api/credentials/share/${id}`,
  AWS:       id => `https://aws.amazon.com/verification/${id}`,
};

/* ── Certificate ID regex per issuer ── */
const CERT_ID_PATTERNS = {
  Coursera:  /\b([A-Z0-9]{8,20})\b/,
  Udemy:     /UC-([A-Za-z0-9\-]{20,42})/,
  LinkedIn:  /\b([A-Za-z0-9]{28,52})\b/,
  Google:    /\b([A-Za-z0-9\-]{14,42})\b/,
  Microsoft: /\b([A-Za-z0-9\-]{36})\b/,
  AWS:       /\b([A-Z0-9]{12,22})\b/,
};

/* ════════════════════════════════════════════════
   TEXT EXTRACTION
   ════════════════════════════════════════════════ */
async function extractTextFromPDF(filePath) {
  try {
    const pdfParse = require('pdf-parse');
    const data     = await pdfParse(fs.readFileSync(filePath));
    return data.text || '';
  } catch(e) { console.warn('[OCR] pdf-parse:', e.message); return ''; }
}

/**
 * Extract text from an image with Tesseract.
 * We try two passes: original + greyscale-enhanced (via Jimp).
 * Whichever gives more text wins.
 */
async function extractTextFromImage(filePath) {
  const Tesseract = (() => { try { return require('tesseract.js'); } catch { return null; } })();
  if (!Tesseract) { console.warn('[OCR] tesseract.js not installed'); return ''; }

  const opts = { logger: () => {} };
  let bestText = '';

  // Pass 1 — raw file
  try {
    const { data: { text } } = await Tesseract.recognize(filePath, 'eng', opts);
    if ((text||'').length > bestText.length) bestText = text;
  } catch(e) { console.warn('[OCR] Tesseract pass 1:', e.message); }

  // Pass 2 — greyscale + contrast via Jimp then OCR
  try {
    const Jimp       = require('jimp');
    const tmpPath    = filePath + '_ocr_tmp.png';
    const img        = await Jimp.read(filePath);
    img.greyscale().contrast(0.3).normalize().write(tmpPath);
    const { data: { text } } = await Tesseract.recognize(tmpPath, 'eng', opts);
    if ((text||'').length > bestText.length) bestText = text;
    if (fs.existsSync(tmpPath)) fs.unlinkSync(tmpPath);
  } catch(e) { console.warn('[OCR] Tesseract pass 2:', e.message); }

  return bestText;
}

/* ════════════════════════════════════════════════
   QR CODE SCANNING  — multi-scale for small QRs
   ════════════════════════════════════════════════ */
async function extractQRFromImage(filePath) {
  const Jimp = (() => { try { return require('jimp'); }  catch { return null; } })();
  const jsQR = (() => { try { return require('jsqr');  } catch { return null; } })();
  if (!Jimp || !jsQR) { console.warn('[QR] jimp or jsqr not installed'); return null; }

  try {
    const original = await Jimp.read(filePath);

    // Try multiple scales — large originals hide small QR codes
    const scales = [1, 0.5, 2, 0.75, 1.5];
    for (const scale of scales) {
      const img  = original.clone();
      if (scale !== 1) img.scale(scale);
      // Also try greyscale pass for better contrast
      for (const grey of [false, true]) {
        const proc = img.clone();
        if (grey) proc.greyscale().contrast(0.2);
        const { data, width, height } = proc.bitmap;
        const code = jsQR(new Uint8ClampedArray(data), width, height, { inversionAttempts: 'dontInvert' });
        if (code && code.data) {
          console.log(`[QR] Found at scale=${scale} grey=${grey}: ${code.data.slice(0,60)}`);
          return code.data;
        }
      }
    }
    return null;
  } catch(e) { console.warn('[QR] scan error:', e.message); return null; }
}

/* ════════════════════════════════════════════════
   REAL HTTP VERIFICATION
   Opens the verification URL — marks verified if page is reachable (2xx/3xx).
   Uses GET (not HEAD) so redirects are followed and real content is checked.
   ════════════════════════════════════════════════ */
async function reachVerificationURL(url) {
  try {
    // Follow redirects, accept any status < 500 as "page exists"
    const r = await axios.get(url, {
      timeout:        10000,
      maxRedirects:   10,
      validateStatus: s => s < 500,
      headers: {
        'User-Agent': 'Mozilla/5.0 (compatible; CertifyHub-Verifier/1.0)',
        'Accept':     'text/html,application/xhtml+xml,*/*',
      }
    });
    const ok = r.status >= 200 && r.status < 400;
    // Extra check: if the page body contains "not found" / "invalid" text → unverified
    const body = (typeof r.data === 'string') ? r.data.toLowerCase() : '';
    const pageInvalid = body.length > 50 && (
      body.includes('certificate not found') ||
      body.includes('invalid certificate') ||
      body.includes('page not found') ||
      body.includes('404')
    );
    return {
      reached:    ok && !pageInvalid,
      statusCode: r.status,
      url,
      reason: (ok && !pageInvalid)
        ? `Verification page reached successfully (HTTP ${r.status})`
        : `Certificate page not found at issuer (HTTP ${r.status})`
    };
  } catch(e) {
    return { reached: false, statusCode: 0, url, reason: `Could not reach ${url}: ${e.message}` };
  }
}

/* ════════════════════════════════════════════════
   CERT ID PARSER  — smarter context-aware version
   ════════════════════════════════════════════════ */
function parseCertificateId(ocrText, issuer) {
  if (!ocrText) return null;

  // 1. Try explicit label patterns first (most reliable)
  const labelPatterns = [
    /(?:certificate\s*(?:id|no|number|code)[:\s#]+)([A-Za-z0-9\-_]{6,50})/i,
    /(?:credential\s*(?:id|no|number)[:\s#]+)([A-Za-z0-9\-_]{6,50})/i,
    /(?:verification\s*(?:id|code)[:\s#]+)([A-Za-z0-9\-_]{6,50})/i,
    /(?:cert(?:ification)?\s*(?:id|code)[:\s#]+)([A-Za-z0-9\-_]{6,50})/i,
  ];
  for (const pat of labelPatterns) {
    const m = ocrText.match(pat);
    if (m && m[1]) return m[1].trim();
  }

  // 2. Udemy UC- prefix — very reliable
  const udemyM = ocrText.match(/UC-([A-Za-z0-9\-]{20,42})/);
  if (udemyM) return `UC-${udemyM[1]}`;

  // 3. Issuer-specific pattern
  if (issuer && CERT_ID_PATTERNS[issuer]) {
    const m = ocrText.match(CERT_ID_PATTERNS[issuer]);
    if (m) return (m[1] || m[0]).trim();
  }

  // 4. Generic: long alphanumeric sequence that looks like a cert ID
  const generic = ocrText.match(/\b([A-Z0-9][A-Z0-9\-]{10,38}[A-Z0-9])\b/);
  if (generic) return generic[1];

  return null;
}

/* ════════════════════════════════════════════════
   MAIN AUTO-VERIFY PIPELINE
   ════════════════════════════════════════════════ */
async function autoVerifyCertificate({ filePath, fileType, issuer, certificateId: manualId, qrCodeData: manualQR }) {
  const result = {
    status:          'unverified',
    method:          'none',
    extractedId:     null,
    extractedQR:     null,
    verificationUrl: null,
    message:         'No verification data found',
    verifiedAt:      undefined,
  };

  const mime = (fileType || '').toLowerCase();
  const ext  = mime.includes('/') ? mime.split('/')[1] : path.extname(filePath).replace('.','').toLowerCase();
  const isImage = ['jpg','jpeg','png','gif','webp'].includes(ext);
  const isPDF   = ext === 'pdf' || mime.includes('pdf');

  /* ── Step 1: extract text ── */
  let ocrText = '';
  if (isPDF)    ocrText = await extractTextFromPDF(filePath);
  else if (isImage) ocrText = await extractTextFromImage(filePath);
  console.log(`[Verify] OCR extracted ${ocrText.length} chars`);

  /* ── Step 2: scan QR code ── */
  let qrData = manualQR || null;
  if (!qrData && isImage) {
    qrData = await extractQRFromImage(filePath);
    if (qrData) {
      result.extractedQR = qrData;
      result.method = 'qr_scan';
      console.log('[Verify] QR found:', qrData.slice(0, 80));
    }
  }
  // Also try to find a URL in OCR text if no QR image found
  if (!qrData && ocrText) {
    const urlMatch = ocrText.match(/https?:\/\/[^\s"'<>]{10,200}/);
    if (urlMatch) {
      const candidate = urlMatch[0].replace(/[.,;:)]+$/, '');
      // Only use if it looks like a cert verify URL
      if (/verif|certificate|credential|cert|learn|skill/i.test(candidate)) {
        qrData = candidate;
        result.extractedQR = candidate;
        result.method = 'url_from_ocr';
        console.log('[Verify] URL found in OCR text:', candidate.slice(0, 80));
      }
    }
  }

  /* ── Step 3: parse cert ID ── */
  let certId = manualId || null;
  if (!certId && ocrText) {
    certId = parseCertificateId(ocrText, issuer);
    if (certId) {
      result.extractedId = certId;
      result.method = result.method || 'ocr_id';
      console.log('[Verify] Cert ID found:', certId);
    }
  }

  /* ── Step 4: REAL verification — open the URL ── */
  // Priority: QR URL > cert-ID-based URL
  let verifyURL = null;

  if (qrData && (qrData.startsWith('http://') || qrData.startsWith('https://'))) {
    verifyURL = qrData;
  } else if (certId && issuer && ISSUER_VERIFY_URLS[issuer]) {
    verifyURL = ISSUER_VERIFY_URLS[issuer](certId);
  } else if (certId) {
    // Try to auto-detect issuer from cert ID format + OCR text
    const detectedIssuer = detectIssuerFromText(ocrText || '', certId);
    if (detectedIssuer && ISSUER_VERIFY_URLS[detectedIssuer]) {
      verifyURL = ISSUER_VERIFY_URLS[detectedIssuer](certId);
      result.method = result.method || 'auto_detect';
    }
  }

  if (verifyURL) {
    result.verificationUrl = verifyURL;
    console.log('[Verify] Checking URL:', verifyURL);
    const check = await reachVerificationURL(verifyURL);
    result.status  = check.reached ? 'verified' : 'unverified';
    result.message = check.reason;
    if (check.reached) {
      result.verifiedAt = new Date();
      console.log('[Verify] ✅ VERIFIED via', verifyURL);
    } else {
      console.log('[Verify] ❌ NOT verified:', check.reason);
    }
  } else {
    result.message = ocrText.length > 20
      ? 'Text extracted but could not find a Certificate ID, QR code, or verification URL'
      : 'Could not extract any data from the certificate file';
  }

  return result;
}

/* ────────────────────────────────────────────────
   Auto-detect issuer from OCR text + cert ID shape
   ──────────────────────────────────────────────── */
function detectIssuerFromText(text, certId) {
  const lo = text.toLowerCase();
  if (lo.includes('coursera'))  return 'Coursera';
  if (lo.includes('udemy') || (certId||'').startsWith('UC-')) return 'Udemy';
  if (lo.includes('linkedin'))  return 'LinkedIn';
  if (lo.includes('google'))    return 'Google';
  if (lo.includes('microsoft')) return 'Microsoft';
  if (lo.includes('amazon') || lo.includes('aws')) return 'AWS';
  return null;
}

/* ── Manual verification by teacher/admin ── */
function manualVerification(verifiedBy) {
  return {
    status: 'verified', method: 'manual',
    message: 'Manually verified by teacher or admin',
    verifiedAt: new Date(), verifiedBy,
  };
}

function getSupportedIssuers() {
  return ['Coursera','Udemy','LinkedIn','Google','Microsoft','AWS','Other']
    .map(n => ({ name: n, code: n.toLowerCase() }));
}

module.exports = {
  autoVerifyCertificate, manualVerification, getSupportedIssuers,
  extractTextFromImage, extractTextFromPDF, extractQRFromImage,
  parseCertificateId, reachVerificationURL,
};
