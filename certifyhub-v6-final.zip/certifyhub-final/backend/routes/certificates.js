/**
 * certificates.js  — v3
 * Includes:
 *   POST /ocr-extract  — smart OCR scan + QR decode, returns structured fields
 *   POST /upload       — save cert + real auto-verification
 *   All other CRUD routes
 */
const express     = require('express');
const router      = express.Router();
const path        = require('path');
const fs          = require('fs');
const Certificate = require('../models/Certificate');
const User        = require('../models/User');
const { auth, studentOnly, teacherOrAdmin, adminOnly } = require('../middleware/auth');
const upload      = require('../middleware/upload');
const { extractKeywords, categorizeCertificate, determineSkillLevel, searchCertificates } = require('../services/nlpService');
const { autoVerifyCertificate, manualVerification } = require('../services/verificationService');

/* ══════════════════════════════════════════════════════════
   OCR EXTRACT   POST /api/certificates/ocr-extract
   Scans uploaded file → returns extracted fields WITHOUT saving a cert.
   ══════════════════════════════════════════════════════════ */
router.post('/ocr-extract', auth, studentOnly, upload.single('certificate'), async (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'No file uploaded' });

  const filePath = req.file.path;
  const mime     = req.file.mimetype || '';
  const ext      = path.extname(req.file.filename).substring(1).toLowerCase();
  const isImage  = ['jpg','jpeg','png'].includes(ext);
  const isPDF    = ext === 'pdf';

  try {
    let ocrText    = '';
    let qrCodeData = '';

    /* ── PDF text extraction ── */
    if (isPDF) {
      try {
        const pdfParse = require('pdf-parse');
        ocrText = (await pdfParse(fs.readFileSync(filePath))).text || '';
      } catch(e) { console.warn('[OCR] pdf-parse:', e.message); }
    }

    /* ── Image: enhanced OCR + QR scan ── */
    if (isImage) {
      const Tesseract = (() => { try { return require('tesseract.js'); } catch { return null; } })();
      const Jimp      = (() => { try { return require('jimp');         } catch { return null; } })();
      const jsQR      = (() => { try { return require('jsqr');         } catch { return null; } })();

      /* OCR pass 1 – raw image */
      if (Tesseract) {
        try {
          const { data: { text } } = await Tesseract.recognize(filePath, 'eng', { logger: () => {} });
          ocrText = text || '';
        } catch(e) { console.warn('[OCR] Tesseract pass1:', e.message); }

        /* OCR pass 2 – greyscale + contrast enhanced */
        if (Jimp) {
          try {
            const tmpPath = filePath + '_grey.png';
            const img     = await Jimp.read(filePath);
            img.greyscale().contrast(0.35).normalize().write(tmpPath);
            const { data: { text } } = await Tesseract.recognize(tmpPath, 'eng', { logger: () => {} });
            if ((text||'').length > ocrText.length) ocrText = text;
            if (fs.existsSync(tmpPath)) fs.unlinkSync(tmpPath);
          } catch(e) { console.warn('[OCR] Tesseract pass2:', e.message); }
        }
      }

      /* QR scan – multiple scales */
      if (Jimp && jsQR) {
        try {
          const original = await Jimp.read(filePath);
          outer: for (const scale of [1, 0.5, 2, 0.75, 1.5]) {
            for (const grey of [false, true]) {
              const proc = original.clone();
              if (scale !== 1) proc.scale(scale);
              if (grey) proc.greyscale().contrast(0.25);
              const { data, width, height } = proc.bitmap;
              const code = jsQR(new Uint8ClampedArray(data), width, height, { inversionAttempts: 'dontInvert' });
              if (code && code.data) { qrCodeData = code.data; break outer; }
            }
          }
        } catch(e) { console.warn('[OCR] QR scan:', e.message); }
      }
    }

    /* Cleanup */
    if (fs.existsSync(filePath)) fs.unlinkSync(filePath);

    const extracted = parseOCRFields(ocrText, qrCodeData);
    return res.json({ ...extracted, ocrTextLength: ocrText.length });

  } catch(err) {
    if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
    console.error('[OCR] extract error:', err);
    return res.status(500).json({ error: 'OCR processing failed' });
  }
});

/* ─── Smart OCR field parser ─── */
function parseOCRFields(rawText, qrCodeData) {
  const result = {
    title: '', description: '', issueDate: '',
    certificateId: '', issuer: '', qrCodeData: qrCodeData || ''
  };

  if (!rawText || rawText.trim().length < 5) return result;

  /* Normalise whitespace but preserve line structure */
  const text  = rawText.replace(/\r\n/g, '\n').replace(/[ \t]{2,}/g, ' ');
  const lines = text.split('\n').map(l => l.trim()).filter(Boolean);

  /* ── 1. Issuer detection (before title so title skip-rules work) ── */
  const ISSUER_MAP = {
    Coursera:  ['coursera'],
    Udemy:     ['udemy'],
    LinkedIn:  ['linkedin', 'linked in'],
    Google:    ['google'],
    Microsoft: ['microsoft', 'microsoft learn'],
    AWS:       ['amazon web services', 'aws certified', 'aws'],
    NPTEL:     ['nptel', 'national programme on technology'],
    Swayam:    ['swayam'],
    'IIT':     ['indian institute of technology', 'iit '],
    'NASSCOM': ['nasscom'],
    Simplilearn:['simplilearn'],
    Coursera:  ['coursera'],
    edX:       ['edx', 'ed-x'],
    Infosys:   ['infosys springboard', 'infosys'],
    TCS:       ['tcs ion', 'tata consultancy'],
    Oracle:    ['oracle'],
    Cisco:     ['cisco'],
  };
  const lo = text.toLowerCase();
  for (const [name, kws] of Object.entries(ISSUER_MAP)) {
    if (kws.some(k => lo.includes(k))) { result.issuer = name; break; }
  }

  /* ── 2. Title extraction ──
     Skip boilerplate lines. Pick the first meaningful line that looks like a course/cert name. */
  const BOILERPLATE = [
    'certificate','congratulations','this is to certify','this certifies that',
    'awarded to','presented to','has successfully','verify at','has completed',
    'in recognition','with distinction','this course','upon completion',
    'issued on','issue date','valid through','credential id','certificate id',
    result.issuer.toLowerCase(),
  ].filter(Boolean);

  const isBP = (line) => {
    const ll = line.toLowerCase();
    return BOILERPLATE.some(bp => ll.startsWith(bp) || ll === bp)
      || line.length < 5
      || /^\d[\d\s\-\/]+$/.test(line)       // only numbers/dates
      || /^[A-Z0-9\-]{6,}$/.test(line);     // looks like cert ID only
  };

  for (const line of lines) {
    if (!isBP(line) && line.length >= 6 && line.length <= 150) {
      result.title = line;
      break;
    }
  }
  if (!result.title && lines.length > 0) result.title = lines[0];

  /* ── 3. Date extraction — many formats ── */
  const MO = { jan:1,feb:2,mar:3,apr:4,may:5,jun:6,jul:7,aug:8,sep:9,oct:10,nov:11,dec:12 };
  const DATE_PATS = [
    /* YYYY-MM-DD or YYYY/MM/DD */
    { re: /(\d{4})[-\/](\d{1,2})[-\/](\d{1,2})/,
      fn: m => `${m[1]}-${m[2].padStart(2,'0')}-${m[3].padStart(2,'0')}` },
    /* DD-MM-YYYY or DD/MM/YYYY */
    { re: /(\d{1,2})[-\/](\d{1,2})[-\/](\d{4})/,
      fn: m => `${m[3]}-${m[2].padStart(2,'0')}-${m[1].padStart(2,'0')}` },
    /* DD Month YYYY */
    { re: /(\d{1,2})\s+(Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|Jun(?:e)?|Jul(?:y)?|Aug(?:ust)?|Sep(?:tember)?|Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?)[,.\s]+(\d{4})/i,
      fn: m => `${m[3]}-${String(MO[m[2].slice(0,3).toLowerCase()]).padStart(2,'0')}-${m[1].padStart(2,'0')}` },
    /* Month DD, YYYY */
    { re: /(Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|Jun(?:e)?|Jul(?:y)?|Aug(?:ust)?|Sep(?:tember)?|Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?)\s+(\d{1,2})[,.\s]+(\d{4})/i,
      fn: m => `${m[3]}-${String(MO[m[1].slice(0,3).toLowerCase()]).padStart(2,'0')}-${m[2].padStart(2,'0')}` },
    /* Month YYYY (no day — use 01) */
    { re: /(Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|Jun(?:e)?|Jul(?:y)?|Aug(?:ust)?|Sep(?:tember)?|Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?)[,.\s]+(\d{4})/i,
      fn: m => `${m[2]}-${String(MO[m[1].slice(0,3).toLowerCase()]).padStart(2,'0')}-01` },
  ];
  for (const { re, fn } of DATE_PATS) {
    const m = text.match(re);
    if (m) {
      try {
        const iso = fn(m);
        const d   = new Date(iso);
        if (!isNaN(d) && d.getFullYear() >= 2010 && d <= new Date()) {
          result.issueDate = iso;
          break;
        }
      } catch(_) { /* skip */ }
    }
  }

  /* ── 4. Certificate ID extraction — context-aware ── */
  // Explicit label (most reliable)
  const ID_LABEL = text.match(
    /(?:certificate\s*(?:id|no|number|code)|credential\s*(?:id|no)|cert(?:ification)?\s*(?:id|code)|verification\s*(?:id|code))[:\s#]+([A-Za-z0-9\-_]{6,60})/i
  );
  if (ID_LABEL && ID_LABEL[1]) {
    result.certificateId = ID_LABEL[1].trim();
  } else {
    // Udemy UC- is unambiguous
    const udemy = text.match(/UC-([A-Za-z0-9\-]{20,42})/);
    if (udemy) {
      result.certificateId = `UC-${udemy[1]}`;
    } else if (result.issuer && CERT_ID_PATTERNS_LOCAL[result.issuer]) {
      const m = text.match(CERT_ID_PATTERNS_LOCAL[result.issuer]);
      if (m) result.certificateId = (m[1] || m[0]).trim();
    }
  }

  /* ── 5. Description — 2-3 meaningful content lines ── */
  const descLines = lines.filter(l =>
    l.length >= 25 &&
    /[a-zA-Z]{5,}/.test(l) &&
    l !== result.title &&
    !isBP(l) &&
    !/^\d/.test(l)
  ).slice(0, 3);
  result.description = descLines.join(' ').slice(0, 350) || '';

  return result;
}

/* Local copy used only inside parseOCRFields */
const CERT_ID_PATTERNS_LOCAL = {
  Coursera:  /\b([A-Z0-9]{8,22})\b/,
  LinkedIn:  /\b([A-Za-z0-9]{28,52})\b/,
  Google:    /\b([A-Za-z0-9\-]{14,42})\b/,
  Microsoft: /\b([A-Za-z0-9\-]{36})\b/,
  AWS:       /\b([A-Z0-9]{12,22})\b/,
};

/* ══════════════════════════════════════════════════════════
   UPLOAD   POST /api/certificates/upload
   ══════════════════════════════════════════════════════════ */
router.post('/upload', auth, studentOnly, upload.single('certificate'), async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ error: 'Please upload a certificate file' });

    const {
      title, description, issueDate,
      certificateId, issuer, qrCodeData,
      certificateType,
      courseStartDate, courseEndDate,
      internshipStartDate, internshipEndDate
    } = req.body;

    if (!title || !description || !issueDate) {
      fs.unlinkSync(req.file.path);
      return res.status(400).json({ error: 'Please provide title, description, and issue date' });
    }

    const keywords   = extractKeywords(`${title} ${description}`);
    const category   = categorizeCertificate(title, description);
    const skillLevel = determineSkillLevel(title, description);

    /* Real auto-verification */
    let autoV = { status: 'unverified', method: 'none', message: 'No verification attempted' };
    try {
      autoV = await autoVerifyCertificate({
        filePath:      req.file.path,
        fileType:      req.file.mimetype,
        issuer:        issuer      || '',
        certificateId: certificateId || '',
        qrCodeData:    qrCodeData  || '',
      });
    } catch(e) { console.error('[Verify] Non-fatal error:', e.message); }

    const certificate = new Certificate({
      student:      req.userId,
      title, description,
      issueDate:    new Date(issueDate),
      certificateType: certificateType || 'course',
      courseStartDate:      courseStartDate      ? new Date(courseStartDate)      : undefined,
      courseEndDate:        courseEndDate        ? new Date(courseEndDate)        : undefined,
      internshipStartDate:  internshipStartDate  ? new Date(internshipStartDate)  : undefined,
      internshipEndDate:    internshipEndDate    ? new Date(internshipEndDate)    : undefined,
      fileName:  req.file.filename,
      filePath:  req.file.path,
      fileType:  req.file.mimetype,
      certificateId: autoV.extractedId  || certificateId  || '',
      issuer:        issuer || '',
      qrCodeData:    autoV.extractedQR  || qrCodeData     || '',
      verificationStatus: autoV.status,
      verificationMethod: autoV.method,
      verifiedAt:    autoV.verifiedAt   || undefined,
      ocrExtracted:  !!(autoV.extractedId || autoV.extractedQR),
      category, keywords, skillLevel,
    });

    await certificate.save();
    await certificate.populate('student', 'name rollNumber department');

    /* Dept-filtered teacher notifications */
    const notify = req.app.get('sendNotificationToTeachers');
    if (notify) notify(certificate).catch(e => console.error('[Notify]', e.message));

    return res.status(201).json({
      message: 'Certificate uploaded successfully',
      certificate,
      autoVerification: {
        status:          autoV.status,
        method:          autoV.method,
        message:         autoV.message,
        extractedId:     autoV.extractedId     || null,
        extractedQR:     autoV.extractedQR     || null,
        verificationUrl: autoV.verificationUrl || null,
      }
    });
  } catch(error) {
    console.error('[Upload] error:', error);
    if (req.file && fs.existsSync(req.file.path)) fs.unlinkSync(req.file.path);
    return res.status(500).json({ error: error.message || 'Server error during upload' });
  }
});

/* ══════ GET my-certificates ══════ */
router.get('/my-certificates', auth, studentOnly, async (req, res) => {
  try {
    const certs = await Certificate.find({ student: req.userId }).sort({ issueDate: -1 }).select('-filePath');
    res.json({ certificates: certs, count: certs.length });
  } catch { res.status(500).json({ error: 'Server error' }); }
});

/* ══════ GET all (teacher/admin) ══════ */
router.get('/all', auth, teacherOrAdmin, async (req, res) => {
  try {
    const { year, month, verificationStatus, studentId } = req.query;
    let query = {};

    if (studentId) {
      query.student = studentId;
    } else if (req.userRole === 'teacher') {
      const dept = req.user.department || req.user.subject;
      if (dept) {
        const ds = await User.find({ role:'student', isApproved:true, department:{ $regex:new RegExp(`^${dept.trim()}$`,'i') } }).select('_id');
        query.student = { $in: ds.map(d => d._id) };
      }
    }

    if (year && year !== 'all') {
      const mn = (month && month !== 'all') ? parseInt(month) : null;
      query.issueDate = mn
        ? { $gte: new Date(parseInt(year), mn-1, 1), $lte: new Date(parseInt(year), mn, 0, 23, 59, 59) }
        : { $gte: new Date(`${year}-01-01`), $lte: new Date(`${year}-12-31`) };
    } else if (month && month !== 'all') {
      query.$expr = { $eq: [{ $month: '$issueDate' }, parseInt(month)] };
    }
    if (verificationStatus && verificationStatus !== 'all') query.verificationStatus = verificationStatus;

    const certs = await Certificate.find(query).populate('student','name rollNumber department').sort({ issueDate:-1 }).select('-filePath');
    res.json({ certificates: certs, count: certs.length });
  } catch(e) { console.error(e); res.status(500).json({ error: 'Server error' }); }
});

/* ══════ GET search ══════ */
router.get('/search', auth, teacherOrAdmin, async (req, res) => {
  try {
    const { query, year, verificationStatus } = req.query;
    let dbQ = {};
    if (req.userRole === 'teacher') {
      const dept = req.user.department || req.user.subject;
      if (dept) {
        const ds = await User.find({ role:'student', isApproved:true, department:{ $regex:new RegExp(`^${dept.trim()}$`,'i') } }).select('_id');
        dbQ.student = { $in: ds.map(d => d._id) };
      }
    }
    if (year && year !== 'all') dbQ.issueDate = { $gte:new Date(`${year}-01-01`), $lte:new Date(`${year}-12-31`) };
    if (verificationStatus && verificationStatus !== 'all') dbQ.verificationStatus = verificationStatus;

    let results = await Certificate.find(dbQ).populate('student','name rollNumber department').sort({ issueDate:-1 });
    if (query && query.trim()) results = searchCertificates(results, query);
    res.json({ certificates: results.map(c => { const { filePath, ...r } = c._doc||c; return r; }), count: results.length });
  } catch { res.status(500).json({ error: 'Server error' }); }
});

/* ══════ GET download/:id ══════ */
router.get('/download/:id', auth, async (req, res) => {
  try {
    const c = await Certificate.findById(req.params.id);
    if (!c) return res.status(404).json({ error: 'Not found' });
    if (req.userRole === 'student' && c.student.toString() !== req.userId.toString()) return res.status(403).json({ error: 'Access denied' });
    if (!fs.existsSync(c.filePath)) return res.status(404).json({ error: 'File not found' });
    res.download(c.filePath, c.fileName);
  } catch { res.status(500).json({ error: 'Server error' }); }
});

/* ══════ GET view/:id ══════ */
router.get('/view/:id', auth, async (req, res) => {
  try {
    const c = await Certificate.findById(req.params.id);
    if (!c) return res.status(404).json({ error: 'Not found' });
    if (req.userRole === 'student' && c.student.toString() !== req.userId.toString()) return res.status(403).json({ error: 'Access denied' });
    if (!fs.existsSync(c.filePath)) return res.status(404).json({ error: 'File not found' });
    res.setHeader('Content-Type', c.fileType || 'application/pdf');
    res.setHeader('Content-Disposition', `inline; filename="${c.fileName}"`);
    fs.createReadStream(c.filePath).pipe(res);
  } catch { res.status(500).json({ error: 'Server error' }); }
});

/* ══════ GET view-token/:id (for iframe) ══════ */
router.get('/view-token/:id', async (req, res) => {
  try {
    const jwt   = require('jsonwebtoken');
    const token = req.query.token;
    if (!token) return res.status(401).json({ error: 'No token' });
    try { jwt.verify(token, process.env.JWT_SECRET); } catch { return res.status(401).json({ error: 'Invalid token' }); }
    const c = await Certificate.findById(req.params.id);
    if (!c || !fs.existsSync(c.filePath)) return res.status(404).json({ error: 'Not found' });
    res.setHeader('Content-Type', c.fileType || 'application/pdf');
    res.setHeader('Content-Disposition', `inline; filename="${c.fileName}"`);
    res.setHeader('Access-Control-Allow-Origin', '*');
    fs.createReadStream(c.filePath).pipe(res);
  } catch { res.status(500).json({ error: 'Server error' }); }
});

/* ══════ DELETE /:id ══════ */
router.delete('/:id', auth, async (req, res) => {
  try {
    const c = await Certificate.findById(req.params.id);
    if (!c) return res.status(404).json({ error: 'Not found' });
    if (req.userRole === 'student' && c.student.toString() !== req.userId.toString()) return res.status(403).json({ error: 'Access denied' });
    if (fs.existsSync(c.filePath)) fs.unlinkSync(c.filePath);
    await Certificate.findByIdAndDelete(req.params.id);
    res.json({ message: 'Deleted' });
  } catch { res.status(500).json({ error: 'Server error' }); }
});

/* ══════ PUT verify/:id (manual) ══════ */
router.put('/verify/:id', auth, teacherOrAdmin, async (req, res) => {
  try {
    const c = await Certificate.findById(req.params.id);
    if (!c) return res.status(404).json({ error: 'Not found' });
    const v = manualVerification(req.userId);
    Object.assign(c, { verificationStatus:v.status, verificationMethod:v.method, verifiedBy:req.userId, verifiedAt:v.verifiedAt });
    await c.save();
    res.json({ message: 'Certificate verified', certificate: c });
  } catch { res.status(500).json({ error: 'Server error' }); }
});

/* ══════ GET stats/overview ══════ */
router.get('/stats/overview', auth, adminOnly, async (req, res) => {
  try {
    const total    = await Certificate.countDocuments();
    const verified = await Certificate.countDocuments({ verificationStatus:'verified' });
    const cats     = await Certificate.aggregate([{ $group:{ _id:'$category', count:{ $sum:1 } } }]);
    res.json({ totalCertificates:total, verifiedCertificates:verified, unverifiedCertificates:total-verified, categoryCounts:cats });
  } catch { res.status(500).json({ error: 'Server error' }); }
});

module.exports = router;
