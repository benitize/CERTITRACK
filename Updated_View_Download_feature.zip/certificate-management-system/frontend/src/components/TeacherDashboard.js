import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { certificateAPI, notificationAPI } from '../services/api';
import socketService from '../services/socket';
import { 
  FiSearch, FiLogOut, FiUser, FiBell, FiFile, 
  FiX, FiCheck, FiFilter, FiArrowLeft, FiDownload, FiUsers
} from 'react-icons/fi';
import './TeacherDashboard.css';

const TeacherDashboard = () => {
  const { user, logout } = useAuth();
  const [view, setView] = useState('students'); // 'students', 'certificates', 'search-results'
  const [students, setStudents] = useState([]);
  const [selectedStudent, setSelectedStudent] = useState(null);
  const [certificates, setCertificates] = useState([]);
  const [searchResults, setSearchResults] = useState([]);
  const [notifications, setNotifications] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [loading, setLoading] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const [unreadCount, setUnreadCount] = useState(0);

  useEffect(() => {
    fetchStudents();
    fetchNotifications();
    
    // Connect to socket for real-time notifications
    console.log('🔌 Connecting to Socket.io...');
    socketService.connect();
    
    socketService.on('new-certificate', handleNewCertificateNotification);

    return () => {
      socketService.off('new-certificate', handleNewCertificateNotification);
    };
  }, []);

  const handleNewCertificateNotification = (data) => {
    console.log('🔔 New certificate notification received:', data);
    
    // Show browser notification if supported
    if ('Notification' in window && Notification.permission === 'granted') {
      new Notification('New Certificate Uploaded', {
        body: `${data.studentName} uploaded: ${data.certificateTitle}`,
        icon: '🎓'
      });
    }
    
    // Refresh data
    fetchNotifications();
    fetchStudents(); // Refresh student list to update counts
  };

  const fetchStudents = async () => {
    setLoading(true);
    try {
      const response = await certificateAPI.getStudents();
      setStudents(response.data.students);
    } catch (error) {
      console.error('Error fetching students:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchStudentCertificates = async (studentId) => {
    setLoading(true);
    try {
      const response = await certificateAPI.getStudentCertificatesById(studentId, '');
      setCertificates(response.data.certificates);
    } catch (error) {
      console.error('Error fetching certificates:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchNotifications = async () => {
    try {
      const response = await notificationAPI.getNotifications();
      setNotifications(response.data.notifications);
      setUnreadCount(response.data.unreadCount);
      console.log('📬 Notifications fetched:', response.data.unreadCount, 'unread');
    } catch (error) {
      console.error('Error fetching notifications:', error);
    }
  };

  // Request notification permission on mount
  useEffect(() => {
    if ('Notification' in window && Notification.permission === 'default') {
      Notification.requestPermission();
    }
  }, []);

  const handleStudentClick = (student) => {
    setSelectedStudent(student);
    setView('certificates');
    fetchStudentCertificates(student._id);
  };

  const handleBackToStudents = () => {
    setView('students');
    setSelectedStudent(null);
    setCertificates([]);
    setSearchQuery('');
    setSearchResults([]);
  };

  const handleNLPSearch = async (e) => {
    e.preventDefault();
    
    if (!searchQuery.trim()) {
      setView('students');
      setSearchResults([]);
      return;
    }

    setLoading(true);
    try {
      // Use NLP search endpoint to search ALL certificates
      const response = await certificateAPI.getAllCertificates(searchQuery);
      setSearchResults(response.data.certificates);
      setView('search-results');
    } catch (error) {
      console.error('Error searching certificates:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSearchChange = (e) => {
    setSearchQuery(e.target.value);
  };

  const clearSearch = () => {
    setSearchQuery('');
    setSearchResults([]);
    setView('students');
  };

  const handleDownload = async (id, fileName) => {
    try {
      const response = await certificateAPI.downloadCertificate(id);
      const url = window.URL.createObjectURL(new Blob([response.data]));
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', fileName);
      document.body.appendChild(link);
      link.click();
      link.remove();
      window.URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Download error:', error);
      alert('Failed to download certificate');
    }
  };

  const markNotificationAsRead = async (notificationId) => {
    try {
      await notificationAPI.markAsRead(notificationId);
      fetchNotifications();
    } catch (error) {
      console.error('Error marking notification as read:', error);
    }
  };

  const markAllAsRead = async () => {
    try {
      await notificationAPI.markAllAsRead();
      fetchNotifications();
    } catch (error) {
      console.error('Error marking all as read:', error);
    }
  };

  return (
    <div className="dashboard-container">
      <header className="dashboard-header">
        <div className="container">
          <div className="header-content">
            <div className="logo">
              <span className="logo-icon">🎓</span>
              <h2>CertifyHub</h2>
            </div>
            <div className="header-actions">
              <div className="notification-btn-wrapper">
                <button
                  onClick={() => setShowNotifications(!showNotifications)}
                  className="notification-btn"
                >
                  <FiBell size={20} />
                  {unreadCount > 0 && (
                    <span className="notification-badge">{unreadCount}</span>
                  )}
                </button>
                
                {showNotifications && (
                  <div className="notifications-dropdown">
                    <div className="notifications-header">
                      <h3>Notifications</h3>
                      {unreadCount > 0 && (
                        <button onClick={markAllAsRead} className="mark-all-btn">
                          <FiCheck /> Mark all read
                        </button>
                      )}
                    </div>
                    <div className="notifications-list">
                      {notifications.length === 0 ? (
                        <p className="no-notifications">No notifications</p>
                      ) : (
                        notifications.map((notif) => (
                          <div
                            key={notif._id}
                            className={`notification-item ${notif.read ? 'read' : 'unread'}`}
                            onClick={() => !notif.read && markNotificationAsRead(notif._id)}
                          >
                            <div className="notif-icon">
                              <FiFile />
                            </div>
                            <div className="notif-content">
                              <p className="notif-title">
                                <strong>{notif.studentName}</strong> uploaded a certificate
                              </p>
                              <p className="notif-cert">{notif.certificateTitle}</p>
                              <p className="notif-time">
                                {new Date(notif.createdAt).toLocaleString()}
                              </p>
                            </div>
                            {!notif.read && <div className="unread-indicator"></div>}
                          </div>
                        ))
                      )}
                    </div>
                  </div>
                )}
              </div>
              
              <div className="user-info">
                <FiUser />
                <span>{user?.name}</span>
                <span className="role-badge teacher">Teacher</span>
              </div>
              <button onClick={logout} className="btn btn-secondary">
                <FiLogOut /> Logout
              </button>
            </div>
          </div>
        </div>
      </header>

      <main className="dashboard-main">
        <div className="container">
          {/* NLP Search Bar - Always visible on home page */}
          {(view === 'students' || view === 'search-results') && (
            <>
              <div className="dashboard-intro">
                <h1>Teacher Dashboard</h1>
                <p>Search certificates using NLP or browse students</p>
                <div className="stats-card">
                  <div className="stat-item">
                    <span className="stat-number">{students.length}</span>
                    <span className="stat-label">Total Students</span>
                  </div>
                </div>
              </div>

              {/* NLP Search Section */}
              <div className="search-section card">
                <div className="search-header">
                  <FiSearch size={24} />
                  <h2>NLP-Powered Certificate Search</h2>
                </div>
                <form onSubmit={handleNLPSearch} className="search-form">
                  <div className="search-input-wrapper">
                    <FiSearch className="search-icon" />
                    <input
                      type="text"
                      value={searchQuery}
                      onChange={handleSearchChange}
                      placeholder='Try "Java Internship", "Machine Learning", "Web Development"...'
                      className="search-input"
                    />
                    {searchQuery && (
                      <button
                        type="button"
                        onClick={clearSearch}
                        className="clear-search-btn"
                      >
                        <FiX />
                      </button>
                    )}
                  </div>
                  <button type="submit" className="btn btn-primary search-btn">
                    <FiFilter /> Search All Certificates
                  </button>
                </form>
                <p className="search-hint">
                  💡 Search across all student certificates using natural language
                </p>
              </div>
            </>
          )}

          {/* Students List View */}
          {view === 'students' && (
            <div className="students-section">
              <h2><FiUsers /> All Students ({students.length})</h2>

              {loading ? (
                <div className="loading-state">
                  <span className="loading"></span>
                  <p>Loading students...</p>
                </div>
              ) : students.length === 0 ? (
                <div className="empty-state card">
                  <FiUsers size={48} />
                  <h3>No students yet</h3>
                  <p>No students have uploaded certificates yet</p>
                </div>
              ) : (
                <div className="students-grid">
                  {students.map((student, index) => (
                    <div 
                      key={student._id} 
                      className="student-card card"
                      onClick={() => handleStudentClick(student)}
                    >
                      <div className="student-number">{index + 1}</div>
                      <div className="student-avatar">
                        <FiUser size={32} />
                      </div>
                      <div className="student-info">
                        <h3>{student.name}</h3>
                        {student.rollNumber && (
                          <p className="roll-number">Roll No: {student.rollNumber}</p>
                        )}
                        {student.department && (
                          <p className="department">{student.department}</p>
                        )}
                        <p className="email">{student.email}</p>
                      </div>
                      <div className="student-stats">
                        <div className="cert-count">
                          <span className="count-number">{student.certificateCount}</span>
                          <span className="count-label">Certificates</span>
                        </div>
                        {student.lastUpload && (
                          <p className="last-upload">
                            Last upload: {new Date(student.lastUpload).toLocaleDateString()}
                          </p>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* NLP Search Results View */}
          {view === 'search-results' && (
            <div className="search-results-section">
              <div className="section-header">
                <h2>
                  <FiSearch /> Search Results for "{searchQuery}" ({searchResults.length})
                </h2>
                <button onClick={clearSearch} className="btn btn-secondary">
                  <FiX /> Clear Search
                </button>
              </div>

              {loading ? (
                <div className="loading-state">
                  <span className="loading"></span>
                  <p>Searching certificates...</p>
                </div>
              ) : searchResults.length === 0 ? (
                <div className="empty-state card">
                  <FiSearch size={48} />
                  <h3>No certificates found</h3>
                  <p>Try a different search term like "Java", "Python", or "Internship"</p>
                  <button onClick={clearSearch} className="btn btn-secondary" style={{marginTop: '1rem'}}>
                    Clear Search
                  </button>
                </div>
              ) : (
                <div className="certificates-grid">
                  {searchResults.map((cert) => (
                    <div key={cert._id} className="certificate-card card search-result">
                      <div className="cert-header">
                        <div className="cert-icon">
                          <FiFile size={32} />
                        </div>
                        <div className="student-badge">
                          <FiUser size={14} />
                          <span>{cert.student?.name}</span>
                        </div>
                      </div>
                      
                      <div className="cert-content">
                        <h3>{cert.title}</h3>
                        <p className="cert-description">{cert.description}</p>

                        <div className="cert-student-info">
                          <p><strong>Student:</strong> {cert.student?.name}</p>
                          {cert.student?.rollNumber && (
                            <p><strong>Roll No:</strong> {cert.student.rollNumber}</p>
                          )}
                          {cert.student?.department && (
                            <p><strong>Department:</strong> {cert.student.department}</p>
                          )}
                        </div>

                        <div className="cert-meta">
                          <span>Uploaded: {new Date(cert.uploadDate).toLocaleDateString()}</span>
                        </div>

                        {cert.keywords && cert.keywords.length > 0 && (
                          <div className="cert-keywords">
                            {cert.keywords.slice(0, 6).map((keyword, idx) => (
                              <span key={idx} className="keyword-tag">{keyword}</span>
                            ))}
                          </div>
                        )}
                      </div>
                      
                      <div className="cert-actions">
                        <a
                          href={`http://localhost:5000${cert.fileUrl}`}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="btn btn-secondary btn-sm"
                        >
                          View
                        </a>
                        <button
                          onClick={() => handleDownload(cert._id, cert.fileName)}
                          className="btn btn-primary btn-sm"
                        >
                          <FiDownload /> Download
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Individual Student Certificates View */}
          {view === 'certificates' && (
            <>
              <div className="back-navigation">
                <button onClick={handleBackToStudents} className="btn btn-secondary">
                  <FiArrowLeft /> Back to Students
                </button>
              </div>

              <div className="dashboard-intro">
                <h1>{selectedStudent?.name}'s Certificates</h1>
                <div className="student-details-banner">
                  {selectedStudent?.rollNumber && (
                    <span>Roll No: {selectedStudent.rollNumber}</span>
                  )}
                  {selectedStudent?.department && (
                    <span>Department: {selectedStudent.department}</span>
                  )}
                  <span className="cert-total">
                    Total: <strong>{certificates.length}</strong> certificates
                  </span>
                </div>
              </div>

              <div className="certificates-section">
                <div className="section-header">
                  <h2>All Certificates ({certificates.length})</h2>
                </div>

                {loading ? (
                  <div className="loading-state">
                    <span className="loading"></span>
                    <p>Loading certificates...</p>
                  </div>
                ) : certificates.length === 0 ? (
                  <div className="empty-state card">
                    <FiFile size={48} />
                    <h3>No certificates yet</h3>
                    <p>This student hasn't uploaded any certificates yet</p>
                  </div>
                ) : (
                  <div className="certificates-grid">
                    {certificates.map((cert) => (
                      <div key={cert._id} className="certificate-card card">
                        <div className="cert-icon">
                          <FiFile size={32} />
                        </div>
                        
                        <div className="cert-content">
                          <h3>{cert.title}</h3>
                          <p className="cert-description">{cert.description}</p>

                          <div className="cert-meta">
                            <span>Uploaded: {new Date(cert.uploadDate).toLocaleDateString()}</span>
                          </div>

                          {cert.keywords && cert.keywords.length > 0 && (
                            <div className="cert-keywords">
                              {cert.keywords.slice(0, 6).map((keyword, idx) => (
                                <span key={idx} className="keyword-tag">{keyword}</span>
                              ))}
                            </div>
                          )}
                        </div>
                        
                        <div className="cert-actions">
                          <a
                            href={`http://localhost:5000${cert.fileUrl}`}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="btn btn-secondary btn-sm"
                          >
                            View
                          </a>
                          <button
                            onClick={() => handleDownload(cert._id, cert.fileName)}
                            className="btn btn-primary btn-sm"
                          >
                            <FiDownload /> Download
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </>
          )}
        </div>
      </main>
    </div>
  );
};

export default TeacherDashboard;
