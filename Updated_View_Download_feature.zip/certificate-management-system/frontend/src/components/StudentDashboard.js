import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { certificateAPI } from '../services/api';
import socketService from '../services/socket';
import { FiUpload, FiFile, FiTrash2, FiLogOut, FiUser, FiDownload } from 'react-icons/fi';
import './StudentDashboard.css';

const StudentDashboard = () => {
  const { user, logout } = useAuth();
  const [certificates, setCertificates] = useState([]);
  const [loading, setLoading] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [showUploadForm, setShowUploadForm] = useState(false);
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    file: null,
  });
  const [message, setMessage] = useState({ type: '', text: '' });

  useEffect(() => {
    fetchCertificates();
    
    // Connect to socket
    console.log('🔌 Student connecting to Socket.io...');
    socketService.connect();
  }, []);

  const fetchCertificates = async () => {
    setLoading(true);
    try {
      const response = await certificateAPI.getStudentCertificates();
      setCertificates(response.data.certificates);
    } catch (error) {
      console.error('Error fetching certificates:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleFileChange = (e) => {
    setFormData({ ...formData, file: e.target.files[0] });
  };

  const handleUpload = async (e) => {
    e.preventDefault();
    setUploading(true);
    setMessage({ type: '', text: '' });

    try {
      const formDataToSend = new FormData();
      formDataToSend.append('title', formData.title);
      formDataToSend.append('description', formData.description);
      formDataToSend.append('certificate', formData.file);

      await certificateAPI.upload(formDataToSend);

      setMessage({ type: 'success', text: 'Certificate uploaded successfully!' });
      setFormData({ title: '', description: '', file: null });
      setShowUploadForm(false);
      fetchCertificates();

      setTimeout(() => setMessage({ type: '', text: '' }), 3000);
    } catch (error) {
      setMessage({ 
        type: 'error', 
        text: error.response?.data?.message || 'Upload failed. Please try again.' 
      });
    } finally {
      setUploading(false);
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Are you sure you want to delete this certificate?')) return;

    try {
      await certificateAPI.deleteCertificate(id);
      setCertificates(certificates.filter((cert) => cert._id !== id));
      setMessage({ type: 'success', text: 'Certificate deleted successfully!' });
      setTimeout(() => setMessage({ type: '', text: '' }), 3000);
    } catch (error) {
      setMessage({ type: 'error', text: 'Failed to delete certificate.' });
    }
  };

  const handleDownload = async (id, fileName) => {
    try {
      const response = await certificateAPI.downloadCertificate(id);
      const url = window.URL.createObjectURL(new Blob([response.data]));
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', fileName);
      document.body.appendChild(link);
      link.click();
      link.remove();
      window.URL.revokeObjectURL(url);
    } catch (error) {
      setMessage({ type: 'error', text: 'Failed to download certificate.' });
    }
  };

  return (
    <div className="dashboard-container">
      <header className="dashboard-header">
        <div className="container">
          <div className="header-content">
            <div className="logo">
              <span className="logo-icon">🎓</span>
              <h2>CertifyHub</h2>
            </div>
            <div className="header-actions">
              <div className="user-info">
                <FiUser />
                <span>{user?.name}</span>
                <span className="role-badge student">Student</span>
              </div>
              <button onClick={logout} className="btn btn-secondary">
                <FiLogOut /> Logout
              </button>
            </div>
          </div>
        </div>
      </header>

      <main className="dashboard-main">
        <div className="container">
          <div className="dashboard-intro">
            <h1>Welcome, {user?.name}!</h1>
            <p>Upload and manage your certificates</p>
            <div className="stats-card">
              <div className="stat-item">
                <span className="stat-number">{certificates.length}</span>
                <span className="stat-label">Total Certificates</span>
              </div>
            </div>
          </div>

          {message.text && (
            <div className={`alert alert-${message.type}`}>
              {message.text}
            </div>
          )}

          <div className="upload-section">
            <button
              onClick={() => setShowUploadForm(!showUploadForm)}
              className="btn btn-primary upload-toggle"
            >
              <FiUpload /> {showUploadForm ? 'Cancel Upload' : 'Upload New Certificate'}
            </button>

            {showUploadForm && (
              <div className="upload-form-container fade-in">
                <form onSubmit={handleUpload} className="upload-form card">
                  <h3>Upload Certificate</h3>
                  
                  <div className="input-group">
                    <label>Certificate Title</label>
                    <input
                      type="text"
                      name="title"
                      value={formData.title}
                      onChange={handleInputChange}
                      required
                      placeholder="e.g., Java Internship Certificate"
                    />
                  </div>

                  <div className="input-group">
                    <label>Description</label>
                    <textarea
                      name="description"
                      value={formData.description}
                      onChange={handleInputChange}
                      required
                      placeholder="Describe your certificate (e.g., 3-month Java internship at XYZ Company...)"
                    />
                  </div>

                  <div className="input-group">
                    <label>Upload File (PDF or Image)</label>
                    <input
                      type="file"
                      accept=".pdf,.jpg,.jpeg,.png"
                      onChange={handleFileChange}
                      required
                    />
                    {formData.file && (
                      <p className="file-info">Selected: {formData.file.name}</p>
                    )}
                  </div>

                  <button type="submit" className="btn btn-primary" disabled={uploading}>
                    {uploading ? <span className="loading"></span> : 'Upload Certificate'}
                  </button>
                </form>
              </div>
            )}
          </div>

          <div className="certificates-section">
            <h2>My Certificates ({certificates.length})</h2>

            {loading ? (
              <div className="loading-state">
                <span className="loading"></span>
                <p>Loading certificates...</p>
              </div>
            ) : certificates.length === 0 ? (
              <div className="empty-state card">
                <FiFile size={48} />
                <h3>No certificates yet</h3>
                <p>Upload your first certificate to get started!</p>
              </div>
            ) : (
              <div className="certificates-grid">
                {certificates.map((cert) => (
                  <div key={cert._id} className="certificate-card card">
                    <div className="cert-icon">
                      <FiFile size={32} />
                    </div>
                    <div className="cert-content">
                      <h3>{cert.title}</h3>
                      <p className="cert-description">{cert.description}</p>
                      <div className="cert-meta">
                        <span>Uploaded: {new Date(cert.uploadDate).toLocaleDateString()}</span>
                      </div>
                      {cert.keywords && cert.keywords.length > 0 && (
                        <div className="cert-keywords">
                          {cert.keywords.slice(0, 5).map((keyword, idx) => (
                            <span key={idx} className="keyword-tag">{keyword}</span>
                          ))}
                        </div>
                      )}
                    </div>
                    <div className="cert-actions">
                      <a 
                        href={`http://localhost:5000${cert.fileUrl}`} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="btn btn-secondary btn-sm"
                      >
                        View
                      </a>
                      <button
                        onClick={() => handleDownload(cert._id, cert.fileName)}
                        className="btn btn-primary btn-sm"
                      >
                        <FiDownload /> Download
                      </button>
                      <button
                        onClick={() => handleDelete(cert._id)}
                        className="btn btn-danger btn-sm"
                      >
                        <FiTrash2 /> Delete
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  );
};

export default StudentDashboard;
