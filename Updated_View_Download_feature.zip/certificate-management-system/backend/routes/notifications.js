const express = require('express');
const router = express.Router();
const User = require('../models/User');
const { authenticate, authorizeRole } = require('../middleware/auth');

// @route   GET /api/notifications
// @desc    Get all notifications for teacher
// @access  Private (Teacher)
router.get('/', authenticate, authorizeRole('teacher'), async (req, res) => {
  try {
    const teacher = await User.findById(req.user._id).select('notifications');
    
    // Sort notifications by date (newest first)
    const notifications = teacher.notifications.sort((a, b) => b.createdAt - a.createdAt);

    res.json({ 
      notifications,
      unreadCount: notifications.filter(n => !n.read).length
    });
  } catch (error) {
    console.error('Get notifications error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// @route   PUT /api/notifications/:id/read
// @desc    Mark notification as read
// @access  Private (Teacher)
router.put('/:id/read', authenticate, authorizeRole('teacher'), async (req, res) => {
  try {
    const teacher = await User.findById(req.user._id);
    
    const notification = teacher.notifications.id(req.params.id);
    
    if (!notification) {
      return res.status(404).json({ message: 'Notification not found' });
    }

    notification.read = true;
    await teacher.save();

    res.json({ message: 'Notification marked as read', notification });
  } catch (error) {
    console.error('Mark notification read error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// @route   PUT /api/notifications/mark-all-read
// @desc    Mark all notifications as read
// @access  Private (Teacher)
router.put('/mark-all-read', authenticate, authorizeRole('teacher'), async (req, res) => {
  try {
    const teacher = await User.findById(req.user._id);
    
    teacher.notifications.forEach(notification => {
      notification.read = true;
    });

    await teacher.save();

    res.json({ message: 'All notifications marked as read' });
  } catch (error) {
    console.error('Mark all read error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// @route   DELETE /api/notifications/:id
// @desc    Delete a notification
// @access  Private (Teacher)
router.delete('/:id', authenticate, authorizeRole('teacher'), async (req, res) => {
  try {
    const teacher = await User.findById(req.user._id);
    
    teacher.notifications.pull(req.params.id);
    await teacher.save();

    res.json({ message: 'Notification deleted' });
  } catch (error) {
    console.error('Delete notification error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;
