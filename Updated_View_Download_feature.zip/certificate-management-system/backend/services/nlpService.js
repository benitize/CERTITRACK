const natural = require('natural');
const compromise = require('compromise');

class NLPService {
  constructor() {
    this.tokenizer = new natural.WordTokenizer();
    this.TfIdf = natural.TfIdf;
    this.stemmer = natural.PorterStemmer;
  }

  // Extract keywords from text using NLP
  extractKeywords(text) {
    const doc = compromise(text);
    
    // Extract nouns, adjectives, and technical terms
    const nouns = doc.nouns().out('array');
    const adjectives = doc.adjectives().out('array');
    const terms = doc.terms().out('array');
    
    // Combine and deduplicate
    const keywords = [...new Set([...nouns, ...adjectives, ...terms])];
    
    // Filter out common words
    const stopWords = ['the', 'a', 'an', 'in', 'on', 'at', 'for', 'to', 'of', 'and', 'or'];
    return keywords
      .filter(word => word && word.length > 2 && !stopWords.includes(word.toLowerCase()))
      .map(word => word.toLowerCase());
  }

  // Process search query using NLP
  processSearchQuery(query) {
    const doc = compromise(query);
    
    // Extract important terms
    const keywords = this.extractKeywords(query);
    
    // Identify entities (organizations, places, topics)
    const organizations = doc.organizations().out('array');
    const topics = doc.topics().out('array');
    
    // Get stemmed versions for better matching
    const stemmedKeywords = keywords.map(word => this.stemmer.stem(word));
    
    return {
      original: query,
      keywords: keywords,
      stemmedKeywords: stemmedKeywords,
      organizations: organizations,
      topics: topics,
      allTerms: [...new Set([...keywords, ...organizations, ...topics])]
    };
  }

  // Calculate similarity score between query and certificate
  calculateRelevanceScore(query, certificate) {
    const processedQuery = this.processSearchQuery(query);
    
    // Combine title and description for matching
    const certificateText = `${certificate.title} ${certificate.description}`.toLowerCase();
    const certificateKeywords = certificate.keywords || [];
    
    let score = 0;
    
    // Exact keyword matches (highest weight)
    processedQuery.keywords.forEach(keyword => {
      if (certificateText.includes(keyword)) {
        score += 10;
      }
    });
    
    // Keyword array matches
    certificateKeywords.forEach(certKeyword => {
      if (processedQuery.keywords.some(qk => certKeyword.toLowerCase().includes(qk))) {
        score += 8;
      }
    });
    
    // Stemmed matches (medium weight)
    processedQuery.stemmedKeywords.forEach(stemmed => {
      const certTextStemmed = this.tokenizer.tokenize(certificateText)
        .map(word => this.stemmer.stem(word));
      
      if (certTextStemmed.includes(stemmed)) {
        score += 5;
      }
    });
    
    // Organization/topic matches (high weight)
    processedQuery.organizations.forEach(org => {
      if (certificateText.includes(org.toLowerCase())) {
        score += 12;
      }
    });
    
    processedQuery.topics.forEach(topic => {
      if (certificateText.includes(topic.toLowerCase())) {
        score += 7;
      }
    });
    
    return score;
  }

  // Smart search with NLP
  searchCertificates(query, certificates) {
    if (!query || query.trim() === '') {
      return certificates;
    }

    // Score each certificate
    const scoredCertificates = certificates.map(cert => ({
      certificate: cert,
      score: this.calculateRelevanceScore(query, cert)
    }));

    // Filter certificates with score > 0 and sort by score
    return scoredCertificates
      .filter(item => item.score > 0)
      .sort((a, b) => b.score - a.score)
      .map(item => item.certificate);
  }

  // Suggest related search terms
  suggestSearchTerms(query) {
    const doc = compromise(query);
    const suggestions = [];
    
    // Extract nouns and topics
    const nouns = doc.nouns().out('array');
    const topics = doc.topics().out('array');
    
    // Create variations
    [...nouns, ...topics].forEach(term => {
      suggestions.push(term);
      suggestions.push(`${term} certificate`);
      suggestions.push(`${term} training`);
      suggestions.push(`${term} internship`);
    });
    
    return [...new Set(suggestions)].slice(0, 5);
  }
}

module.exports = new NLPService();
