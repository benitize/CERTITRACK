# CertifyHub - Certificate Management System

A full-stack MERN application with NLP-powered search for managing student certificates. Features real-time notifications, intelligent search using Natural Language Processing, and separate dashboards for students and teachers.

## 🚀 Features

### Student Features
- ✅ Register and login as a student
- 📤 Upload certificates with title and description
- 🏷️ Automatic keyword extraction using NLP
- 📋 View all uploaded certificates
- 🗑️ Delete certificates
- 💾 Support for PDF and image files

### Teacher Features
- ✅ Register and login as a teacher
- 🔍 **NLP-Powered Search** - Search certificates using natural language
  - Example: "Java Internship" matches certificates about Java internships
  - Intelligent keyword matching and relevance scoring
  - Semantic understanding of search queries
- 🔔 Real-time notifications when students upload certificates
- 👁️ View all student certificates with detailed information
- 📊 See student details (name, roll number, department)
- 🔄 Live updates via WebSocket

### Technical Features
- 🧠 Natural Language Processing using `natural` and `compromise` libraries
- 🔐 JWT-based authentication
- 🔄 Real-time notifications with Socket.io
- 📱 Responsive, modern UI design
- 🎨 Distinctive gradient-based design aesthetic
- 🔒 Role-based access control

## 🛠️ Tech Stack

### Backend
- **Node.js** - Runtime environment
- **Express.js** - Web framework
- **MongoDB** - Database
- **Mongoose** - ODM
- **Natural** - NLP library for tokenization and stemming
- **Compromise** - NLP library for entity extraction
- **Socket.io** - Real-time communication
- **JWT** - Authentication
- **Multer** - File upload handling
- **Bcrypt** - Password hashing

### Frontend
- **React** - UI library
- **React Router** - Routing
- **Axios** - HTTP client
- **Socket.io Client** - Real-time updates
- **React Icons** - Icon library

## 📋 Prerequisites

Before running this application, make sure you have:

- Node.js (v14 or higher)
- MongoDB (running locally or MongoDB Atlas account)
- npm or yarn package manager

## 🔧 Installation & Setup

### 1. Clone or Extract the Project

```bash
cd certificate-management-system
```

### 2. Backend Setup

```bash
# Navigate to backend directory
cd backend

# Install dependencies
npm install

# Create .env file
cp .env.example .env
```

Edit the `.env` file with your configuration:

```env
PORT=5000
MONGODB_URI=mongodb://localhost:27017/certificate_management
JWT_SECRET=your_super_secret_jwt_key_change_this_in_production
NODE_ENV=development
```

**Important:** If using MongoDB Atlas, replace `MONGODB_URI` with your Atlas connection string.

### 3. Frontend Setup

```bash
# Navigate to frontend directory (from project root)
cd frontend

# Install dependencies
npm install
```

Create a `.env` file in the frontend directory (optional):

```env
REACT_APP_API_URL=http://localhost:5000/api
REACT_APP_SOCKET_URL=http://localhost:5000
```

### 4. Start MongoDB

Make sure MongoDB is running on your system:

```bash
# If using local MongoDB
mongod

# Or if using MongoDB as a service
sudo systemctl start mongod
```

### 5. Run the Application

**Terminal 1 - Backend:**
```bash
cd backend
npm run dev
# Backend will run on http://localhost:5000
```

**Terminal 2 - Frontend:**
```bash
cd frontend
npm start
# Frontend will run on http://localhost:3000
```

## 📖 Usage Guide

### For Students

1. **Register/Login**
   - Open http://localhost:3000
   - Click "Sign Up" and select "Student" as role
   - Fill in your details (name, email, password, department, roll number)
   - Login with your credentials

2. **Upload Certificate**
   - Click "Upload New Certificate" button
   - Enter certificate title (e.g., "Java Internship Certificate")
   - Add a detailed description
   - Upload your certificate file (PDF or Image)
   - Click "Upload Certificate"

3. **Manage Certificates**
   - View all your uploaded certificates
   - Click "View" to see the certificate
   - Click "Delete" to remove a certificate

### For Teachers

1. **Register/Login**
   - Click "Sign Up" and select "Teacher" as role
   - Fill in your details
   - Login with your credentials

2. **View Notifications**
   - Click the bell icon (🔔) in the header
   - See new certificate uploads from students
   - Click on a notification to mark it as read
   - Click "Mark all read" to clear all notifications

3. **Search Certificates (NLP-Powered)**
   - Use the search bar at the top
   - Type natural language queries like:
     - "Java Internship"
     - "Machine Learning certificate"
     - "Web Development course"
     - "Python programming"
   - The system uses NLP to find relevant certificates
   - Results are ranked by relevance score

4. **View Certificate Details**
   - See student name, roll number, and department
   - View certificate title and description
   - See extracted keywords
   - Click "View Certificate" to open the file

## 🧠 How NLP Search Works

The search system uses advanced Natural Language Processing:

1. **Query Processing**
   - Tokenizes the search query
   - Extracts nouns, adjectives, and topics
   - Identifies organizations and entities
   - Creates stemmed versions for better matching

2. **Keyword Extraction**
   - Automatically extracts keywords from certificate titles and descriptions
   - Stores keywords in the database for fast retrieval

3. **Relevance Scoring**
   - Exact keyword matches: 10 points
   - Keyword array matches: 8 points
   - Stemmed matches: 5 points
   - Organization/topic matches: 12 points

4. **Results**
   - Certificates are ranked by relevance score
   - Only certificates with score > 0 are shown
   - Results are sorted from most to least relevant

## 📁 Project Structure

```
certificate-management-system/
├── backend/
│   ├── models/
│   │   ├── User.js              # User model (students & teachers)
│   │   └── Certificate.js       # Certificate model
│   ├── routes/
│   │   ├── auth.js             # Authentication routes
│   │   ├── certificates.js     # Certificate routes
│   │   └── notifications.js    # Notification routes
│   ├── services/
│   │   └── nlpService.js       # NLP search logic
│   ├── middleware/
│   │   ├── auth.js             # JWT authentication
│   │   └── upload.js           # File upload config
│   ├── uploads/                # Uploaded certificates
│   ├── server.js               # Express server
│   ├── package.json
│   └── .env.example
│
├── frontend/
│   ├── public/
│   │   └── index.html
│   ├── src/
│   │   ├── components/
│   │   │   ├── Auth.js         # Login/Register
│   │   │   ├── Auth.css
│   │   │   ├── StudentDashboard.js
│   │   │   ├── StudentDashboard.css
│   │   │   ├── TeacherDashboard.js
│   │   │   └── TeacherDashboard.css
│   │   ├── context/
│   │   │   └── AuthContext.js  # Auth state management
│   │   ├── services/
│   │   │   ├── api.js          # API calls
│   │   │   └── socket.js       # Socket.io client
│   │   ├── App.js              # Main app component
│   │   ├── index.js            # Entry point
│   │   └── index.css           # Global styles
│   └── package.json
│
└── README.md
```

## 🔒 Security Features

- Password hashing with bcrypt
- JWT token-based authentication
- Protected API routes
- Role-based access control
- File type validation
- File size limits (5MB)

## 🎨 Design Features

- Modern gradient-based design
- Distinctive typography (Lexend + Archivo fonts)
- Animated backgrounds
- Smooth transitions and hover effects
- Responsive layout
- Dark theme with cyan accents

## 🐛 Troubleshooting

### Backend won't start
- Ensure MongoDB is running
- Check if port 5000 is available
- Verify .env configuration

### Frontend won't connect to backend
- Check if backend is running on port 5000
- Verify CORS is enabled
- Check browser console for errors

### File uploads not working
- Ensure `uploads/certificates/` directory exists
- Check file size (max 5MB)
- Verify file type (PDF, JPG, PNG only)

### NLP search not working properly
- Make sure certificates have titles and descriptions
- Try more specific search terms
- Check backend logs for NLP processing errors

## 📝 API Endpoints

### Authentication
- `POST /api/auth/register` - Register new user
- `POST /api/auth/login` - Login user
- `GET /api/auth/me` - Get current user

### Certificates
- `POST /api/certificates/upload` - Upload certificate (Student)
- `GET /api/certificates/student` - Get student's certificates
- `GET /api/certificates/all?search=query` - Get all with NLP search (Teacher)
- `GET /api/certificates/:id` - Get single certificate
- `DELETE /api/certificates/:id` - Delete certificate (Student)

### Notifications
- `GET /api/notifications` - Get teacher notifications
- `PUT /api/notifications/:id/read` - Mark as read
- `PUT /api/notifications/mark-all-read` - Mark all as read
- `DELETE /api/notifications/:id` - Delete notification

## 🚀 Future Enhancements

- Email notifications
- Certificate verification
- Bulk upload
- Advanced analytics dashboard
- Certificate templates
- Export to PDF reports
- Mobile app
- Multi-language support

## 📄 License

This project is open source and available for educational purposes.

## 👨‍💻 Developer Notes

- Built with MERN stack
- Uses NLP libraries: `natural` and `compromise`
- Real-time features powered by Socket.io
- Follows RESTful API design
- Component-based React architecture
- Context API for state management

## 🤝 Contributing

Feel free to fork this project and submit pull requests for any improvements!

---

**Developed with ❤️ using MERN Stack + NLP**
