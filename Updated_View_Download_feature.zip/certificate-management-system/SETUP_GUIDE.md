# Quick Setup Guide - CertifyHub

## Step-by-Step Installation

### 1️⃣ Install Prerequisites

**Install Node.js:**
- Download from https://nodejs.org/
- Choose LTS version (v18 or higher recommended)
- Verify installation: `node --version` and `npm --version`

**Install MongoDB:**

**Option A - Local MongoDB:**
```bash
# macOS (using Homebrew)
brew tap mongodb/brew
brew install mongodb-community
brew services start mongodb-community

# Ubuntu/Debian
sudo apt-get install mongodb
sudo systemctl start mongodb

# Windows
# Download from https://www.mongodb.com/try/download/community
# Install and run as a service
```

**Option B - MongoDB Atlas (Cloud):**
1. Go to https://www.mongodb.com/cloud/atlas
2. Create free account
3. Create a cluster
4. Get connection string
5. Use it in your .env file

### 2️⃣ Setup Backend

```bash
# Navigate to backend
cd certificate-management-system/backend

# Install dependencies
npm install

# Create environment file
cp .env.example .env

# Edit .env file (use nano, vim, or any text editor)
nano .env
```

**.env configuration:**
```env
PORT=5000
MONGODB_URI=mongodb://localhost:27017/certificate_management
# OR for MongoDB Atlas:
# MONGODB_URI=mongodb+srv://username:password@cluster.mongodb.net/certificate_management

JWT_SECRET=your_random_secret_key_here_make_it_long_and_complex
NODE_ENV=development
```

**Generate a strong JWT secret:**
```bash
# On Linux/Mac
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"

# Or use any long random string
```

### 3️⃣ Setup Frontend

```bash
# Navigate to frontend
cd ../frontend

# Install dependencies
npm install

# Optional: Create .env file for custom API URLs
echo "REACT_APP_API_URL=http://localhost:5000/api" > .env
echo "REACT_APP_SOCKET_URL=http://localhost:5000" >> .env
```

### 4️⃣ Create Required Directories

```bash
# Create uploads directory for certificates
cd ../backend
mkdir -p uploads/certificates
```

### 5️⃣ Start the Application

**Terminal 1 - Backend:**
```bash
cd backend
npm run dev

# You should see:
# "Server running on port 5000"
# "Connected to MongoDB"
```

**Terminal 2 - Frontend:**
```bash
cd frontend
npm start

# Browser should automatically open http://localhost:3000
# If not, manually open it
```

## 🧪 Test the Application

### Create Test Accounts

1. **Create a Student Account:**
   - Go to http://localhost:3000
   - Click "Sign Up"
   - Fill in:
     - Name: John Student
     - Email: student@test.com
     - Password: student123
     - Role: Student
     - Department: Computer Science
     - Roll Number: CS001

2. **Create a Teacher Account:**
   - Logout and register again
   - Fill in:
     - Name: Jane Teacher
     - Email: teacher@test.com
     - Password: teacher123
     - Role: Teacher
     - Department: Computer Science

### Test Student Features

1. Login as student@test.com
2. Click "Upload New Certificate"
3. Fill in:
   - Title: "Java Programming Internship"
   - Description: "Completed 3-month Java internship at ABC Company focusing on Spring Boot and Microservices"
   - Upload a PDF or image file
4. Click "Upload Certificate"
5. See your certificate in the list

### Test Teacher Features

1. Logout and login as teacher@test.com
2. Check the notification bell - you should see a notification
3. Try searching:
   - Type "Java"
   - Type "Internship"
   - Type "Spring Boot"
4. See the student's certificate appear

## 🔧 Troubleshooting

### Issue: "Cannot connect to MongoDB"

**Solution:**
```bash
# Check if MongoDB is running
# For local MongoDB:
sudo systemctl status mongodb  # Linux
brew services list | grep mongodb  # macOS

# Start MongoDB if not running
sudo systemctl start mongodb  # Linux
brew services start mongodb-community  # macOS

# For MongoDB Atlas: Check your connection string and whitelist your IP
```

### Issue: "Port 5000 already in use"

**Solution:**
```bash
# Find and kill the process using port 5000
# Linux/Mac:
lsof -ti:5000 | xargs kill -9

# Windows:
netstat -ano | findstr :5000
taskkill /PID <PID_NUMBER> /F

# Or change the port in backend/.env
PORT=5001
```

### Issue: "CORS errors in browser"

**Solution:**
- Make sure backend is running on port 5000
- Check that CORS is enabled in server.js (it already is)
- Clear browser cache
- Try in incognito mode

### Issue: "File upload fails"

**Solution:**
```bash
# Make sure uploads directory exists
cd backend
mkdir -p uploads/certificates

# Check file permissions
chmod 755 uploads/certificates

# Verify file size is under 5MB
# Verify file type is PDF, JPG, or PNG
```

### Issue: "npm install fails"

**Solution:**
```bash
# Clear npm cache
npm cache clean --force

# Delete node_modules and package-lock.json
rm -rf node_modules package-lock.json

# Install again
npm install

# If still failing, try with --legacy-peer-deps
npm install --legacy-peer-deps
```

### Issue: "Search not working properly"

**Solution:**
- Make sure you've uploaded certificates with good titles and descriptions
- The NLP search needs meaningful text to work with
- Try exact keyword matches first
- Check browser console for errors

## 📱 Using the Application

### Student Workflow
1. Register → 2. Login → 3. Upload Certificate → 4. View/Delete Certificates

### Teacher Workflow
1. Register → 2. Login → 3. Check Notifications → 4. Search Certificates → 5. View Details

## 🎯 Tips for Best Results

1. **For NLP Search:**
   - Use descriptive titles: "Java Spring Boot Internship" instead of "Internship"
   - Add detailed descriptions with keywords
   - The system extracts keywords automatically

2. **For Notifications:**
   - Keep browser tab open for real-time updates
   - Notifications appear instantly when students upload

3. **File Uploads:**
   - Use clear, readable PDFs
   - Keep files under 5MB
   - Use descriptive filenames

## 🔐 Default Test Credentials

After setup, you can use these accounts for testing:

**Student:**
- Email: student@test.com
- Password: student123

**Teacher:**
- Email: teacher@test.com
- Password: teacher123

## 📊 Monitoring

**Check Backend Logs:**
```bash
cd backend
npm run dev
# Watch the console for:
# - API requests
# - NLP processing
# - Socket connections
# - Database queries
```

**Check Frontend in Browser:**
- Open Developer Tools (F12)
- Check Console tab for errors
- Check Network tab for API calls

## 🚀 Production Deployment

For production deployment:

1. **Backend:**
   - Use MongoDB Atlas or managed MongoDB
   - Set NODE_ENV=production
   - Use strong JWT secret
   - Set up proper logging
   - Use process manager (PM2)

2. **Frontend:**
   - Run `npm run build`
   - Serve with nginx or similar
   - Update API URLs

3. **Security:**
   - Enable HTTPS
   - Set up firewall rules
   - Regular backups
   - Monitor logs

## ✅ Success Checklist

- [ ] Node.js and npm installed
- [ ] MongoDB running
- [ ] Backend dependencies installed
- [ ] Frontend dependencies installed
- [ ] .env file configured
- [ ] Uploads directory created
- [ ] Backend starts without errors
- [ ] Frontend starts and opens in browser
- [ ] Can register student account
- [ ] Can register teacher account
- [ ] Student can upload certificate
- [ ] Teacher receives notification
- [ ] Search works correctly

## 📞 Need Help?

If you encounter issues not covered here:
1. Check the browser console for errors
2. Check the backend terminal for error logs
3. Verify all prerequisites are installed
4. Make sure all environment variables are set
5. Try restarting both backend and frontend

---

**Happy Learning! 🎓**
