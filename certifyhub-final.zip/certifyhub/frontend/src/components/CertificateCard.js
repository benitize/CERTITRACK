import React from 'react';

const CertificateCard = ({ certificate, onDownload, onDelete, onVerify, showStudent = false, userRole }) => {
  const formatDate = (date) => {
    return new Date(date).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  const getVerificationBadge = () => {
    if (certificate.verificationStatus === 'verified') {
      return (
        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
          <svg className="w-3 h-3 mr-1" fill="currentColor" viewBox="0 0 20 20">
            <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
          </svg>
          Verified
        </span>
      );
    }
    return (
      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
        Unverified
      </span>
    );
  };

  const getCategoryColor = (category) => {
    const colors = {
      'Programming': 'bg-blue-100 text-blue-800',
      'Backend': 'bg-purple-100 text-purple-800',
      'Frontend': 'bg-pink-100 text-pink-800',
      'Database': 'bg-yellow-100 text-yellow-800',
      'Cloud': 'bg-indigo-100 text-indigo-800',
      'AI/ML': 'bg-green-100 text-green-800',
      'Mobile': 'bg-orange-100 text-orange-800',
      'Other': 'bg-gray-100 text-gray-800'
    };
    return colors[category] || colors['Other'];
  };

  return (
    <div className="bg-white rounded-lg shadow-md hover:shadow-lg transition-shadow duration-200 p-6">
      {/* Header with Title and Badges */}
      <div className="flex justify-between items-start mb-3">
        <h3 className="text-lg font-semibold text-gray-900 flex-1 mr-2">
          {certificate.title}
        </h3>
        <div className="flex flex-col gap-1 items-end">
          {getVerificationBadge()}
          <span className={`px-2.5 py-0.5 rounded-full text-xs font-medium ${getCategoryColor(certificate.category)}`}>
            {certificate.category}
          </span>
        </div>
      </div>

      {/* Student Info (for teachers/admins) */}
      {showStudent && certificate.student && (
        <div className="mb-3 pb-3 border-b">
          <p className="text-sm text-gray-600">
            <span className="font-medium">Student:</span> {certificate.student.name}
          </p>
          {certificate.student.rollNumber && (
            <p className="text-sm text-gray-600">
              <span className="font-medium">Roll No:</span> {certificate.student.rollNumber}
            </p>
          )}
          {certificate.student.department && (
            <p className="text-sm text-gray-600">
              <span className="font-medium">Department:</span> {certificate.student.department}
            </p>
          )}
        </div>
      )}

      {/* Description */}
      <p className="text-gray-600 text-sm mb-4 line-clamp-2">
        {certificate.description}
      </p>

      {/* Details Grid */}
      <div className="grid grid-cols-2 gap-3 mb-4 text-sm">
        <div>
          <p className="text-gray-500">Issue Date</p>
          <p className="font-medium text-gray-900">{formatDate(certificate.issueDate)}</p>
        </div>
        <div>
          <p className="text-gray-500">Uploaded</p>
          <p className="font-medium text-gray-900">{formatDate(certificate.uploadedAt)}</p>
        </div>
        {certificate.issuer && certificate.issuer !== '' && (
          <div>
            <p className="text-gray-500">Issuer</p>
            <p className="font-medium text-gray-900">{certificate.issuer}</p>
          </div>
        )}
        <div>
          <p className="text-gray-500">Skill Level</p>
          <p className="font-medium text-gray-900">{certificate.skillLevel}</p>
        </div>
      </div>

      {/* Verification Details */}
      {certificate.verificationStatus === 'verified' && certificate.verificationMethod && (
        <div className="bg-green-50 rounded-md p-3 mb-4">
          <p className="text-xs text-green-800">
            <span className="font-medium">Verification Method:</span>{' '}
            {certificate.verificationMethod === 'qr_code' && 'QR Code'}
            {certificate.verificationMethod === 'certificate_id' && 'Certificate ID'}
            {certificate.verificationMethod === 'manual' && 'Manual Verification'}
          </p>
          {certificate.verifiedAt && (
            <p className="text-xs text-green-800 mt-1">
              Verified on {formatDate(certificate.verifiedAt)}
            </p>
          )}
        </div>
      )}

      {/* Keywords */}
      {certificate.keywords && certificate.keywords.length > 0 && (
        <div className="mb-4">
          <div className="flex flex-wrap gap-1">
            {certificate.keywords.slice(0, 5).map((keyword, index) => (
              <span
                key={index}
                className="px-2 py-0.5 bg-gray-100 text-gray-700 rounded text-xs"
              >
                {keyword}
              </span>
            ))}
          </div>
        </div>
      )}

      {/* Action Buttons */}
      <div className="flex gap-2 flex-wrap">
        {onDownload && (
          <button
            onClick={() => onDownload(certificate._id)}
            className="flex-1 min-w-[100px] bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition-colors text-sm font-medium flex items-center justify-center"
          >
            <svg className="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
            </svg>
            Download
          </button>
        )}

        {onVerify && certificate.verificationStatus !== 'verified' && (userRole === 'teacher' || userRole === 'admin') && (
          <button
            onClick={() => onVerify(certificate._id)}
            className="flex-1 min-w-[100px] bg-green-600 text-white px-4 py-2 rounded-md hover:bg-green-700 transition-colors text-sm font-medium flex items-center justify-center"
          >
            <svg className="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            Verify
          </button>
        )}

        {onDelete && (
          <button
            onClick={() => {
              if (window.confirm('Are you sure you want to delete this certificate?')) {
                onDelete(certificate._id);
              }
            }}
            className="bg-red-600 text-white px-4 py-2 rounded-md hover:bg-red-700 transition-colors text-sm font-medium flex items-center justify-center"
          >
            <svg className="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
            </svg>
            Delete
          </button>
        )}
      </div>
    </div>
  );
};

export default CertificateCard;
