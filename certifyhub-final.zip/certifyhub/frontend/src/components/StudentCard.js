import React from 'react';

const StudentCard = ({ student, index, onClick }) => {
  return (
    <div
      onClick={() => onClick(student)}
      className="bg-white rounded-lg shadow-md hover:shadow-xl transition-all duration-200 p-6 cursor-pointer border-2 border-transparent hover:border-blue-500"
    >
      {/* Student Number Badge */}
      <div className="flex justify-between items-start mb-4">
        <div className="bg-blue-600 text-white rounded-full w-10 h-10 flex items-center justify-center font-bold text-lg">
          {index}
        </div>
        <div className="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm font-semibold">
          {student.certificateCount || 0} {student.certificateCount === 1 ? 'Cert' : 'Certs'}
        </div>
      </div>

      {/* Student Info */}
      <div className="space-y-2">
        <h3 className="text-lg font-bold text-gray-900 truncate">
          {student.name}
        </h3>
        
        {student.rollNumber && (
          <div className="flex items-center text-sm text-gray-600">
            <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 6H5a2 2 0 00-2 2v9a2 2 0 002 2h14a2 2 0 002-2V8a2 2 0 00-2-2h-5m-4 0V5a2 2 0 114 0v1m-4 0a2 2 0 104 0m-5 8a2 2 0 100-4 2 2 0 000 4zm0 0c1.306 0 2.417.835 2.83 2M9 14a3.001 3.001 0 00-2.83 2M15 11h3m-3 4h2" />
            </svg>
            <span className="font-medium">Roll No:</span>
            <span className="ml-1">{student.rollNumber}</span>
          </div>
        )}

        {student.department && (
          <div className="flex items-center text-sm text-gray-600">
            <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
            </svg>
            <span className="font-medium">Dept:</span>
            <span className="ml-1 truncate">{student.department}</span>
          </div>
        )}

        {student.email && (
          <div className="flex items-center text-sm text-gray-600 truncate">
            <svg className="w-4 h-4 mr-2 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
            </svg>
            <span className="truncate">{student.email}</span>
          </div>
        )}
      </div>

      {/* Certificate Count Indicator */}
      <div className="mt-4 pt-4 border-t border-gray-200">
        <div className="flex items-center justify-between">
          <span className="text-xs text-gray-500">Total Certificates</span>
          <div className="flex items-center">
            {student.certificateCount > 0 ? (
              <>
                <div className="w-full bg-gray-200 rounded-full h-2 mr-2" style={{ width: '60px' }}>
                  <div
                    className="bg-blue-600 h-2 rounded-full"
                    style={{ width: `${Math.min(100, (student.certificateCount / 20) * 100)}%` }}
                  ></div>
                </div>
                <span className="text-sm font-bold text-blue-600">{student.certificateCount}</span>
              </>
            ) : (
              <span className="text-sm text-gray-400">No certificates</span>
            )}
          </div>
        </div>
      </div>

      {/* Click Indicator */}
      <div className="mt-4 text-center">
        <span className="text-xs text-gray-400 flex items-center justify-center">
          Click to view certificates
          <svg className="w-3 h-3 ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
          </svg>
        </span>
      </div>
    </div>
  );
};

export default StudentCard;
