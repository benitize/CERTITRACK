import axios from 'axios';

const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000/api';

// Create axios instance
const api = axios.create({
  baseURL: API_URL,
  headers: {
    'Content-Type': 'application/json'
  }
});

// Add token to requests
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// Authentication
export const authAPI = {
  register: (data) => api.post('/auth/register', data),
  login: (data) => api.post('/auth/login', data),
  getMe: () => api.get('/auth/me'),
  verifyToken: () => api.get('/auth/verify-token')
};

// Certificates
export const certificateAPI = {
  upload: (formData) => {
    return api.post('/certificates/upload', formData, {
      headers: { 'Content-Type': 'multipart/form-data' }
    });
  },
  getMyCertificates: () => api.get('/certificates/my-certificates'),
  getAllCertificates: (params) => api.get('/certificates/all', { params }),
  search: (params) => api.get('/certificates/search', { params }),
  download: (id) => api.get(`/certificates/download/${id}`, { responseType: 'blob' }),
  delete: (id) => api.delete(`/certificates/${id}`),
  verify: (id) => api.put(`/certificates/verify/${id}`),
  getStats: () => api.get('/certificates/stats/overview')
};

// Admin
export const adminAPI = {
  getPendingApprovals: () => api.get('/admin/pending-approvals'),
  approveUser: (userId) => api.put(`/admin/approve/${userId}`),
  rejectUser: (userId) => api.delete(`/admin/reject/${userId}`),
  getUsers: (params) => api.get('/admin/users', { params }),
  getStudents: () => api.get('/admin/students'),
  deleteUser: (userId) => api.delete(`/admin/users/${userId}`),
  getDashboardStats: () => api.get('/admin/dashboard/stats')
};

// ML Analysis
export const mlAPI = {
  getMyAnalysis: () => api.get('/ml/growth-analysis'),
  getStudentAnalysis: (studentId) => api.get(`/ml/growth-analysis/${studentId}`)
};

// Notifications
export const notificationAPI = {
  getNotifications: () => api.get('/notifications')
};

export default api;
