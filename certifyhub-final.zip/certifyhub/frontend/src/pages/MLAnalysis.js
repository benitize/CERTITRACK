import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { mlAPI } from '../services/api';
import { getErrorMessage, getScoreColor, getScoreBgColor, getPriorityColor } from '../utils/helpers';

const MLAnalysis = () => {
  const navigate = useNavigate();
  const [analysis, setAnalysis] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    fetchAnalysis();
  }, []);

  const fetchAnalysis = async () => {
    setLoading(true);
    try {
      const response = await mlAPI.getMyAnalysis();
      if (response.data.hasData) {
        setAnalysis(response.data.analysis);
      } else {
        setError(response.data.message);
      }
    } catch (error) {
      setError(getErrorMessage(error));
    } finally {
      setLoading(false);
    }
  };

  const COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899', '#14b8a6', '#64748b'];

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="inline-block animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
          <p className="mt-4 text-gray-600">Analyzing your learning journey...</p>
        </div>
      </div>
    );
  }

  if (error || !analysis) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="max-w-md w-full bg-white rounded-lg shadow-lg p-8 text-center">
          <svg className="w-16 h-16 text-yellow-400 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
          </svg>
          <h2 className="text-xl font-semibold text-gray-900 mb-2">No Analysis Available</h2>
          <p className="text-gray-600 mb-6">{error || 'Upload certificates to view your growth analysis'}</p>
          <button
            onClick={() => navigate('/student')}
            className="bg-blue-600 text-white px-6 py-2 rounded-md hover:bg-blue-700"
          >
            Go to Dashboard
          </button>
        </div>
      </div>
    );
  }

  const categoryData = Object.entries(analysis.features.categoryCounts).map(([name, value]) => ({
    name,
    value
  })).filter(item => item.value > 0);

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <button
            onClick={() => navigate('/student')}
            className="mb-4 flex items-center text-blue-600 hover:text-blue-800"
          >
            <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" />
            </svg>
            Back to Dashboard
          </button>
          <h1 className="text-3xl font-bold text-gray-900">AI Growth Analysis</h1>
          <p className="text-gray-600 mt-2">Powered by Random Forest Machine Learning</p>
        </div>

        {/* Score Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          {/* Skill Level Score */}
          <div className="bg-white rounded-lg shadow-lg p-6">
            <h3 className="text-lg font-semibold mb-4">Skill Level Score</h3>
            <div className="flex items-center justify-between mb-4">
              <div className={`text-5xl font-bold ${getScoreColor(analysis.skillLevelScore)}`}>
                {analysis.skillLevelScore}
              </div>
              <div className="text-right">
                <p className="text-sm text-gray-500">out of 100</p>
                <p className="text-xs text-gray-400 mt-1">Based on volume, diversity & progression</p>
              </div>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-3">
              <div
                className={`h-3 rounded-full ${getScoreBgColor(analysis.skillLevelScore)}`}
                style={{ width: `${analysis.skillLevelScore}%` }}
              ></div>
            </div>
          </div>

          {/* Career Readiness Score */}
          <div className="bg-white rounded-lg shadow-lg p-6">
            <h3 className="text-lg font-semibold mb-4">Career Readiness Score</h3>
            <div className="flex items-center justify-between mb-4">
              <div className={`text-5xl font-bold ${getScoreColor(analysis.careerReadinessScore)}`}>
                {analysis.careerReadinessScore}
              </div>
              <div className="text-right">
                <p className="text-sm text-gray-500">out of 100</p>
                <p className="text-xs text-gray-400 mt-1">Random Forest Ensemble</p>
              </div>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-3">
              <div
                className={`h-3 rounded-full ${getScoreBgColor(analysis.careerReadinessScore)}`}
                style={{ width: `${analysis.careerReadinessScore}%` }}
              ></div>
            </div>

            {/* Breakdown */}
            <div className="mt-4 grid grid-cols-2 gap-2 text-sm">
              <div className="flex justify-between">
                <span className="text-gray-600">Volume:</span>
                <span className="font-medium">{analysis.careerReadinessBreakdown.volume}/25</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Diversity:</span>
                <span className="font-medium">{analysis.careerReadinessBreakdown.diversity}/20</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Progression:</span>
                <span className="font-medium">{analysis.careerReadinessBreakdown.progression}/25</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Consistency:</span>
                <span className="font-medium">{analysis.careerReadinessBreakdown.consistency}/15</span>
              </div>
              <div className="flex justify-between col-span-2">
                <span className="text-gray-600">Specialization:</span>
                <span className="font-medium">{analysis.careerReadinessBreakdown.specialization}/15</span>
              </div>
            </div>
          </div>
        </div>

        {/* Career Predictions */}
        <div className="bg-white rounded-lg shadow-lg p-6 mb-8">
          <h3 className="text-lg font-semibold mb-4">Career Role Predictions</h3>
          <div className="space-y-3">
            {analysis.predictedRoles.map((role, index) => (
              <div key={index}>
                <div className="flex justify-between items-center mb-1">
                  <span className="font-medium">{role.role}</span>
                  <span className="text-sm text-gray-600">{role.confidence}% confidence</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div
                    className="bg-blue-600 h-2 rounded-full"
                    style={{ width: `${role.confidence}%` }}
                  ></div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Growth Chart */}
        <div className="bg-white rounded-lg shadow-lg p-6 mb-8">
          <h3 className="text-lg font-semibold mb-4">Certificate Growth Over Time</h3>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={analysis.growthChart}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="date" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Line type="monotone" dataKey="count" stroke="#3b82f6" strokeWidth={2} name="Total Certificates" />
            </LineChart>
          </ResponsiveContainer>
        </div>

        {/* Category Distribution and Peer Comparison */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          {/* Category Distribution */}
          <div className="bg-white rounded-lg shadow-lg p-6">
            <h3 className="text-lg font-semibold mb-4">Skill Distribution</h3>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={categoryData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {categoryData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>

          {/* Peer Comparison */}
          <div className="bg-white rounded-lg shadow-lg p-6">
            <h3 className="text-lg font-semibold mb-4">Peer Comparison</h3>
            <div className="space-y-4">
              <div>
                <div className="flex justify-between items-center mb-2">
                  <span className="text-gray-600">Your Certificates</span>
                  <span className="font-bold text-blue-600">{analysis.peerComparison.userCertificates}</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div
                    className="bg-blue-600 h-2 rounded-full"
                    style={{ width: `${(analysis.peerComparison.userCertificates / analysis.peerComparison.topPerformer) * 100}%` }}
                  ></div>
                </div>
              </div>

              <div>
                <div className="flex justify-between items-center mb-2">
                  <span className="text-gray-600">Department Average</span>
                  <span className="font-bold text-gray-700">{analysis.peerComparison.departmentAverage}</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div
                    className="bg-gray-500 h-2 rounded-full"
                    style={{ width: `${(analysis.peerComparison.departmentAverage / analysis.peerComparison.topPerformer) * 100}%` }}
                  ></div>
                </div>
              </div>

              <div>
                <div className="flex justify-between items-center mb-2">
                  <span className="text-gray-600">Top Performer</span>
                  <span className="font-bold text-green-600">{analysis.peerComparison.topPerformer}</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div className="bg-green-600 h-2 rounded-full w-full"></div>
                </div>
              </div>

              <div className="mt-4 p-4 bg-blue-50 rounded-lg">
                <p className="text-sm text-gray-700">
                  <span className="font-semibold">Ranking:</span> {analysis.peerComparison.ranking}
                </p>
                <p className="text-sm text-gray-700 mt-1">
                  <span className="font-semibold">Percentile:</span> {analysis.peerComparison.percentile}th
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* AI Recommendations */}
        <div className="bg-white rounded-lg shadow-lg p-6 mb-8">
          <h3 className="text-lg font-semibold mb-4">AI-Powered Recommendations</h3>
          <div className="space-y-4">
            {analysis.recommendations.map((rec, index) => (
              <div key={index} className={`border-l-4 p-4 rounded ${getPriorityColor(rec.priority)}`}>
                <div className="flex justify-between items-start mb-2">
                  <h4 className="font-semibold text-lg">{rec.skill}</h4>
                  <span className={`px-3 py-1 rounded-full text-xs font-medium ${getPriorityColor(rec.priority)}`}>
                    {rec.priority} Priority
                  </span>
                </div>
                <p className="text-gray-700 mb-3">{rec.reason}</p>
                <div className="flex items-center text-sm text-gray-600 mb-2">
                  <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  Estimated Time: {rec.estimatedTime}
                </div>
                <div className="mt-2">
                  <p className="text-sm font-medium text-gray-700 mb-1">Suggested Topics:</p>
                  <div className="flex flex-wrap gap-2">
                    {rec.suggestions.map((suggestion, idx) => (
                      <span key={idx} className="px-2 py-1 bg-white rounded text-xs border">
                        {suggestion}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Stats Overview */}
        <div className="bg-white rounded-lg shadow-lg p-6">
          <h3 className="text-lg font-semibold mb-4">Learning Analytics</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="text-center p-4 bg-gray-50 rounded-lg">
              <p className="text-2xl font-bold text-blue-600">{analysis.features.totalCertificates}</p>
              <p className="text-sm text-gray-600 mt-1">Total Certificates</p>
            </div>
            <div className="text-center p-4 bg-gray-50 rounded-lg">
              <p className="text-2xl font-bold text-green-600">{analysis.features.uniqueCategories}</p>
              <p className="text-sm text-gray-600 mt-1">Unique Categories</p>
            </div>
            <div className="text-center p-4 bg-gray-50 rounded-lg">
              <p className="text-2xl font-bold text-purple-600">{analysis.features.growthRate}</p>
              <p className="text-sm text-gray-600 mt-1">Certs/Month</p>
            </div>
            <div className="text-center p-4 bg-gray-50 rounded-lg">
              <p className="text-2xl font-bold text-orange-600">{analysis.features.monthsActive}</p>
              <p className="text-sm text-gray-600 mt-1">Months Active</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MLAnalysis;
