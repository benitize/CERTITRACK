import React, { useState, useEffect } from 'react';
import { adminAPI, certificateAPI } from '../services/api';
import { getErrorMessage, debounce } from '../utils/helpers';
import StudentCard from '../components/StudentCard';
import CertificateCard from '../components/CertificateCard';

const TeacherDashboard = () => {
  const [students, setStudents] = useState([]);
  const [selectedStudent, setSelectedStudent] = useState(null);
  const [certificates, setCertificates] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [yearFilter, setYearFilter] = useState('all');
  const [verificationFilter, setVerificationFilter] = useState('all');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    fetchStudents();
  }, []);

  useEffect(() => {
    if (selectedStudent) {
      fetchStudentCertificates(selectedStudent._id);
    } else if (searchQuery) {
      performSearch();
    } else {
      fetchAllCertificates();
    }
  }, [selectedStudent, yearFilter, verificationFilter]);

  const fetchStudents = async () => {
    setLoading(true);
    try {
      const response = await adminAPI.getStudents();
      setStudents(response.data.students);
    } catch (error) {
      setError(getErrorMessage(error));
    } finally {
      setLoading(false);
    }
  };

  const fetchAllCertificates = async () => {
    setLoading(true);
    try {
      const params = {};
      if (yearFilter !== 'all') params.year = yearFilter;
      if (verificationFilter !== 'all') params.verificationStatus = verificationFilter;
      
      const response = await certificateAPI.getAllCertificates(params);
      setCertificates(response.data.certificates);
    } catch (error) {
      setError(getErrorMessage(error));
    } finally {
      setLoading(false);
    }
  };

  const fetchStudentCertificates = async (studentId) => {
    setLoading(true);
    try {
      const params = { studentId };
      if (yearFilter !== 'all') params.year = yearFilter;
      if (verificationFilter !== 'all') params.verificationStatus = verificationFilter;
      
      const response = await certificateAPI.getAllCertificates(params);
      setCertificates(response.data.certificates);
    } catch (error) {
      setError(getErrorMessage(error));
    } finally {
      setLoading(false);
    }
  };

  const performSearch = debounce(async () => {
    if (!searchQuery.trim()) {
      fetchAllCertificates();
      return;
    }

    setLoading(true);
    try {
      const params = { query: searchQuery };
      if (yearFilter !== 'all') params.year = yearFilter;
      if (verificationFilter !== 'all') params.verificationStatus = verificationFilter;
      
      const response = await certificateAPI.search(params);
      setCertificates(response.data.certificates);
    } catch (error) {
      setError(getErrorMessage(error));
    } finally {
      setLoading(false);
    }
  }, 500);

  useEffect(() => {
    if (searchQuery) {
      performSearch();
    }
  }, [searchQuery]);

  const handleStudentClick = (student) => {
    setSelectedStudent(student);
    setSearchQuery('');
  };

  const handleBackToStudents = () => {
    setSelectedStudent(null);
    setCertificates([]);
  };

  const handleDownloadCertificate = async (certId) => {
    try {
      const response = await certificateAPI.download(certId);
      const blob = new Blob([response.data]);
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `certificate-${certId}.pdf`;
      link.click();
    } catch (error) {
      alert(getErrorMessage(error));
    }
  };

  const handleVerifyCertificate = async (certId) => {
    try {
      await certificateAPI.verify(certId);
      setCertificates(certificates.map(cert => 
        cert._id === certId 
          ? { ...cert, verificationStatus: 'verified', verificationMethod: 'manual' }
          : cert
      ));
      alert('Certificate verified successfully');
    } catch (error) {
      alert(getErrorMessage(error));
    }
  };

  const handleClearSearch = () => {
    setSearchQuery('');
    setSelectedStudent(null);
    fetchAllCertificates();
  };

  const years = ['all', '2024', '2023', '2022', '2021', '2020'];

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Teacher Dashboard</h1>
          <p className="text-gray-600 mt-2">
            {selectedStudent 
              ? `Viewing certificates for ${selectedStudent.name}`
              : searchQuery 
                ? `Search results for "${searchQuery}"`
                : 'View students and their certificates'}
          </p>
        </div>

        {error && (
          <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
            {error}
          </div>
        )}

        {/* Search and Filters */}
        <div className="bg-white rounded-lg shadow p-6 mb-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            {/* NLP Search */}
            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Search Certificates (NLP)
              </label>
              <div className="relative">
                <input
                  type="text"
                  placeholder="e.g., Python course, React internship, Java backend"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                />
                {searchQuery && (
                  <button
                    onClick={handleClearSearch}
                    className="absolute right-2 top-2 text-gray-400 hover:text-gray-600"
                  >
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                    </svg>
                  </button>
                )}
              </div>
            </div>

            {/* Year Filter */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Filter by Year
              </label>
              <select
                value={yearFilter}
                onChange={(e) => setYearFilter(e.target.value)}
                className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
              >
                {years.map(year => (
                  <option key={year} value={year}>
                    {year === 'all' ? 'All Years' : year}
                  </option>
                ))}
              </select>
            </div>

            {/* Verification Filter */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Verification Status
              </label>
              <select
                value={verificationFilter}
                onChange={(e) => setVerificationFilter(e.target.value)}
                className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
              >
                <option value="all">All</option>
                <option value="verified">Verified</option>
                <option value="unverified">Unverified</option>
              </select>
            </div>
          </div>
        </div>

        {/* Back Button */}
        {selectedStudent && (
          <button
            onClick={handleBackToStudents}
            className="mb-6 flex items-center text-blue-600 hover:text-blue-800"
          >
            <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" />
            </svg>
            Back to Students
          </button>
        )}

        {/* Main Content */}
        {loading ? (
          <div className="text-center py-12">
            <div className="inline-block animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
            <p className="mt-4 text-gray-600">Loading...</p>
          </div>
        ) : (
          <>
            {/* Students Grid */}
            {!selectedStudent && !searchQuery && (
              <div>
                <h2 className="text-xl font-semibold mb-4">
                  All Students ({students.length})
                </h2>
                {students.length === 0 ? (
                  <div className="bg-white rounded-lg shadow p-12 text-center">
                    <svg className="w-16 h-16 text-gray-400 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" />
                    </svg>
                    <p className="text-gray-600">No students found</p>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                    {students.map((student, index) => (
                      <StudentCard
                        key={student._id}
                        student={student}
                        index={index + 1}
                        onClick={handleStudentClick}
                      />
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* Certificates Grid */}
            {(selectedStudent || searchQuery) && (
              <div>
                <div className="flex justify-between items-center mb-4">
                  <h2 className="text-xl font-semibold">
                    {certificates.length} Certificate{certificates.length !== 1 ? 's' : ''} Found
                  </h2>
                  {selectedStudent && (
                    <div className="text-sm text-gray-600">
                      <span className="font-medium">{selectedStudent.name}</span>
                      {selectedStudent.rollNumber && ` • ${selectedStudent.rollNumber}`}
                      {selectedStudent.department && ` • ${selectedStudent.department}`}
                    </div>
                  )}
                </div>

                {certificates.length === 0 ? (
                  <div className="bg-white rounded-lg shadow p-12 text-center">
                    <svg className="w-16 h-16 text-gray-400 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                    </svg>
                    <p className="text-gray-600">
                      {searchQuery 
                        ? 'No certificates match your search'
                        : 'This student has not uploaded any certificates yet'}
                    </p>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {certificates.map((cert) => (
                      <CertificateCard
                        key={cert._id}
                        certificate={cert}
                        showStudent={!selectedStudent}
                        userRole="teacher"
                        onDownload={handleDownloadCertificate}
                        onVerify={handleVerifyCertificate}
                      />
                    ))}
                  </div>
                )}
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
};

export default TeacherDashboard;
