// Random Forest ML Service with 5 Decision Trees
// Analyzes certificate data to predict career readiness and provide recommendations

// Feature extraction from certificates
const extractFeatures = (certificates) => {
  if (!certificates || certificates.length === 0) {
    return null;
  }

  const features = {
    totalCerts: certificates.length,
    programming: 0,
    backend: 0,
    frontend: 0,
    database: 0,
    cloud: 0,
    aiml: 0,
    mobile: 0,
    avgTimeGap: 0,
    growthRate: 0,
    diversityScore: 0,
    progressionScore: 0,
    monthsActive: 0,
    skillLevels: { beginner: 0, intermediate: 0, advanced: 0 }
  };

  // Count by category
  certificates.forEach(cert => {
    const cat = cert.category || 'Other';
    switch (cat) {
      case 'Programming':
        features.programming++;
        break;
      case 'Backend':
        features.backend++;
        break;
      case 'Frontend':
        features.frontend++;
        break;
      case 'Database':
        features.database++;
        break;
      case 'Cloud':
        features.cloud++;
        break;
      case 'AI/ML':
        features.aiml++;
        break;
      case 'Mobile':
        features.mobile++;
        break;
    }

    // Detect skill level from title/description
    const text = `${cert.title} ${cert.description}`.toLowerCase();
    if (text.includes('beginner') || text.includes('intro') || text.includes('basics')) {
      features.skillLevels.beginner++;
    } else if (text.includes('advanced') || text.includes('expert') || text.includes('master')) {
      features.skillLevels.advanced++;
    } else {
      features.skillLevels.intermediate++;
    }
  });

  // Calculate time-based features using issue dates
  const sortedByIssue = [...certificates]
    .filter(c => c.issueDate)
    .sort((a, b) => new Date(a.issueDate) - new Date(b.issueDate));

  if (sortedByIssue.length > 1) {
    const firstDate = new Date(sortedByIssue[0].issueDate);
    const lastDate = new Date(sortedByIssue[sortedByIssue.length - 1].issueDate);
    
    // Months active
    features.monthsActive = Math.max(1, 
      (lastDate - firstDate) / (1000 * 60 * 60 * 24 * 30)
    );

    // Average time gap between certificates
    let totalGap = 0;
    for (let i = 1; i < sortedByIssue.length; i++) {
      const gap = (new Date(sortedByIssue[i].issueDate) - 
                   new Date(sortedByIssue[i-1].issueDate)) / 
                   (1000 * 60 * 60 * 24); // days
      totalGap += gap;
    }
    features.avgTimeGap = totalGap / (sortedByIssue.length - 1);

    // Growth rate (certificates per month)
    features.growthRate = certificates.length / features.monthsActive;
  }

  // Diversity score (unique categories / 8)
  const uniqueCategories = new Set();
  if (features.programming > 0) uniqueCategories.add('programming');
  if (features.backend > 0) uniqueCategories.add('backend');
  if (features.frontend > 0) uniqueCategories.add('frontend');
  if (features.database > 0) uniqueCategories.add('database');
  if (features.cloud > 0) uniqueCategories.add('cloud');
  if (features.aiml > 0) uniqueCategories.add('aiml');
  if (features.mobile > 0) uniqueCategories.add('mobile');
  features.diversityScore = uniqueCategories.size / 7;

  // Progression score (beginner -> intermediate -> advanced trajectory)
  const total = features.skillLevels.beginner + 
                features.skillLevels.intermediate + 
                features.skillLevels.advanced;
  if (total > 0) {
    features.progressionScore = 
      (features.skillLevels.intermediate * 0.5 + 
       features.skillLevels.advanced * 1.0) / total;
  }

  return features;
};

// Decision Tree 1: Certificate Volume Analysis (5-25 points)
const decisionTree1 = (features) => {
  if (features.totalCerts >= 20) return 25;
  if (features.totalCerts >= 15) return 20;
  if (features.totalCerts >= 10) return 15;
  if (features.totalCerts >= 5) return 10;
  return 5;
};

// Decision Tree 2: Skill Diversity Analysis (0-20 points)
const decisionTree2 = (features) => {
  const score = features.diversityScore * 20;
  if (score >= 15) return 20;
  if (score >= 10) return 15;
  if (score >= 5) return 10;
  return score;
};

// Decision Tree 3: Learning Progression Analysis (0-25 points)
const decisionTree3 = (features) => {
  const score = features.progressionScore * 25;
  
  // Bonus for having all skill levels
  if (features.skillLevels.beginner > 0 && 
      features.skillLevels.intermediate > 0 && 
      features.skillLevels.advanced > 0) {
    return Math.min(25, score + 5);
  }
  
  return score;
};

// Decision Tree 4: Growth Rate Consistency (0-15 points)
const decisionTree4 = (features) => {
  // Consistent growth (not too slow, not too fast)
  if (features.growthRate >= 1.5 && features.growthRate <= 3) return 15;
  if (features.growthRate >= 1 && features.growthRate <= 4) return 12;
  if (features.growthRate >= 0.5 && features.growthRate <= 5) return 9;
  if (features.growthRate > 0) return 5;
  return 0;
};

// Decision Tree 5: Specialization Bonuses (0-15 points)
const decisionTree5 = (features) => {
  let score = 0;
  
  // Full Stack Bonus
  if (features.backend >= 2 && features.frontend >= 2 && features.database >= 1) {
    score += 5;
  }
  
  // Cloud Native Bonus
  if (features.cloud >= 3) {
    score += 4;
  }
  
  // AI/ML Specialization
  if (features.aiml >= 3) {
    score += 4;
  }
  
  // Deep specialization in any area
  const maxCategoryCount = Math.max(
    features.backend, features.frontend, features.database,
    features.cloud, features.aiml, features.mobile
  );
  if (maxCategoryCount >= 5) {
    score += 3;
  }
  
  // Versatility bonus
  if (features.diversityScore >= 0.7) {
    score += 2;
  }
  
  return Math.min(15, score);
};

// Calculate Career Readiness Score using Random Forest
const calculateCareerReadiness = (features) => {
  const tree1Score = decisionTree1(features);
  const tree2Score = decisionTree2(features);
  const tree3Score = decisionTree3(features);
  const tree4Score = decisionTree4(features);
  const tree5Score = decisionTree5(features);
  
  // Ensemble: Average of all trees
  const totalScore = tree1Score + tree2Score + tree3Score + tree4Score + tree5Score;
  
  return {
    score: Math.round(totalScore),
    breakdown: {
      volume: tree1Score,
      diversity: tree2Score,
      progression: tree3Score,
      consistency: tree4Score,
      specialization: tree5Score
    }
  };
};

// Calculate Skill Level Score
const calculateSkillLevel = (features) => {
  let score = 0;
  
  // Volume component (40 points)
  score += Math.min(40, features.totalCerts * 2);
  
  // Diversity component (30 points)
  score += features.diversityScore * 30;
  
  // Progression component (30 points)
  score += features.progressionScore * 30;
  
  return Math.round(Math.min(100, score));
};

// Predict Career Role
const predictCareerRole = (features) => {
  const roles = [];
  
  // Backend Developer
  if (features.backend >= 3 && features.database >= 2) {
    const confidence = Math.min(95, 60 + (features.backend * 5) + (features.database * 3));
    roles.push({ role: 'Backend Developer', confidence: Math.round(confidence) });
  }
  
  // Frontend Developer
  if (features.frontend >= 3) {
    const confidence = Math.min(95, 60 + (features.frontend * 8));
    roles.push({ role: 'Frontend Developer', confidence: Math.round(confidence) });
  }
  
  // Full Stack Developer
  if (features.backend >= 2 && features.frontend >= 2) {
    const confidence = Math.min(95, 55 + (features.backend * 4) + (features.frontend * 4) + (features.database * 2));
    roles.push({ role: 'Full Stack Developer', confidence: Math.round(confidence) });
  }
  
  // Cloud Engineer
  if (features.cloud >= 2) {
    const confidence = Math.min(95, 55 + (features.cloud * 10));
    roles.push({ role: 'Cloud Engineer', confidence: Math.round(confidence) });
  }
  
  // Data Scientist / ML Engineer
  if (features.aiml >= 2) {
    const confidence = Math.min(95, 55 + (features.aiml * 10));
    roles.push({ role: 'Data Scientist / ML Engineer', confidence: Math.round(confidence) });
  }
  
  // Mobile App Developer
  if (features.mobile >= 2) {
    const confidence = Math.min(95, 55 + (features.mobile * 10));
    roles.push({ role: 'Mobile App Developer', confidence: Math.round(confidence) });
  }
  
  // Software Engineer (general)
  if (features.programming >= 3) {
    const confidence = Math.min(85, 50 + (features.programming * 5));
    roles.push({ role: 'Software Engineer', confidence: Math.round(confidence) });
  }
  
  // Sort by confidence
  roles.sort((a, b) => b.confidence - a.confidence);
  
  return roles.length > 0 ? roles : [{ role: 'Entry-Level Developer', confidence: 40 }];
};

// Generate AI Recommendations
const generateRecommendations = (features) => {
  const recommendations = [];
  
  // Skill gap analysis
  if (features.backend < 2) {
    recommendations.push({
      skill: 'Backend Development',
      priority: 'High',
      reason: 'Essential for full-stack proficiency',
      suggestedCourses: ['Node.js & Express', 'RESTful API Design', 'Database Management'],
      estimatedTime: '2-3 months'
    });
  }
  
  if (features.frontend < 2) {
    recommendations.push({
      skill: 'Frontend Development',
      priority: 'High',
      reason: 'Critical for modern web development',
      suggestedCourses: ['React.js Fundamentals', 'Modern CSS & Responsive Design', 'JavaScript ES6+'],
      estimatedTime: '2-3 months'
    });
  }
  
  if (features.database < 1) {
    recommendations.push({
      skill: 'Database Management',
      priority: 'High',
      reason: 'Required for data-driven applications',
      suggestedCourses: ['SQL Basics', 'MongoDB', 'Database Design'],
      estimatedTime: '1-2 months'
    });
  }
  
  if (features.cloud < 1) {
    recommendations.push({
      skill: 'Cloud Computing',
      priority: 'Medium',
      reason: 'Industry standard for deployment',
      suggestedCourses: ['AWS Fundamentals', 'Docker & Containers', 'CI/CD Basics'],
      estimatedTime: '2-3 months'
    });
  }
  
  if (features.diversityScore < 0.4) {
    recommendations.push({
      skill: 'Diversify Your Skills',
      priority: 'Medium',
      reason: 'Broader skill set increases job opportunities',
      suggestedCourses: ['Explore new technologies', 'Cross-functional learning'],
      estimatedTime: 'Ongoing'
    });
  }
  
  if (features.skillLevels.advanced < 2) {
    recommendations.push({
      skill: 'Advanced Specialization',
      priority: 'Low',
      reason: 'Stand out with deep expertise',
      suggestedCourses: ['Advanced architecture patterns', 'Performance optimization', 'System design'],
      estimatedTime: '3-6 months'
    });
  }
  
  return recommendations;
};

// Main ML Analysis Function
exports.analyzeGrowth = (certificates) => {
  const features = extractFeatures(certificates);
  
  if (!features) {
    return {
      error: 'Insufficient data for analysis',
      message: 'Please upload at least one certificate to see your growth analysis.'
    };
  }
  
  const careerReadiness = calculateCareerReadiness(features);
  const skillLevel = calculateSkillLevel(features);
  const careerRoles = predictCareerRole(features);
  const recommendations = generateRecommendations(features);
  
  return {
    features,
    predictions: {
      skillLevelScore: skillLevel,
      careerReadinessScore: careerReadiness.score,
      careerReadinessBreakdown: careerReadiness.breakdown,
      predictedRoles: careerRoles,
      recommendations
    },
    summary: {
      totalCertificates: features.totalCerts,
      learningConsistency: features.growthRate > 1 ? 'Excellent' : features.growthRate > 0.5 ? 'Good' : 'Needs Improvement',
      skillDiversity: features.diversityScore > 0.6 ? 'High' : features.diversityScore > 0.3 ? 'Moderate' : 'Low',
      topRole: careerRoles[0].role,
      readinessLevel: careerReadiness.score >= 80 ? 'Job Ready' : 
                      careerReadiness.score >= 60 ? 'Nearly Ready' : 
                      careerReadiness.score >= 40 ? 'In Progress' : 'Getting Started'
    }
  };
};

// Generate growth chart data (cumulative over time using issue dates)
exports.generateGrowthChart = (certificates) => {
  if (!certificates || certificates.length === 0) {
    return [];
  }
  
  const sorted = [...certificates]
    .filter(c => c.issueDate)
    .sort((a, b) => new Date(a.issueDate) - new Date(b.issueDate));
  
  const chartData = [];
  let cumulative = 0;
  
  sorted.forEach(cert => {
    cumulative++;
    chartData.push({
      date: new Date(cert.issueDate).toLocaleDateString(),
      count: cumulative,
      category: cert.category || 'Other'
    });
  });
  
  return chartData;
};
