// Random Forest-based ML Growth Analysis Service

// Extract features from certificates
function extractFeatures(certificates) {
  if (!certificates || certificates.length === 0) {
    return null;
  }

  // Sort by issue date
  const sorted = certificates.sort((a, b) => new Date(a.issueDate) - new Date(b.issueDate));
  
  // Category counts
  const categoryCounts = {
    Programming: 0,
    Backend: 0,
    Frontend: 0,
    Database: 0,
    Cloud: 0,
    'AI/ML': 0,
    Mobile: 0,
    Other: 0
  };

  certificates.forEach(cert => {
    if (categoryCounts.hasOwnProperty(cert.category)) {
      categoryCounts[cert.category]++;
    }
  });

  // Calculate time gaps between certificates (using issue dates)
  const timeGaps = [];
  for (let i = 1; i < sorted.length; i++) {
    const gap = (new Date(sorted[i].issueDate) - new Date(sorted[i-1].issueDate)) / (1000 * 60 * 60 * 24); // days
    timeGaps.push(gap);
  }
  
  const avgTimeGap = timeGaps.length > 0 ? timeGaps.reduce((a, b) => a + b, 0) / timeGaps.length : 0;

  // Months active (from first to last issue date)
  const firstDate = new Date(sorted[0].issueDate);
  const lastDate = new Date(sorted[sorted.length - 1].issueDate);
  const monthsActive = Math.max(1, (lastDate - firstDate) / (1000 * 60 * 60 * 24 * 30));

  // Growth rate (certificates per month)
  const growthRate = certificates.length / monthsActive;

  // Diversity score (unique categories / 8)
  const uniqueCategories = Object.values(categoryCounts).filter(count => count > 0).length;
  const diversityScore = uniqueCategories / 8;

  // Skill level distribution
  const skillLevels = { Beginner: 0, Intermediate: 0, Advanced: 0 };
  certificates.forEach(cert => {
    if (skillLevels.hasOwnProperty(cert.skillLevel)) {
      skillLevels[cert.skillLevel]++;
    }
  });

  // Progression score (trajectory from Beginner to Advanced)
  const progressionScore = (skillLevels.Advanced * 3 + skillLevels.Intermediate * 2 + skillLevels.Beginner * 1) / certificates.length;

  return {
    totalCount: certificates.length,
    categoryCounts,
    avgTimeGap,
    growthRate,
    diversityScore,
    progressionScore,
    monthsActive,
    skillLevels,
    uniqueCategories
  };
}

// Random Forest Decision Trees (5 trees)
function decisionTree1_VolumeScore(features) {
  // Tree 1: Certificate volume (0-25 points)
  const count = features.totalCount;
  
  if (count >= 20) return 25;
  if (count >= 15) return 20;
  if (count >= 10) return 15;
  if (count >= 5) return 10;
  return 5;
}

function decisionTree2_DiversityScore(features) {
  // Tree 2: Skill diversity (0-20 points)
  const diversity = features.diversityScore;
  const unique = features.uniqueCategories;
  
  if (unique >= 6) return 20;
  if (unique >= 5) return 16;
  if (unique >= 4) return 12;
  if (unique >= 3) return 8;
  if (unique >= 2) return 5;
  return 2;
}

function decisionTree3_ProgressionScore(features) {
  // Tree 3: Learning progression (0-25 points)
  const progression = features.progressionScore;
  const advanced = features.skillLevels.Advanced;
  
  if (progression >= 2.5 && advanced >= 3) return 25;
  if (progression >= 2.0) return 20;
  if (progression >= 1.5) return 15;
  if (progression >= 1.2) return 10;
  return 5;
}

function decisionTree4_ConsistencyScore(features) {
  // Tree 4: Growth rate consistency (0-15 points)
  const growthRate = features.growthRate;
  const avgTimeGap = features.avgTimeGap;
  
  if (growthRate >= 2 && avgTimeGap < 45) return 15; // 2+ certs per month, consistent
  if (growthRate >= 1.5) return 12;
  if (growthRate >= 1) return 9;
  if (growthRate >= 0.5) return 6;
  return 3;
}

function decisionTree5_SpecializationScore(features) {
  // Tree 5: Specialization bonus (0-15 points)
  const counts = features.categoryCounts;
  const maxCategory = Math.max(...Object.values(counts));
  
  if (maxCategory >= 5 && features.uniqueCategories >= 3) return 15; // Specialized + diverse
  if (maxCategory >= 5) return 12; // Strong specialization
  if (maxCategory >= 3) return 9;
  if (maxCategory >= 2) return 6;
  return 3;
}

// Calculate Career Readiness Score (Random Forest ensemble)
function calculateCareerReadiness(features) {
  const tree1 = decisionTree1_VolumeScore(features);
  const tree2 = decisionTree2_DiversityScore(features);
  const tree3 = decisionTree3_ProgressionScore(features);
  const tree4 = decisionTree4_ConsistencyScore(features);
  const tree5 = decisionTree5_SpecializationScore(features);
  
  // Ensemble average
  const totalScore = tree1 + tree2 + tree3 + tree4 + tree5;
  
  return {
    score: Math.min(100, totalScore),
    breakdown: {
      volume: tree1,
      diversity: tree2,
      progression: tree3,
      consistency: tree4,
      specialization: tree5
    }
  };
}

// Calculate Skill Level Score
function calculateSkillLevel(features) {
  const { totalCount, uniqueCategories, skillLevels, progressionScore } = features;
  
  let score = 0;
  
  // Base score from count (0-30)
  score += Math.min(30, totalCount * 2);
  
  // Diversity bonus (0-25)
  score += Math.min(25, uniqueCategories * 4);
  
  // Progression bonus (0-25)
  score += Math.min(25, progressionScore * 10);
  
  // Advanced skills bonus (0-20)
  score += Math.min(20, skillLevels.Advanced * 4);
  
  return Math.min(100, Math.round(score));
}

// Predict career role
function predictCareerRole(features) {
  const { categoryCounts } = features;
  const roles = [];
  
  // Backend Developer
  if (categoryCounts.Backend >= 3 && categoryCounts.Database >= 2) {
    const confidence = Math.min(95, 60 + categoryCounts.Backend * 5 + categoryCounts.Database * 3);
    roles.push({ role: 'Backend Developer', confidence });
  }
  
  // Frontend Developer
  if (categoryCounts.Frontend >= 3) {
    const confidence = Math.min(95, 65 + categoryCounts.Frontend * 8);
    roles.push({ role: 'Frontend Developer', confidence });
  }
  
  // Full Stack Developer
  if (categoryCounts.Backend >= 2 && categoryCounts.Frontend >= 2) {
    const confidence = Math.min(95, 70 + (categoryCounts.Backend + categoryCounts.Frontend) * 3);
    roles.push({ role: 'Full Stack Developer', confidence });
  }
  
  // Cloud Engineer
  if (categoryCounts.Cloud >= 2) {
    const confidence = Math.min(90, 55 + categoryCounts.Cloud * 10);
    roles.push({ role: 'Cloud Engineer', confidence });
  }
  
  // Data Scientist/ML Engineer
  if (categoryCounts['AI/ML'] >= 2) {
    const confidence = Math.min(90, 60 + categoryCounts['AI/ML'] * 10);
    roles.push({ role: 'Data Scientist/ML Engineer', confidence });
  }
  
  // Mobile App Developer
  if (categoryCounts.Mobile >= 2) {
    const confidence = Math.min(90, 55 + categoryCounts.Mobile * 12);
    roles.push({ role: 'Mobile App Developer', confidence });
  }
  
  // Sort by confidence
  roles.sort((a, b) => b.confidence - a.confidence);
  
  if (roles.length === 0) {
    return [{ role: 'Emerging Developer', confidence: 50 }];
  }
  
  return roles;
}

// Generate AI recommendations
function generateRecommendations(features) {
  const { categoryCounts, totalCount, uniqueCategories } = features;
  const recommendations = [];
  
  // Analyze skill gaps
  const categoryEntries = Object.entries(categoryCounts).sort((a, b) => b[1] - a[1]);
  const topCategory = categoryEntries[0][0];
  const topCount = categoryEntries[0][1];
  
  // Recommendation 1: Strengthen weak areas
  if (categoryCounts.Database < 2 && topCategory !== 'Database') {
    recommendations.push({
      skill: 'Database Management',
      priority: 'High',
      reason: 'Essential for most development roles',
      estimatedTime: '4-6 weeks',
      suggestions: ['SQL Fundamentals', 'MongoDB Basics', 'Database Design']
    });
  }
  
  // Recommendation 2: Diversify if too specialized
  if (uniqueCategories < 3 && totalCount >= 5) {
    recommendations.push({
      skill: 'Skill Diversification',
      priority: 'High',
      reason: 'Broaden your technical expertise',
      estimatedTime: '2-3 months',
      suggestions: ['Explore Cloud Technologies', 'Learn Frontend Frameworks', 'Study DevOps Practices']
    });
  }
  
  // Recommendation 3: Deepen specialization
  if (topCount >= 3 && topCount < 6) {
    recommendations.push({
      skill: `Advanced ${topCategory}`,
      priority: 'Medium',
      reason: `Build expertise in your strongest area (${topCategory})`,
      estimatedTime: '6-8 weeks',
      suggestions: [`${topCategory} Best Practices`, `${topCategory} Architecture`, `${topCategory} Optimization`]
    });
  }
  
  // Recommendation 4: Cloud skills
  if (categoryCounts.Cloud === 0) {
    recommendations.push({
      skill: 'Cloud Computing',
      priority: 'High',
      reason: 'Critical skill for modern software development',
      estimatedTime: '3-4 weeks',
      suggestions: ['AWS Fundamentals', 'Docker Basics', 'CI/CD Introduction']
    });
  }
  
  // Recommendation 5: Advanced level progression
  if (features.skillLevels.Advanced < 2 && totalCount >= 8) {
    recommendations.push({
      skill: 'Advanced Certifications',
      priority: 'Medium',
      reason: 'Progress to advanced-level courses',
      estimatedTime: '8-12 weeks',
      suggestions: ['Advanced Algorithms', 'System Design', 'Architecture Patterns']
    });
  }
  
  return recommendations.slice(0, 5); // Top 5 recommendations
}

// Generate growth chart data
function generateGrowthChart(certificates) {
  if (!certificates || certificates.length === 0) {
    return [];
  }

  // Sort by issue date
  const sorted = certificates.sort((a, b) => new Date(a.issueDate) - new Date(b.issueDate));
  
  const chartData = [];
  let cumulative = 0;
  
  sorted.forEach(cert => {
    cumulative++;
    chartData.push({
      date: new Date(cert.issueDate).toISOString().split('T')[0],
      count: cumulative,
      category: cert.category
    });
  });
  
  return chartData;
}

// Peer comparison (simulated - in real app, compare with other students in same department)
function generatePeerComparison(features, userDepartment) {
  // Simulated peer data
  const departmentAverage = 8;
  const topPerformer = 25;
  const userCount = features.totalCount;
  
  const percentile = Math.min(99, Math.round((userCount / topPerformer) * 100));
  
  return {
    userCertificates: userCount,
    departmentAverage: departmentAverage,
    topPerformer: topPerformer,
    percentile: percentile,
    ranking: percentile >= 75 ? 'Top 25%' : percentile >= 50 ? 'Top 50%' : 'Below Average'
  };
}

// Main ML Analysis function
function performMLAnalysis(certificates, userDepartment) {
  const features = extractFeatures(certificates);
  
  if (!features) {
    return {
      error: 'Insufficient data for analysis',
      message: 'Upload at least one certificate to view growth analysis'
    };
  }
  
  const careerReadiness = calculateCareerReadiness(features);
  const skillLevel = calculateSkillLevel(features);
  const careerRoles = predictCareerRole(features);
  const recommendations = generateRecommendations(features);
  const growthChart = generateGrowthChart(certificates);
  const peerComparison = generatePeerComparison(features, userDepartment);
  
  return {
    skillLevelScore: skillLevel,
    careerReadinessScore: careerReadiness.score,
    careerReadinessBreakdown: careerReadiness.breakdown,
    predictedRoles: careerRoles,
    recommendations: recommendations,
    growthChart: growthChart,
    peerComparison: peerComparison,
    features: {
      totalCertificates: features.totalCount,
      categoryCounts: features.categoryCounts,
      uniqueCategories: features.uniqueCategories,
      averageTimeGap: Math.round(features.avgTimeGap),
      growthRate: features.growthRate.toFixed(2),
      monthsActive: Math.round(features.monthsActive),
      skillLevels: features.skillLevels
    }
  };
}

module.exports = {
  performMLAnalysis,
  extractFeatures,
  calculateCareerReadiness,
  calculateSkillLevel,
  predictCareerRole,
  generateRecommendations
};
