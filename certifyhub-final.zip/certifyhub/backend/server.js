const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const http = require('http');
const socketIO = require('socket.io');
const path = require('path');
require('dotenv').config();

const app = express();
const server = http.createServer(app);
const io = socketIO(server, {
  cors: {
    origin: process.env.CLIENT_URL || 'http://localhost:3000',
    methods: ['GET', 'POST', 'PUT', 'DELETE'],
    credentials: true
  }
});

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve uploaded files
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// Database connection
mongoose.connect(process.env.MONGODB_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true
})
.then(() => console.log('✅ MongoDB connected successfully'))
.catch((err) => console.error('❌ MongoDB connection error:', err));

// Socket.io for real-time notifications
const User = require('./models/User');
const Certificate = require('./models/Certificate');

// Store connected users with their socket IDs
const connectedUsers = new Map();

io.on('connection', (socket) => {
  console.log('🔌 New client connected:', socket.id);
  
  // User joins with their ID
  socket.on('user:join', (userId) => {
    connectedUsers.set(userId, socket.id);
    socket.userId = userId;
    console.log(`👤 User ${userId} joined with socket ${socket.id}`);
  });
  
  // User leaves
  socket.on('disconnect', () => {
    if (socket.userId) {
      connectedUsers.delete(socket.userId);
      console.log(`👤 User ${socket.userId} disconnected`);
    }
  });
  
  // Mark notification as read
  socket.on('notification:read', async ({ userId, notificationId }) => {
    try {
      const user = await User.findById(userId);
      if (user) {
        const notification = user.notifications.id(notificationId);
        if (notification) {
          notification.isRead = true;
          await user.save();
          socket.emit('notification:updated', { notificationId, isRead: true });
        }
      }
    } catch (error) {
      console.error('Error marking notification as read:', error);
    }
  });
  
  // Mark all notifications as read
  socket.on('notification:read-all', async ({ userId }) => {
    try {
      const user = await User.findById(userId);
      if (user) {
        user.notifications.forEach(notification => {
          notification.isRead = true;
        });
        await user.save();
        socket.emit('notification:all-read');
      }
    } catch (error) {
      console.error('Error marking all notifications as read:', error);
    }
  });
  
  // Delete notification
  socket.on('notification:delete', async ({ userId, notificationId }) => {
    try {
      const user = await User.findById(userId);
      if (user) {
        user.notifications = user.notifications.filter(
          n => n._id.toString() !== notificationId
        );
        await user.save();
        socket.emit('notification:deleted', { notificationId });
      }
    } catch (error) {
      console.error('Error deleting notification:', error);
    }
  });
});

// Make io accessible to routes
app.set('io', io);
app.set('connectedUsers', connectedUsers);

// Helper function to send notifications
async function sendNotificationToTeachers(certificate) {
  try {
    // Get all approved teachers
    const teachers = await User.find({ role: 'teacher', isApproved: true });
    
    // Populate student info if not already populated
    if (!certificate.student.name) {
      await certificate.populate('student', 'name rollNumber department');
    }
    
    const notification = {
      message: `${certificate.student.name} uploaded a new certificate: ${certificate.title}`,
      certificateId: certificate._id,
      studentName: certificate.student.name,
      isRead: false,
      createdAt: new Date()
    };
    
    // Add notification to each teacher and emit via socket
    for (const teacher of teachers) {
      teacher.notifications.push(notification);
      await teacher.save();
      
      // Send real-time notification if teacher is connected
      const socketId = connectedUsers.get(teacher._id.toString());
      if (socketId) {
        io.to(socketId).emit('notification:new', {
          notification: teacher.notifications[teacher.notifications.length - 1],
          unreadCount: teacher.notifications.filter(n => !n.isRead).length
        });
      }
    }
    
    console.log(`✉️ Notifications sent to ${teachers.length} teachers`);
  } catch (error) {
    console.error('Error sending notifications:', error);
  }
}

// Export for use in routes
app.set('sendNotificationToTeachers', sendNotificationToTeachers);

// Routes
app.use('/api/auth', require('./routes/auth'));
app.use('/api/certificates', require('./routes/certificates'));
app.use('/api/admin', require('./routes/admin'));
app.use('/api/ml', require('./routes/ml'));

// Notification routes
const notificationRouter = express.Router();
const { auth } = require('./middleware/auth');

// Get user's notifications
notificationRouter.get('/', auth, async (req, res) => {
  try {
    const user = await User.findById(req.userId).select('notifications');
    res.json({
      notifications: user.notifications.sort((a, b) => b.createdAt - a.createdAt),
      unreadCount: user.notifications.filter(n => !n.isRead).length
    });
  } catch (error) {
    console.error('Get notifications error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.use('/api/notifications', notificationRouter);

// Certificate upload notification middleware
app.post('/api/certificates/upload', async (req, res, next) => {
  // Store original res.json
  const originalJson = res.json.bind(res);
  
  // Override res.json
  res.json = function(data) {
    if (data.certificate && data.certificate.notifyTeachers) {
      const sendNotifications = app.get('sendNotificationToTeachers');
      sendNotifications(data.certificate);
    }
    return originalJson(data);
  };
  
  next();
});

// Health check
app.get('/health', (req, res) => {
  res.json({ 
    status: 'OK', 
    timestamp: new Date(),
    database: mongoose.connection.readyState === 1 ? 'connected' : 'disconnected'
  });
});

// 404 handler
app.use((req, res) => {
  res.status(404).json({ error: 'Route not found' });
});

// Error handler
app.use((err, req, res, next) => {
  console.error('Error:', err);
  res.status(500).json({ 
    error: 'Internal server error',
    message: process.env.NODE_ENV === 'development' ? err.message : undefined
  });
});

const PORT = process.env.PORT || 5000;

server.listen(PORT, () => {
  console.log(`🚀 Server running on port ${PORT}`);
  console.log(`📡 Socket.io ready for real-time notifications`);
});

module.exports = { app, io };
