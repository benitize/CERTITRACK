# CertifyHub — Improvements Documentation

---

## Improvement 1 — Areas of Interest + AI Recommendation Gap Analysis

### What changed
| File | Change |
|------|--------|
| `backend/models/User.js` | Added `areasOfInterest: [String]` field to student schema |
| `backend/routes/auth.js` | New `PUT /api/auth/interests` endpoint to save interests; `PUT /api/auth/teacher-department` for teacher dept |
| `backend/services/mlService.js` | `extractFeatures()` now accepts `areasOfInterest[]`; `generateRecommendations()` runs gap analysis |
| `frontend/src/pages/StudentDashboard.js` | New **"My Interests"** tab with chip selector, save button, live gap indicators |
| `frontend/src/pages/MLAnalysis.js` | Recommendations now show 🔥 **Interest Gap** and ⭐ **Your Interest** badges |

### How it works
1. Student opens **My Interests** tab → selects categories they care about (e.g., `AI/ML`, `Cloud`).
2. On save, interests are stored in `user.areasOfInterest`.
3. When AI Analysis runs, `generateRecommendations(features)` checks:
   - **Interest Gap** = interest selected BUT `categoryCounts[interest] === 0` → High Priority recommendation.
   - **Interest Advance** = interest selected AND has certificates → suggest advanced courses in that area.
4. Interest-gap recommendations are **inserted first** (Priority 0) before market-gap recommendations.

---

## Improvement 2 — OCR-Based Automatic Certificate Verification

### What changed
| File | Change |
|------|--------|
| `backend/services/verificationService.js` | Fully rewritten — OCR pipeline using Tesseract.js + jsQR + pdf-parse |
| `backend/controllers/certificateController.js` | Calls `autoVerifyCertificate()` on every upload; returns extracted data in response |
| `backend/package.json` | Added `tesseract.js`, `jimp`, `jsqr`, `pdf-parse` |

### OCR Verification Pipeline
```
Upload file (PDF / JPG / PNG)
        │
        ├─ PDF? → pdf-parse → extract raw text
        ├─ Image? → Tesseract.js OCR → extract raw text
        │
        ├─ Image? → Jimp decode pixels → jsQR → QR code string
        │
        ├─ Parse cert ID from OCR text using issuer-specific regex
        │   Coursera:  /([A-Z0-9]{8,20})/
        │   Udemy:     /UC-([A-Za-z0-9\-]{30,40})/
        │   LinkedIn:  /([A-Za-z0-9]{30,50})/
        │   Google:    /([A-Za-z0-9\-]{16,40})/
        │   Microsoft: /([A-Za-z0-9\-]{36})/  (UUID)
        │   AWS:       /([A-Z0-9]{12,20})/
        │
        └─ HTTP HEAD request to issuer verification URL
            Coursera:  https://www.coursera.org/verify/{id}
            Udemy:     https://www.udemy.com/certificate/{id}/
            LinkedIn:  https://www.linkedin.com/learning/certificates/{id}
            Google:    https://skillshop.credential.net/verify/{id}
            Microsoft: https://learn.microsoft.com/api/credentials/share/{id}
            AWS:       https://aws.amazon.com/verification/{id}
            → HTTP 200-399 = verified ✅
            → HTTP 400+    = unverified ❌
```

Install new dependencies:
```bash
cd backend
npm install tesseract.js jimp jsqr pdf-parse
```

---

## Improvement 3 — Months Active Based on Actual Duration

### What changed
| File | Change |
|------|--------|
| `backend/models/Certificate.js` | Added `courseStartDate`, `courseEndDate`, `internshipStartDate`, `internshipEndDate`, `certificateType` |
| `backend/services/mlService.js` | `extractFeatures()` sums per-certificate durations when dates available; legacy fallback retained |
| `backend/controllers/certificateController.js` | Accepts and saves all duration fields from upload form |
| `frontend/src/pages/StudentDashboard.js` | Upload form now shows start/end date fields based on `certificateType` |

### Formula — Months Active (Updated)

**Old formula (inaccurate):**
```
monthsActive = (lastIssueDate − firstIssueDate) / (30 days)
```
This only measured the calendar span between first and last certificate — if a student did a 6-month internship it wasn't reflected.

**New formula:**
```
If any certificate has courseStartDate or internshipStartDate:
  monthsActive = Σ certDurationMonths(cert_i)   for i = 1..n

  where certDurationMonths(cert) =
    max(0.25,  (endDate − startDate) / 30 days)
    endDate  = courseEndDate || internshipEndDate || issueDate
    startDate = courseStartDate || internshipStartDate

Else (no duration data — legacy fallback):
  monthsActive = max(1, (lastIssueDate − firstIssueDate) / 30 days)
```

This means a 3-month internship + 1-month course = **4 months active**, accurately.

---

## Improvement 4 — Random Forest Algorithm Formulas

The system uses a **Random Forest ensemble of 5 decision trees**. Each tree is an independent scoring function; their outputs are summed (aggregated by addition, not voting, since this is a regression task).

### Feature Extraction

| Feature | Formula |
|---------|---------|
| `totalCount` | count of all certificates |
| `avgTimeGap` | mean of consecutive issueDate gaps in days: `Σ(date[i]−date[i−1]) / (n−1)` |
| `monthsActive` | See Improvement 3 above |
| `growthRate` | `totalCount / monthsActive` (certificates per month) |
| `uniqueCategories` | count of categories with count > 0 (max 8) |
| `diversityScore` | `uniqueCategories / 8` |
| `progressionScore` | `(Advanced×3 + Intermediate×2 + Beginner×1) / totalCount` |

### Tree 1 — Volume Score (max 25 pts)
```
if totalCount ≥ 20 → 25
if totalCount ≥ 15 → 20
if totalCount ≥ 10 → 15
if totalCount ≥  5 → 10
else               →  5
```

### Tree 2 — Diversity Score (max 20 pts)
```
if uniqueCategories ≥ 6 → 20
if uniqueCategories ≥ 5 → 16
if uniqueCategories ≥ 4 → 12
if uniqueCategories ≥ 3 →  8
if uniqueCategories ≥ 2 →  5
else                    →  2
```

### Tree 3 — Progression Score (max 25 pts)
```
if progressionScore ≥ 2.5 AND Advanced ≥ 3 → 25
if progressionScore ≥ 2.0                  → 20
if progressionScore ≥ 1.5                  → 15
if progressionScore ≥ 1.2                  → 10
else                                       →  5
```

### Tree 4 — Consistency Score (max 15 pts)
```
if growthRate ≥ 2.0 AND avgTimeGap < 45 days → 15
if growthRate ≥ 1.5                          → 12
if growthRate ≥ 1.0                          →  9
if growthRate ≥ 0.5                          →  6
else                                         →  3
```

### Tree 5 — Specialization Score (max 15 pts)
```
maxCategoryCount = max(categoryCounts values)

if maxCategoryCount ≥ 5 AND uniqueCategories ≥ 3 → 15
if maxCategoryCount ≥ 5                           → 12
if maxCategoryCount ≥ 3                           →  9
if maxCategoryCount ≥ 2                           →  6
else                                              →  3
```

### Ensemble Aggregation
```
CareerReadinessScore = min(100, Tree1 + Tree2 + Tree3 + Tree4 + Tree5)
                     = min(100, VolumeScore + DiversityScore + ProgressionScore
                                + ConsistencyScore + SpecializationScore)
Maximum possible = 25 + 20 + 25 + 15 + 15 = 100
```

### Skill Level Score (0–100)
```
skillLevelScore = min(100,
    min(30, totalCount × 2)          [volume component]
  + min(25, uniqueCategories × 4)    [breadth component]
  + min(25, progressionScore × 10)   [depth component]
  + min(20, Advanced × 4)            [mastery component]
)
```

### Career Role Confidence (per role)
```
weightedConf(baseConfidence, relevantCategories) =
  round( min(97,
    baseConfidence
    + (relevantCategoryTotal / totalCount) × 40
    + (Advanced × 2)
  ))

where relevantCategoryTotal = sum of cert counts in categories relevant to that role
```

---

## Improvement 5 — Department-Based Teacher Notifications

### What changed
| File | Change |
|------|--------|
| `backend/models/User.js` | Added `teacherDepartment: String` to teacher schema |
| `backend/routes/auth.js` | `PUT /api/auth/teacher-department` endpoint |
| `backend/controllers/certificateController.js` | Notification query now filters `{ role: 'teacher', teacherDepartment: student.department }` |

### Old behavior
All approved teachers received every certificate notification regardless of department.

### New behavior
```
Student (dept: "IT") uploads certificate
    ↓
Query: User.find({ role: 'teacher', isApproved: true, teacherDepartment: "IT" })
    ↓
Only IT teachers get notified via DB + Socket.IO
```

### Setup for Teachers
Teachers must have `teacherDepartment` set to their department string (e.g., "IT", "CSE", "ECE").
This can be done:
- Via the new `PUT /api/auth/teacher-department` API endpoint
- Or directly in the admin panel when approving a teacher

Department strings must **exactly match** the student `department` field values.

---

## Installation Summary

```bash
# Backend — install new OCR dependencies
cd backend
npm install tesseract.js jimp jsqr pdf-parse

# No new frontend dependencies needed
cd frontend
npm install  # existing dependencies are sufficient
```
