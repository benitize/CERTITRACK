module.exports = require('../services/nlpService');
