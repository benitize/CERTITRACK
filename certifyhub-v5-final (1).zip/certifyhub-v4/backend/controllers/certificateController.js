const Certificate = require('../models/Certificate');
const User = require('../models/User');
const nlpService = require('../utils/nlpService');
const verificationService = require('../services/verificationService');
const path = require('path');
const fs = require('fs');

// @desc    Upload certificate
// @route   POST /api/certificates
// @access  Private (Student)
exports.uploadCertificate = async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ success: false, message: 'Please upload a certificate file' });
    }

    const {
      title, description, issueDate, certificateId, issuer, qrCodeData,
      certificateType,
      courseStartDate, courseEndDate,
      internshipStartDate, internshipEndDate
    } = req.body;

    if (!title || !description || !issueDate) {
      fs.unlinkSync(req.file.path);
      return res.status(400).json({ success: false, message: 'Please provide title, description, and issue date' });
    }

    // Extract keywords and categorize using NLP
    const keywords = nlpService.extractKeywords(`${title} ${description}`);
    const category = nlpService.categorize(title, description);

    // ── OCR-powered auto-verification ──
    const fileExt = path.extname(req.file.filename).substring(1).toLowerCase();
    let verificationResult = {
      status: 'unverified',
      method: 'none',
      message: 'No verification attempted'
    };

    // Attempt OCR verification whenever a file is uploaded
    try {
      verificationResult = await verificationService.autoVerifyCertificate({
        filePath: req.file.path,
        fileType: fileExt,
        issuer: issuer || '',
        certificateId: certificateId || '',
        qrCodeData: qrCodeData || ''
      });
    } catch (verErr) {
      console.error('Auto-verification error (non-fatal):', verErr.message);
    }

    // Create certificate
    const certificate = await Certificate.create({
      student: req.user.id,
      title,
      description,
      issueDate: new Date(issueDate),
      // Duration fields for accurate monthsActive
      certificateType: certificateType || 'course',
      courseStartDate:      courseStartDate      ? new Date(courseStartDate)      : undefined,
      courseEndDate:        courseEndDate        ? new Date(courseEndDate)        : undefined,
      internshipStartDate:  internshipStartDate  ? new Date(internshipStartDate)  : undefined,
      internshipEndDate:    internshipEndDate    ? new Date(internshipEndDate)    : undefined,
      fileName: req.file.filename,
      filePath: req.file.path,
      fileType: fileExt,
      certificateId: verificationResult.extractedId || certificateId || undefined,
      issuer: issuer || 'Other',
      qrCodeData: verificationResult.extractedQR || qrCodeData || undefined,
      verificationStatus: verificationResult.status,
      verificationMethod: verificationResult.method,
      verifiedAt: verificationResult.verifiedAt || undefined,
      keywords,
      category
    });

    await certificate.populate('student', 'name rollNumber department');

    // ── Department-based notifications ──
    // Only notify teachers whose teacherDepartment matches the student's department
    const io = req.app.get('io');
    if (io) {
      const studentDept = req.user.department;

      // Find teachers in the SAME department as the student
      const teachers = await User.find({
        role: 'teacher',
        isApproved: true,
        teacherDepartment: studentDept   // ← dept-filtered
      });

      for (const teacher of teachers) {
        teacher.notifications.push({
          message: `[${studentDept}] ${req.user.name} uploaded: ${title}`,
          certificateId: certificate._id,
          studentName: req.user.name
        });
        await teacher.save();

        io.to(`user_${teacher._id}`).emit('newCertificate', {
          message: `[${studentDept}] ${req.user.name} uploaded: ${title}`,
          certificate,
          student: { id: req.user.id, name: req.user.name, rollNumber: req.user.rollNumber, department: studentDept }
        });
      }
    }

    res.status(201).json({
      success: true,
      message: 'Certificate uploaded successfully',
      certificate,
      autoVerification: {
        status: verificationResult.status,
        method: verificationResult.method,
        message: verificationResult.message,
        extractedId: verificationResult.extractedId || null,
        extractedQR: verificationResult.extractedQR || null,
        verificationUrl: verificationResult.verificationUrl || null
      }
    });
  } catch (error) {
    console.error('Upload error:', error);
    if (req.file && fs.existsSync(req.file.path)) fs.unlinkSync(req.file.path);
    res.status(500).json({ success: false, message: error.message || 'Failed to upload certificate' });
  }
};

// @desc    Get all certificates for student (own)
// @route   GET /api/certificates
// @access  Private (Student)
exports.getMyCertificates = async (req, res) => {
  try {
    const certificates = await Certificate.find({ student: req.user.id })
      .sort({ issueDate: -1 })
      .populate('student', 'name rollNumber department');

    res.status(200).json({
      success: true,
      count: certificates.length,
      certificates
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Failed to fetch certificates'
    });
  }
};

// @desc    Get single certificate
// @route   GET /api/certificates/:id
// @access  Private
exports.getCertificate = async (req, res) => {
  try {
    const certificate = await Certificate.findById(req.params.id)
      .populate('student', 'name rollNumber department email')
      .populate('verifiedBy', 'name role');

    if (!certificate) {
      return res.status(404).json({
        success: false,
        message: 'Certificate not found'
      });
    }

    // Authorization check
    if (req.user.role === 'student' && certificate.student._id.toString() !== req.user.id) {
      return res.status(403).json({
        success: false,
        message: 'Not authorized to view this certificate'
      });
    }

    res.status(200).json({
      success: true,
      certificate
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Failed to fetch certificate'
    });
  }
};

// @desc    Download certificate file
// @route   GET /api/certificates/:id/download
// @access  Private
exports.downloadCertificate = async (req, res) => {
  try {
    const certificate = await Certificate.findById(req.params.id);

    if (!certificate) {
      return res.status(404).json({
        success: false,
        message: 'Certificate not found'
      });
    }

    // Authorization check
    if (req.user.role === 'student' && certificate.student.toString() !== req.user.id) {
      return res.status(403).json({
        success: false,
        message: 'Not authorized to download this certificate'
      });
    }

    // Check if file exists
    if (!fs.existsSync(certificate.filePath)) {
      return res.status(404).json({
        success: false,
        message: 'Certificate file not found'
      });
    }

    // Send file
    res.download(certificate.filePath, certificate.fileName);
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Failed to download certificate'
    });
  }
};

// @desc    Delete certificate
// @route   DELETE /api/certificates/:id
// @access  Private (Student - own, Admin - any)
exports.deleteCertificate = async (req, res) => {
  try {
    const certificate = await Certificate.findById(req.params.id);

    if (!certificate) {
      return res.status(404).json({
        success: false,
        message: 'Certificate not found'
      });
    }

    // Authorization check
    if (req.user.role === 'student' && certificate.student.toString() !== req.user.id) {
      return res.status(403).json({
        success: false,
        message: 'Not authorized to delete this certificate'
      });
    }

    // Delete file
    if (fs.existsSync(certificate.filePath)) {
      fs.unlinkSync(certificate.filePath);
    }

    // Delete from database
    await certificate.deleteOne();

    res.status(200).json({
      success: true,
      message: 'Certificate deleted successfully'
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Failed to delete certificate'
    });
  }
};

// @desc    Search certificates using NLP
// @route   GET /api/certificates/search
// @access  Private (Teacher, Admin)
exports.searchCertificates = async (req, res) => {
  try {
    const { query, year, verified, studentId } = req.query;

    let filter = {};

    // Filter by student (if provided)
    if (studentId) {
      filter.student = studentId;
    }

    // Filter by year
    if (year) {
      const startDate = new Date(`${year}-01-01`);
      const endDate = new Date(`${year}-12-31`);
      filter.issueDate = { $gte: startDate, $lte: endDate };
    }

    // Filter by verification status
    if (verified === 'verified') {
      filter.isVerified = true;
    } else if (verified === 'unverified') {
      filter.isVerified = false;
    }

    // Get certificates
    let certificates = await Certificate.find(filter)
      .populate('student', 'name rollNumber department email')
      .populate('verifiedBy', 'name role')
      .sort({ issueDate: -1 });

    // Apply NLP search if query provided
    if (query && query.trim()) {
      certificates = nlpService.searchCertificates(certificates, query);
    }

    res.status(200).json({
      success: true,
      count: certificates.length,
      certificates
    });
  } catch (error) {
    console.error('Search error:', error);
    res.status(500).json({
      success: false,
      message: 'Search failed'
    });
  }
};

// @desc    Get certificates by student
// @route   GET /api/certificates/student/:studentId
// @access  Private (Teacher, Admin)
exports.getCertificatesByStudent = async (req, res) => {
  try {
    const certificates = await Certificate.find({ student: req.params.studentId })
      .sort({ issueDate: -1 })
      .populate('student', 'name rollNumber department email');

    res.status(200).json({
      success: true,
      count: certificates.length,
      certificates
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Failed to fetch certificates'
    });
  }
};

// @desc    Manually verify certificate
// @route   PUT /api/certificates/:id/verify
// @access  Private (Teacher, Admin)
exports.verifyCertificate = async (req, res) => {
  try {
    const certificate = await Certificate.findById(req.params.id);

    if (!certificate) {
      return res.status(404).json({
        success: false,
        message: 'Certificate not found'
      });
    }

    certificate.isVerified = true;
    certificate.verificationMethod = 'Manual';
    certificate.verificationDate = new Date();
    certificate.verifiedBy = req.user.id;

    await certificate.save();
    await certificate.populate('verifiedBy', 'name role');

    res.status(200).json({
      success: true,
      message: 'Certificate verified successfully',
      certificate
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Verification failed'
    });
  }
};

// @desc    Get search suggestions
// @route   GET /api/certificates/suggestions
// @access  Private (Teacher, Admin)
exports.getSearchSuggestions = async (req, res) => {
  try {
    const certificates = await Certificate.find({});
    const suggestions = nlpService.getSearchSuggestions(certificates);

    res.status(200).json({
      success: true,
      suggestions
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Failed to get suggestions'
    });
  }
};
