const express = require('express');
const router  = express.Router();
const path    = require('path');
const fs      = require('fs');

const Certificate = require('../models/Certificate');
const User        = require('../models/User');
const { auth, studentOnly, teacherOrAdmin, adminOnly } = require('../middleware/auth');
const upload = require('../middleware/upload');
const { extractKeywords, categorizeCertificate, determineSkillLevel, searchCertificates } = require('../services/nlpService');
const { autoVerifyCertificate, manualVerification } = require('../services/verificationService');

/* ══════════════════════════════════════════════════════════════════════
   OCR EXTRACT  POST /api/certificates/ocr-extract
   Uploads file, runs OCR/QR extraction, deletes file, returns fields.
   No certificate record is created. Students use this to auto-fill the form.
══════════════════════════════════════════════════════════════════════ */
router.post('/ocr-extract', auth, studentOnly, upload.single('certificate'), async (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'No file uploaded' });

  const filePath = req.file.path;
  const fileExt  = path.extname(req.file.filename).substring(1).toLowerCase();

  try {
    let ocrText    = '';
    let qrCodeData = '';

    // ── PDF text extraction ──
    if (fileExt === 'pdf') {
      try {
        const pdfParse = require('pdf-parse');
        const buf      = fs.readFileSync(filePath);
        const parsed   = await pdfParse(buf);
        ocrText = parsed.text || '';
      } catch (e) { console.warn('pdf-parse:', e.message); }

    // ── Image OCR + QR ──
    } else if (['jpg','jpeg','png'].includes(fileExt)) {
      try {
        const Tesseract = require('tesseract.js');
        const { data: { text } } = await Tesseract.recognize(filePath, 'eng', { logger: () => {} });
        ocrText = text || '';
      } catch (e) { console.warn('Tesseract:', e.message); }

      try {
        const Jimp = require('jimp');
        const jsQR = require('jsqr');
        const img  = await Jimp.read(filePath);
        const code = jsQR(new Uint8ClampedArray(img.bitmap.data), img.bitmap.width, img.bitmap.height);
        if (code) qrCodeData = code.data;
      } catch (e) { console.warn('jsQR:', e.message); }
    }

    // Clean up temp file immediately
    if (fs.existsSync(filePath)) fs.unlinkSync(filePath);

    const extracted = parseOCRFields(ocrText, qrCodeData);
    return res.json(extracted);
  } catch (err) {
    if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
    console.error('OCR extract error:', err);
    return res.status(500).json({ error: 'OCR processing failed' });
  }
});

/* ── OCR field parser ── */
function parseOCRFields(text, qrCodeData) {
  const result = { title:'', description:'', issueDate:'', certificateId:'', issuer:'', qrCodeData: qrCodeData || '' };
  if (!text || text.trim().length < 5) return result;

  const lines = text.split('\n').map(l => l.trim()).filter(Boolean);

  // Issuer detection
  const ISSUERS = {
    Coursera:  ['coursera'],
    Udemy:     ['udemy'],
    LinkedIn:  ['linkedin'],
    Google:    ['google'],
    Microsoft: ['microsoft'],
    AWS:       ['amazon web services','aws'],
  };
  for (const [name, kws] of Object.entries(ISSUERS)) {
    if (kws.some(kw => text.toLowerCase().includes(kw))) { result.issuer = name; break; }
  }

  // Title: first meaningful line that isn't boilerplate
  const BOILER = ['certificate','congratulations','this is to certify','awarded','presented','verify at','completion of'];
  for (const line of lines) {
    if (line.length > 4 && line.length < 120 && !BOILER.some(b => line.toLowerCase().startsWith(b))) {
      result.title = line; break;
    }
  }
  if (!result.title) result.title = lines[0] || '';

  // Date parsing
  const DATE_PATS = [
    { re: /(\d{4})[\/\-](\d{1,2})[\/\-](\d{1,2})/, fn: m => `${m[1]}-${m[2].padStart(2,'0')}-${m[3].padStart(2,'0')}` },
    { re: /(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{4})/, fn: m => `${m[3]}-${m[1].padStart(2,'0')}-${m[2].padStart(2,'0')}` },
    { re: /(\d{1,2})\s+(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\w*[\s,]+(\d{4})/i,
      fn: m => { const MO={jan:1,feb:2,mar:3,apr:4,may:5,jun:6,jul:7,aug:8,sep:9,oct:10,nov:11,dec:12}; return `${m[3]}-${String(MO[m[2].slice(0,3).toLowerCase()]).padStart(2,'0')}-${m[1].padStart(2,'0')}`; } },
    { re: /(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\w*\s+(\d{1,2}),?\s+(\d{4})/i,
      fn: m => { const MO={jan:1,feb:2,mar:3,apr:4,may:5,jun:6,jul:7,aug:8,sep:9,oct:10,nov:11,dec:12}; return `${m[3]}-${String(MO[m[1].slice(0,3).toLowerCase()]).padStart(2,'0')}-${m[2].padStart(2,'0')}`; } },
  ];
  for (const { re, fn } of DATE_PATS) {
    const m = text.match(re);
    if (m) {
      try {
        const iso = fn(m);
        const d   = new Date(iso);
        if (!isNaN(d) && d <= new Date()) { result.issueDate = iso; break; }
      } catch (_) { /* skip */ }
    }
  }

  // Certificate ID
  const CERT_ID_PATS = {
    Coursera:  /([A-Z0-9]{8,20})/,
    Udemy:     /UC-([A-Za-z0-9\-]{20,40})/,
    LinkedIn:  /([A-Za-z0-9]{30,50})/,
    Google:    /([A-Za-z0-9\-]{16,40})/,
    Microsoft: /([A-Za-z0-9\-]{36})/,
    AWS:       /([A-Z0-9]{12,20})/,
  };
  if (result.issuer && CERT_ID_PATS[result.issuer]) {
    const m = text.match(CERT_ID_PATS[result.issuer]);
    if (m) result.certificateId = m[1] || m[0];
  }
  if (!result.certificateId) {
    const m = text.match(/(?:certificate\s*(?:id|no|number)[:\s#]+)([A-Za-z0-9\-]{6,30})/i);
    if (m) result.certificateId = m[1];
  }

  // Description: a few content lines
  result.description = lines
    .filter(l => l.length > 20 && /[a-zA-Z]{4,}/.test(l) && l !== result.title)
    .slice(0, 3).join(' ').slice(0, 300);

  return result;
}

/* ══════════════════════════════════════════════════════════════════════
   UPLOAD  POST /api/certificates/upload
══════════════════════════════════════════════════════════════════════ */
router.post('/upload', auth, studentOnly, upload.single('certificate'), async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ error: 'Please upload a certificate file' });

    const {
      title, description, issueDate,
      certificateId, issuer, qrCodeData,
      certificateType,
      courseStartDate, courseEndDate,
      internshipStartDate, internshipEndDate
    } = req.body;

    if (!title || !description || !issueDate) {
      fs.unlinkSync(req.file.path);
      return res.status(400).json({ error: 'Please provide title, description, and issue date' });
    }

    // NLP
    const keywords   = extractKeywords(`${title} ${description}`);
    const category   = categorizeCertificate(title, description);
    const skillLevel = determineSkillLevel(title, description);

    // Auto-verification
    const fileExt = path.extname(req.file.filename).substring(1).toLowerCase();
    let autoVerification = { status:'unverified', method:'none', message:'No verification attempted' };
    try {
      autoVerification = await autoVerifyCertificate({
        filePath: req.file.path, fileType: fileExt,
        issuer: issuer || '', certificateId: certificateId || '', qrCodeData: qrCodeData || ''
      });
    } catch (e) { console.error('Auto-verify (non-fatal):', e.message); }

    const certificate = new Certificate({
      student:      req.userId,
      title, description,
      issueDate:    new Date(issueDate),
      certificateType: certificateType || 'course',
      courseStartDate:     courseStartDate     ? new Date(courseStartDate)     : undefined,
      courseEndDate:       courseEndDate       ? new Date(courseEndDate)       : undefined,
      internshipStartDate: internshipStartDate ? new Date(internshipStartDate) : undefined,
      internshipEndDate:   internshipEndDate   ? new Date(internshipEndDate)   : undefined,
      fileName:     req.file.filename,
      filePath:     req.file.path,
      fileType:     req.file.mimetype,
      certificateId: autoVerification.extractedId || certificateId || '',
      issuer:        issuer || '',
      qrCodeData:    autoVerification.extractedQR || qrCodeData || '',
      verificationStatus: autoVerification.status,
      verificationMethod: autoVerification.method,
      verifiedAt: autoVerification.verifiedAt || undefined,
      category, keywords, skillLevel
    });

    await certificate.save();
    await certificate.populate('student', 'name rollNumber department');

    // Dept-filtered notifications
    const notify = req.app.get('sendNotificationToTeachers');
    if (notify) notify(certificate).catch(e => console.error('Notify:', e));

    return res.status(201).json({
      message: 'Certificate uploaded successfully',
      certificate,
      autoVerification: {
        status:          autoVerification.status,
        method:          autoVerification.method,
        message:         autoVerification.message,
        extractedId:     autoVerification.extractedId || null,
        extractedQR:     autoVerification.extractedQR || null,
        verificationUrl: autoVerification.verificationUrl || null
      }
    });
  } catch (error) {
    console.error('Upload error:', error);
    if (req.file && fs.existsSync(req.file.path)) fs.unlinkSync(req.file.path);
    return res.status(500).json({ error: error.message || 'Server error during upload' });
  }
});

/* ══════ GET my-certificates ══════ */
router.get('/my-certificates', auth, studentOnly, async (req, res) => {
  try {
    const certs = await Certificate.find({ student: req.userId }).sort({ issueDate: -1 }).select('-filePath');
    res.json({ certificates: certs, count: certs.length });
  } catch { res.status(500).json({ error: 'Server error' }); }
});

/* ══════ GET all (teacher/admin) ══════ */
router.get('/all', auth, teacherOrAdmin, async (req, res) => {
  try {
    const { year, month, verificationStatus, studentId } = req.query;
    let query = {};

    if (studentId) {
      query.student = studentId;
    } else if (req.userRole === 'teacher') {
      const dept = req.user.department || req.user.subject;
      if (dept) {
        const ds = await User.find({ role:'student', isApproved:true, department:{ $regex:new RegExp(`^${dept}$`,'i') } }).select('_id');
        query.student = { $in: ds.map(d => d._id) };
      }
    }

    if (year && year !== 'all') {
      if (month && month !== 'all') {
        const mn = parseInt(month);
        query.issueDate = { $gte:new Date(parseInt(year),mn-1,1), $lte:new Date(parseInt(year),mn,0,23,59,59) };
      } else {
        query.issueDate = { $gte:new Date(`${year}-01-01`), $lte:new Date(`${year}-12-31`) };
      }
    } else if (month && month !== 'all') {
      query.$expr = { $eq:[{ $month:'$issueDate' }, parseInt(month)] };
    }
    if (verificationStatus && verificationStatus !== 'all') query.verificationStatus = verificationStatus;

    const certs = await Certificate.find(query).populate('student','name rollNumber department').sort({ issueDate:-1 }).select('-filePath');
    res.json({ certificates: certs, count: certs.length });
  } catch (e) { console.error(e); res.status(500).json({ error:'Server error' }); }
});

/* ══════ GET search ══════ */
router.get('/search', auth, teacherOrAdmin, async (req, res) => {
  try {
    const { query, year, verificationStatus } = req.query;
    let dbQ = {};
    if (req.userRole === 'teacher') {
      const dept = req.user.department || req.user.subject;
      if (dept) {
        const ds = await User.find({ role:'student', isApproved:true, department:{ $regex:new RegExp(`^${dept}$`,'i') } }).select('_id');
        dbQ.student = { $in: ds.map(d => d._id) };
      }
    }
    if (year && year !== 'all') dbQ.issueDate = { $gte:new Date(`${year}-01-01`), $lte:new Date(`${year}-12-31`) };
    if (verificationStatus && verificationStatus !== 'all') dbQ.verificationStatus = verificationStatus;

    let results = await Certificate.find(dbQ).populate('student','name rollNumber department').sort({ issueDate:-1 });
    if (query && query.trim()) results = searchCertificates(results, query);
    res.json({ certificates: results.map(c => { const { filePath, ...r } = c._doc||c; return r; }), count: results.length });
  } catch (e) { res.status(500).json({ error:'Server error' }); }
});

/* ══════ GET download/:id ══════ */
router.get('/download/:id', auth, async (req, res) => {
  try {
    const cert = await Certificate.findById(req.params.id);
    if (!cert) return res.status(404).json({ error:'Certificate not found' });
    if (req.userRole === 'student' && cert.student.toString() !== req.userId.toString()) return res.status(403).json({ error:'Access denied' });
    if (!fs.existsSync(cert.filePath)) return res.status(404).json({ error:'File not found' });
    res.download(cert.filePath, cert.fileName);
  } catch { res.status(500).json({ error:'Server error' }); }
});

/* ══════ GET view/:id ══════ */
router.get('/view/:id', auth, async (req, res) => {
  try {
    const cert = await Certificate.findById(req.params.id);
    if (!cert) return res.status(404).json({ error:'Certificate not found' });
    if (req.userRole === 'student' && cert.student.toString() !== req.userId.toString()) return res.status(403).json({ error:'Access denied' });
    if (!fs.existsSync(cert.filePath)) return res.status(404).json({ error:'File not found' });
    res.setHeader('Content-Type', cert.fileType || 'application/pdf');
    res.setHeader('Content-Disposition', `inline; filename="${cert.fileName}"`);
    fs.createReadStream(cert.filePath).pipe(res);
  } catch { res.status(500).json({ error:'Server error' }); }
});

/* ══════ DELETE /:id ══════ */
router.delete('/:id', auth, async (req, res) => {
  try {
    const cert = await Certificate.findById(req.params.id);
    if (!cert) return res.status(404).json({ error:'Certificate not found' });
    if (req.userRole === 'student' && cert.student.toString() !== req.userId.toString()) return res.status(403).json({ error:'Access denied' });
    if (fs.existsSync(cert.filePath)) fs.unlinkSync(cert.filePath);
    await Certificate.findByIdAndDelete(req.params.id);
    res.json({ message:'Certificate deleted successfully' });
  } catch { res.status(500).json({ error:'Server error' }); }
});

/* ══════ PUT verify/:id ══════ */
router.put('/verify/:id', auth, teacherOrAdmin, async (req, res) => {
  try {
    const cert = await Certificate.findById(req.params.id);
    if (!cert) return res.status(404).json({ error:'Certificate not found' });
    const v = manualVerification(req.userId);
    Object.assign(cert, { verificationStatus:v.status, verificationMethod:v.method, verifiedBy:req.userId, verifiedAt:v.verifiedAt });
    await cert.save();
    res.json({ message:'Certificate verified successfully', certificate:cert });
  } catch { res.status(500).json({ error:'Server error' }); }
});

/* ══════ GET stats/overview (admin) ══════ */
router.get('/stats/overview', auth, adminOnly, async (req, res) => {
  try {
    const total    = await Certificate.countDocuments();
    const verified = await Certificate.countDocuments({ verificationStatus:'verified' });
    const cats     = await Certificate.aggregate([{ $group:{ _id:'$category', count:{ $sum:1 } } }]);
    res.json({ totalCertificates:total, verifiedCertificates:verified, unverifiedCertificates:total-verified, categoryCounts:cats });
  } catch { res.status(500).json({ error:'Server error' }); }
});

module.exports = router;
