const express = require('express');
const router = express.Router();
const Feedback = require('../models/Feedback');
const User = require('../models/User');
const { auth, teacherOrAdmin, studentOnly } = require('../middleware/auth');

// Teacher sends feedback to a student
router.post('/', auth, teacherOrAdmin, async (req, res) => {
  try {
    const { studentId, message, certificateId, type } = req.body;

    if (!studentId || !message) {
      return res.status(400).json({ error: 'studentId and message are required' });
    }

    const student = await User.findById(studentId);
    if (!student || student.role !== 'student') {
      return res.status(404).json({ error: 'Student not found' });
    }

    const feedback = new Feedback({
      teacher: req.userId,
      student: studentId,
      certificate: certificateId || null,
      message,
      type: type || 'general'
    });

    await feedback.save();
    await feedback.populate('teacher', 'name department');
    await feedback.populate('certificate', 'title category');

    // Add notification to student
    const notifMessage = `${req.user.name} sent you feedback${feedback.certificate ? ` on "${feedback.certificate.title}"` : ''}: "${message.substring(0, 60)}${message.length > 60 ? '...' : ''}"`;

    await User.updateOne(
      { _id: studentId },
      {
        $push: {
          notifications: {
            $each: [{
              message: notifMessage,
              certificateId: certificateId || null,
              studentName: req.user.name,
              isRead: false,
              createdAt: new Date()
            }],
            $slice: -50
          }
        }
      }
    );

    // Real-time socket notification to student
    const io = req.app.get('io');
    const connectedUsers = req.app.get('connectedUsers');
    const studentSocket = connectedUsers.get(studentId.toString());
    if (studentSocket) {
      io.to(studentSocket).emit('feedback:new', {
        feedback,
        message: notifMessage
      });
    }

    res.status(201).json({ message: 'Feedback sent successfully', feedback });
  } catch (error) {
    console.error('Feedback send error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// Teacher gets all feedback they sent
router.get('/sent', auth, teacherOrAdmin, async (req, res) => {
  try {
    const feedbacks = await Feedback.find({ teacher: req.userId })
      .populate('student', 'name rollNumber department')
      .populate('certificate', 'title category')
      .sort({ createdAt: -1 });
    res.json({ feedbacks });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// Student gets all feedback received
router.get('/received', auth, async (req, res) => {
  try {
    if (req.userRole !== 'student') {
      return res.status(403).json({ error: 'Students only' });
    }
    const feedbacks = await Feedback.find({ student: req.userId })
      .populate('teacher', 'name department subject')
      .populate('certificate', 'title category')
      .sort({ createdAt: -1 });

    // Count unread
    const unread = feedbacks.filter(f => !f.isRead).length;
    res.json({ feedbacks, unreadCount: unread });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// Get feedback for a specific student (teacher/admin)
router.get('/student/:studentId', auth, teacherOrAdmin, async (req, res) => {
  try {
    const feedbacks = await Feedback.find({ student: req.params.studentId })
      .populate('teacher', 'name department')
      .populate('certificate', 'title category')
      .sort({ createdAt: -1 });
    res.json({ feedbacks });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// Mark feedback as read (student)
router.put('/:id/read', auth, async (req, res) => {
  try {
    await Feedback.updateOne({ _id: req.params.id, student: req.userId }, { isRead: true });
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// Mark all feedback as read (student)
router.put('/read-all', auth, async (req, res) => {
  try {
    await Feedback.updateMany({ student: req.userId, isRead: false }, { isRead: true });
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// Delete feedback
router.delete('/:id', auth, teacherOrAdmin, async (req, res) => {
  try {
    await Feedback.findOneAndDelete({ _id: req.params.id, teacher: req.userId });
    res.json({ message: 'Deleted' });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

module.exports = router;
