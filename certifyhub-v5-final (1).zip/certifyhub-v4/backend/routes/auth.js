const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const User = require('../models/User');
const { auth } = require('../middleware/auth');

// Register new user (Student or Teacher)
router.post('/register', async (req, res) => {
  try {
    const { name, email, password, role, rollNumber, department, subject } = req.body;
    
    // Validate required fields
    if (!name || !email || !password || !role) {
      return res.status(400).json({ error: 'Please provide all required fields' });
    }
    
    // Only allow student and teacher registration via API
    if (role !== 'student' && role !== 'teacher') {
      return res.status(400).json({ error: 'Invalid role. Use student or teacher' });
    }
    
    // Validate role-specific fields
    if (role === 'student' && (!rollNumber || !department)) {
      return res.status(400).json({ error: 'Students must provide roll number and department' });
    }
    
    if (role === 'teacher' && !subject) {
      return res.status(400).json({ error: 'Teachers must provide department (stored as subject)' });
    }
    
    // Check if user already exists
    const existingUser = await User.findOne({ email: email.toLowerCase() });
    if (existingUser) {
      return res.status(400).json({ error: 'Email already registered' });
    }
    
    // Hash password (10 rounds)
    const hashedPassword = await bcrypt.hash(password, 10);
    
    // Create user
    const user = new User({
      name,
      email: email.toLowerCase(),
      password: hashedPassword,
      role,
      rollNumber: role === 'student' ? rollNumber : undefined,
      department: role === 'student' ? department : undefined,
      subject: role === 'teacher' ? subject : undefined,
      teacherDepartment: role === 'teacher' ? (req.body.teacherDepartment || '') : undefined,
      areasOfInterest: role === 'student' ? [] : undefined,
      isApproved: false // Requires admin approval
    });
    
    await user.save();
    
    res.status(201).json({
      message: 'Registration successful. Please wait for admin approval.',
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        role: user.role,
        isApproved: user.isApproved
      }
    });
  } catch (error) {
    console.error('Registration error:', error);
    res.status(500).json({ error: 'Server error during registration' });
  }
});

// Login
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    
    if (!email || !password) {
      return res.status(400).json({ error: 'Please provide email and password' });
    }
    
    // Find user
    const user = await User.findOne({ email: email.toLowerCase() });
    if (!user) {
      return res.status(401).json({ error: 'Invalid email or password' });
    }
    
    // Check password
    const isPasswordValid = await bcrypt.compare(password, user.password);
    if (!isPasswordValid) {
      return res.status(401).json({ error: 'Invalid email or password' });
    }
    
    // Check if approved (except admins)
    if (user.role !== 'admin' && !user.isApproved) {
      return res.status(403).json({ 
        error: 'Your account is pending admin approval',
        isPending: true
      });
    }
    
    // Generate JWT token
    const token = jwt.sign(
      { userId: user._id, role: user.role },
      process.env.JWT_SECRET,
      { expiresIn: '7d' }
    );
    
    res.json({
      message: 'Login successful',
      token,
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        role: user.role,
        department: user.department,
        subject: user.subject,
        rollNumber: user.rollNumber,
        isApproved: user.isApproved,
        areasOfInterest: user.areasOfInterest || [],
        teacherDepartment: user.teacherDepartment || ''
      }
    });
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ error: 'Server error during login' });
  }
});

// Get current user info
router.get('/me', auth, async (req, res) => {
  try {
    const user = await User.findById(req.userId).select('-password');
    res.json({ user });
  } catch (error) {
    console.error('Get user error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// Update student's areas of interest
// PUT /api/auth/interests
router.put('/interests', auth, async (req, res) => {
  try {
    const { areasOfInterest } = req.body;
    const user = await User.findById(req.userId);

    if (!user || user.role !== 'student') {
      return res.status(403).json({ error: 'Only students can set areas of interest' });
    }

    const VALID_INTERESTS = ['Programming', 'Backend', 'Frontend', 'Database', 'Cloud', 'AI/ML', 'Mobile', 'Other'];
    const filtered = (areasOfInterest || []).filter(i => VALID_INTERESTS.includes(i));

    user.areasOfInterest = filtered;
    await user.save();

    res.json({ message: 'Areas of interest updated', areasOfInterest: user.areasOfInterest });
  } catch (error) {
    console.error('Update interests error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// Update teacher's department (for dept-based notifications)
// PUT /api/auth/teacher-department
router.put('/teacher-department', auth, async (req, res) => {
  try {
    const { teacherDepartment } = req.body;
    const user = await User.findById(req.userId);

    if (!user || user.role !== 'teacher') {
      return res.status(403).json({ error: 'Only teachers can set their department' });
    }

    user.teacherDepartment = teacherDepartment;
    await user.save();

    res.json({ message: 'Teacher department updated', teacherDepartment: user.teacherDepartment });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// Verify token
router.get('/verify-token', auth, (req, res) => {
  res.json({ 
    valid: true,
    user: {
      id: req.userId,
      role: req.userRole
    }
  });
});

module.exports = router;
