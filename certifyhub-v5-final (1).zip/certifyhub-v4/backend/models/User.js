const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
    trim: true
  },
  email: {
    type: String,
    required: true,
    unique: true,
    lowercase: true,
    trim: true
  },
  password: {
    type: String,
    required: true
  },
  role: {
    type: String,
    enum: ['admin', 'teacher', 'student'],
    required: true
  },
  // Student-specific fields
  rollNumber: {
    type: String,
    sparse: true // Only required for students
  },
  department: {
    type: String,
    trim: true
  },
  // Student-specific: areas of interest
  areasOfInterest: {
    type: [String],
    default: []
    // e.g. ['AI/ML', 'Cloud', 'Frontend']
  },
  // Teacher-specific fields
  subject: {
    type: String,
    trim: true
  },
  // Teacher department (mirrors student departments for routing notifications)
  teacherDepartment: {
    type: String,
    trim: true
  },
  // Approval system
  isApproved: {
    type: Boolean,
    default: false // Students and teachers need approval
  },
  // Notifications
  notifications: [{
    message: String,
    certificateId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Certificate'
    },
    studentName: String,
    isRead: {
      type: Boolean,
      default: false
    },
    createdAt: {
      type: Date,
      default: Date.now
    }
  }],
  registeredAt: {
    type: Date,
    default: Date.now
  }
}, {
  timestamps: true
});

// Index for faster queries
userSchema.index({ email: 1 });
userSchema.index({ role: 1, isApproved: 1 });

module.exports = mongoose.model('User', userSchema);
