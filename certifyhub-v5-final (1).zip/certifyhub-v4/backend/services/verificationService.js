/**
 * verificationService.js
 *
 * OCR-powered automatic certificate verification:
 *  1. Extract text from PDF (pdf-parse) or image (Tesseract.js)
 *  2. Scan QR code from image (jsQR + Jimp)
 *  3. Parse Certificate ID from OCR text using issuer-specific patterns
 *  4. HTTP HEAD verification against issuer's verification URL
 *
 * OCR packages are lazy-loaded so the server starts even before npm install.
 */

const axios = require('axios');
const fs    = require('fs');

/* ── Issuer verification URL builders ── */
const ISSUER_VERIFY_URLS = {
  Coursera:  id => `https://www.coursera.org/verify/${id}`,
  Udemy:     id => `https://www.udemy.com/certificate/${id}/`,
  LinkedIn:  id => `https://www.linkedin.com/learning/certificates/${id}`,
  Google:    id => `https://skillshop.credential.net/verify/${id}`,
  Microsoft: id => `https://learn.microsoft.com/api/credentials/share/${id}`,
  AWS:       id => `https://aws.amazon.com/verification/${id}`,
};

/* ── Certificate ID patterns per issuer ── */
const CERT_ID_PATTERNS = {
  Coursera:  /([A-Z0-9]{8,20})/,
  Udemy:     /UC-([A-Za-z0-9\-]{20,40})/,
  LinkedIn:  /([A-Za-z0-9]{30,50})/,
  Google:    /([A-Za-z0-9\-]{16,40})/,
  Microsoft: /([A-Za-z0-9\-]{36})/,
  AWS:       /([A-Z0-9]{12,20})/,
};

async function extractTextFromPDF(filePath) {
  try {
    const pdfParse = require('pdf-parse');
    const buf      = fs.readFileSync(filePath);
    const data     = await pdfParse(buf);
    return data.text || '';
  } catch (err) {
    console.warn('pdf-parse error:', err.message);
    return '';
  }
}

async function extractTextFromImage(filePath) {
  try {
    const Tesseract = require('tesseract.js');
    const { data: { text } } = await Tesseract.recognize(filePath, 'eng', { logger: () => {} });
    return text || '';
  } catch (err) {
    console.warn('Tesseract error:', err.message);
    return '';
  }
}

async function extractQRFromImage(filePath) {
  try {
    const Jimp = require('jimp');
    const jsQR = require('jsqr');
    const img  = await Jimp.read(filePath);
    const code = jsQR(new Uint8ClampedArray(img.bitmap.data), img.bitmap.width, img.bitmap.height);
    return code ? code.data : null;
  } catch (err) {
    console.warn('QR scan error:', err.message);
    return null;
  }
}

function parseCertificateId(ocrText, issuer) {
  if (!ocrText || !issuer) return null;
  const pattern = CERT_ID_PATTERNS[issuer];
  if (!pattern) return null;
  const m = ocrText.match(pattern);
  return m ? (m[1] || m[0]) : null;
}

async function verifyWithIssuerURL(issuer, certId) {
  const buildURL = ISSUER_VERIFY_URLS[issuer];
  if (!buildURL || !certId) return { verified: false, reason: 'No verification URL' };
  const url = buildURL(certId);
  try {
    const resp = await axios.head(url, { timeout: 7000, validateStatus: s => s < 500 });
    const ok   = resp.status >= 200 && resp.status < 400;
    return { verified: ok, url, statusCode: resp.status,
      reason: ok ? `Confirmed at ${issuer} (HTTP ${resp.status})` : `Not found at ${issuer} (HTTP ${resp.status})` };
  } catch (err) {
    return { verified: false, url, reason: `Cannot reach ${issuer}: ${err.message}` };
  }
}

async function autoVerifyCertificate({ filePath, fileType, issuer, certificateId: manualId, qrCodeData: manualQR }) {
  const result = {
    status:'unverified', method:'none', extractedId:null, extractedQR:null,
    ocrText:'', verificationUrl:null, message:'No verification data extracted', verifiedAt:undefined,
  };

  // Normalise file extension
  const ext = (fileType || '').replace('image/','').replace('application/','').toLowerCase();

  // 1. Extract text
  let ocrText = '';
  if (ext === 'pdf') {
    ocrText = await extractTextFromPDF(filePath);
  } else if (['jpg','jpeg','png'].includes(ext)) {
    ocrText = await extractTextFromImage(filePath);
  }
  result.ocrText = ocrText.slice(0, 800);

  // 2. QR scan
  let qrData = manualQR || null;
  if (!qrData && ['jpg','jpeg','png'].includes(ext)) {
    qrData = await extractQRFromImage(filePath);
    if (qrData) { result.extractedQR = qrData; result.method = 'ocr_qr'; }
  }

  // 3. Parse cert ID
  let certId = manualId || null;
  if (!certId && ocrText && issuer) {
    certId = parseCertificateId(ocrText, issuer);
    if (certId) { result.extractedId = certId; result.method = result.method || 'ocr_certificate_id'; }
  }

  // 4. Verify
  if (issuer && issuer !== 'Other') {
    if (qrData && qrData.startsWith('http')) {
      try {
        const resp = await axios.head(qrData, { timeout: 7000, validateStatus: s => s < 500 });
        const ok   = resp.status >= 200 && resp.status < 400;
        result.status = ok ? 'verified' : 'unverified';
        result.verificationUrl = qrData;
        result.message = ok ? `QR URL verified (HTTP ${resp.status})` : `QR URL returned HTTP ${resp.status}`;
        if (ok) result.verifiedAt = new Date();
      } catch (e) { result.message = `QR URL unreachable: ${e.message}`; }
    } else if (certId) {
      const r = await verifyWithIssuerURL(issuer, certId);
      result.status = r.verified ? 'verified' : 'unverified';
      result.verificationUrl = r.url || null;
      result.message = r.reason;
      if (r.verified) result.verifiedAt = new Date();
    } else {
      result.message = ocrText
        ? 'Text extracted but no Certificate ID or QR found'
        : 'Could not extract text from the certificate file';
    }
  } else {
    result.message = (certId || qrData)
      ? 'Data extracted but no supported issuer selected for URL verification'
      : 'No verification data found in file';
  }

  return result;
}

function manualVerification(verifiedBy) {
  return { status:'verified', method:'manual', message:'Manually verified by teacher or admin', verifiedAt:new Date(), verifiedBy };
}

function getSupportedIssuers() {
  return [
    { name:'Coursera', code:'coursera' }, { name:'Udemy', code:'udemy' },
    { name:'LinkedIn', code:'linkedin' }, { name:'Google', code:'google' },
    { name:'Microsoft', code:'microsoft' }, { name:'AWS', code:'aws' },
    { name:'Other', code:'other' },
  ];
}

module.exports = { autoVerifyCertificate, manualVerification, getSupportedIssuers, extractTextFromImage, extractTextFromPDF, extractQRFromImage, parseCertificateId };
