// Random Forest-based ML Growth Analysis Service
// UPDATED: Uses actual course/internship duration for monthsActive,
//          and integrates student areasOfInterest for gap-aware recommendations.

const MS_PER_MONTH = 1000 * 60 * 60 * 24 * 30;

/**
 * Compute "months active" for a single certificate using its actual duration dates.
 * Priority: course dates → internship dates → fallback to issueDate (1 month).
 */
function certDurationMonths(cert) {
  const start = cert.courseStartDate || cert.internshipStartDate;
  const end   = cert.courseEndDate   || cert.internshipEndDate || cert.issueDate;
  if (start && end) {
    const diff = (new Date(end) - new Date(start)) / MS_PER_MONTH;
    return Math.max(0.25, diff); // minimum ~1 week
  }
  return 1; // default: 1 month when no duration provided
}

function extractFeatures(certificates, areasOfInterest = []) {
  if (!certificates || certificates.length === 0) return null;

  const sorted = [...certificates].sort((a, b) => new Date(a.issueDate) - new Date(b.issueDate));

  const categoryCounts = {
    Programming: 0, Backend: 0, Frontend: 0, Database: 0,
    Cloud: 0, 'AI/ML': 0, Mobile: 0, Other: 0
  };

  const keywordMap = {}; // aggregate all keywords from certs
  const issuers = {};

  certificates.forEach(cert => {
    if (categoryCounts.hasOwnProperty(cert.category)) categoryCounts[cert.category]++;
    if (cert.keywords) cert.keywords.forEach(k => { keywordMap[k] = (keywordMap[k] || 0) + 1; });
    if (cert.issuer && cert.issuer !== '') issuers[cert.issuer] = (issuers[cert.issuer] || 0) + 1;
  });

  const timeGaps = [];
  for (let i = 1; i < sorted.length; i++) {
    const gap = (new Date(sorted[i].issueDate) - new Date(sorted[i - 1].issueDate)) / (1000 * 60 * 60 * 24);
    timeGaps.push(gap);
  }
  const avgTimeGap = timeGaps.length > 0 ? timeGaps.reduce((a, b) => a + b, 0) / timeGaps.length : 0;

  // ── IMPROVEMENT: monthsActive based on actual course/internship duration ──
  // Sum individual certificate durations (de-duplicated by actual calendar span).
  // If no duration info at all, fall back to first-to-last-issueDate span.
  const hasDurationData = certificates.some(c =>
    c.courseStartDate || c.internshipStartDate
  );

  let monthsActive;
  if (hasDurationData) {
    // Sum each certificate's own duration
    monthsActive = Math.max(1, certificates.reduce((sum, cert) => sum + certDurationMonths(cert), 0));
  } else {
    // Legacy fallback: calendar span between first and last issue dates
    const firstDate = new Date(sorted[0].issueDate);
    const lastDate  = new Date(sorted[sorted.length - 1].issueDate);
    monthsActive = Math.max(1, (lastDate - firstDate) / MS_PER_MONTH);
  }

  const growthRate = certificates.length / monthsActive;

  const uniqueCategories = Object.values(categoryCounts).filter(c => c > 0).length;
  const diversityScore = uniqueCategories / 8;

  const skillLevels = { Beginner: 0, Intermediate: 0, Advanced: 0 };
  certificates.forEach(cert => {
    if (skillLevels.hasOwnProperty(cert.skillLevel)) skillLevels[cert.skillLevel]++;
  });

  const progressionScore = (skillLevels.Advanced * 3 + skillLevels.Intermediate * 2 + skillLevels.Beginner * 1) / certificates.length;

  // Top keywords (sorted by frequency)
  const topKeywords = Object.entries(keywordMap)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 10)
    .map(([k]) => k);

  // Top category
  const topCategoryEntry = Object.entries(categoryCounts).sort((a, b) => b[1] - a[1])[0];
  const topCategory = topCategoryEntry[0];
  const topCategoryCount = topCategoryEntry[1];

  return {
    totalCount: certificates.length,
    categoryCounts,
    avgTimeGap,
    growthRate,
    diversityScore,
    progressionScore,
    monthsActive,
    skillLevels,
    uniqueCategories,
    topKeywords,
    topCategory,
    topCategoryCount,
    issuers,
    areasOfInterest: Array.isArray(areasOfInterest) ? areasOfInterest : []
  };
}

function decisionTree1_VolumeScore(features) {
  const count = features.totalCount;
  if (count >= 20) return 25;
  if (count >= 15) return 20;
  if (count >= 10) return 15;
  if (count >= 5) return 10;
  return 5;
}
function decisionTree2_DiversityScore(features) {
  const unique = features.uniqueCategories;
  if (unique >= 6) return 20;
  if (unique >= 5) return 16;
  if (unique >= 4) return 12;
  if (unique >= 3) return 8;
  if (unique >= 2) return 5;
  return 2;
}
function decisionTree3_ProgressionScore(features) {
  const progression = features.progressionScore;
  const advanced = features.skillLevels.Advanced;
  if (progression >= 2.5 && advanced >= 3) return 25;
  if (progression >= 2.0) return 20;
  if (progression >= 1.5) return 15;
  if (progression >= 1.2) return 10;
  return 5;
}
function decisionTree4_ConsistencyScore(features) {
  const growthRate = features.growthRate;
  const avgTimeGap = features.avgTimeGap;
  if (growthRate >= 2 && avgTimeGap < 45) return 15;
  if (growthRate >= 1.5) return 12;
  if (growthRate >= 1) return 9;
  if (growthRate >= 0.5) return 6;
  return 3;
}
function decisionTree5_SpecializationScore(features) {
  const counts = features.categoryCounts;
  const maxCategory = Math.max(...Object.values(counts));
  if (maxCategory >= 5 && features.uniqueCategories >= 3) return 15;
  if (maxCategory >= 5) return 12;
  if (maxCategory >= 3) return 9;
  if (maxCategory >= 2) return 6;
  return 3;
}

function calculateCareerReadiness(features) {
  const tree1 = decisionTree1_VolumeScore(features);
  const tree2 = decisionTree2_DiversityScore(features);
  const tree3 = decisionTree3_ProgressionScore(features);
  const tree4 = decisionTree4_ConsistencyScore(features);
  const tree5 = decisionTree5_SpecializationScore(features);
  return {
    score: Math.min(100, tree1 + tree2 + tree3 + tree4 + tree5),
    breakdown: { volume: tree1, diversity: tree2, progression: tree3, consistency: tree4, specialization: tree5 }
  };
}

function calculateSkillLevel(features) {
  const { totalCount, uniqueCategories, skillLevels, progressionScore } = features;
  let score = 0;
  score += Math.min(30, totalCount * 2);
  score += Math.min(25, uniqueCategories * 4);
  score += Math.min(25, progressionScore * 10);
  score += Math.min(20, skillLevels.Advanced * 4);
  return Math.min(100, Math.round(score));
}

// ── FIXED: Predict career roles based on ACTUAL certificate categories ──
function predictCareerRole(features) {
  const { categoryCounts, totalCount, uniqueCategories, skillLevels, topKeywords, growthRate } = features;
  const roles = [];
  const total = totalCount || 1;

  // Helper: compute a confidence score weighted by category dominance
  const weightedConf = (base, relevant) => {
    const relevantTotal = relevant.reduce((s, [, c]) => s + c, 0);
    const ratio = relevantTotal / total;
    return Math.round(Math.min(97, base + ratio * 40 + (skillLevels.Advanced * 2)));
  };

  // Full Stack Developer
  if (categoryCounts.Backend >= 1 && categoryCounts.Frontend >= 1) {
    const conf = weightedConf(55, [['b', categoryCounts.Backend], ['f', categoryCounts.Frontend]]);
    roles.push({ role: 'Full Stack Developer', confidence: conf });
  }

  // Backend Developer
  if (categoryCounts.Backend >= 1 || categoryCounts.Database >= 1) {
    const conf = weightedConf(48, [['b', categoryCounts.Backend], ['db', categoryCounts.Database]]);
    roles.push({ role: 'Backend Developer', confidence: conf });
  }

  // Frontend Developer
  if (categoryCounts.Frontend >= 1) {
    const conf = weightedConf(50, [['f', categoryCounts.Frontend]]);
    roles.push({ role: 'Frontend Developer', confidence: conf });
  }

  // Cloud / DevOps Engineer
  if (categoryCounts.Cloud >= 1) {
    const conf = weightedConf(52, [['c', categoryCounts.Cloud]]);
    roles.push({ role: 'Cloud / DevOps Engineer', confidence: conf });
  }

  // Data Scientist / ML Engineer
  if (categoryCounts['AI/ML'] >= 1) {
    const conf = weightedConf(55, [['ai', categoryCounts['AI/ML']]]);
    roles.push({ role: 'Data Scientist / ML Engineer', confidence: conf });
  }

  // Mobile App Developer
  if (categoryCounts.Mobile >= 1) {
    const conf = weightedConf(50, [['m', categoryCounts.Mobile]]);
    roles.push({ role: 'Mobile App Developer', confidence: conf });
  }

  // Software Engineer (general programming)
  if (categoryCounts.Programming >= 1) {
    const conf = weightedConf(45, [['p', categoryCounts.Programming]]);
    roles.push({ role: 'Software Engineer', confidence: conf });
  }

  // If only "Other" certs or very few
  if (roles.length === 0) {
    if (totalCount >= 3) {
      roles.push({ role: 'Emerging Developer', confidence: 40 + totalCount * 2 });
    } else {
      roles.push({ role: 'Early Learner', confidence: 25 + totalCount * 5 });
    }
  }

  // Deduplicate and sort by confidence
  const seen = new Set();
  const unique = roles.filter(r => {
    if (seen.has(r.role)) return false;
    seen.add(r.role);
    return true;
  });

  unique.sort((a, b) => b.confidence - a.confidence);

  // Normalise so top role doesn't exceed 95 and spread is realistic
  if (unique.length > 0 && unique[0].confidence > 95) unique[0].confidence = 95;

  return unique.slice(0, 5);
}

// ── UPDATED: Recommendations based on certificates + areasOfInterest gap analysis ──
/**
 * COURSE SUGGESTIONS MAP — used both for gap filling and interest-based courses.
 */
const COURSE_SUGGESTIONS = {
  Programming:  ['Advanced Algorithms & Data Structures', 'Design Patterns in Python/Java', 'Clean Code Principles', 'Competitive Programming Basics'],
  Backend:      ['Microservices Architecture', 'REST API Best Practices', 'Node.js / Spring Boot Advanced', 'GraphQL Essentials'],
  Frontend:     ['React Advanced Patterns', 'Performance Optimization & Web Vitals', 'TypeScript Mastery', 'CSS Architecture & Tailwind'],
  Database:     ['SQL Query Optimization', 'NoSQL vs SQL Trade-offs', 'Database Indexing & Tuning', 'MongoDB for Developers'],
  Cloud:        ['AWS Certified Cloud Practitioner', 'Docker & Kubernetes', 'Terraform / IaC', 'Serverless Architecture'],
  'AI/ML':      ['Machine Learning with Python (scikit-learn)', 'Deep Learning Basics with TensorFlow', 'MLOps & Model Deployment', 'Natural Language Processing'],
  Mobile:       ['Cross-Platform with Flutter', 'React Native Advanced', 'iOS/Android Security Best Practices', 'Mobile UI/UX Design'],
  Other:        ['System Design Fundamentals', 'Software Architecture Patterns', 'Agile & Scrum Certification', 'Technical Communication']
};

function generateRecommendations(features) {
  const {
    categoryCounts, totalCount, uniqueCategories,
    skillLevels, topCategory, topCategoryCount,
    areasOfInterest
  } = features;
  const recommendations = [];

  // ── PRIORITY 0: Interest-Gap Analysis ──
  // Find areas of interest that have NO certificates submitted yet.
  if (Array.isArray(areasOfInterest) && areasOfInterest.length > 0) {
    const interestGaps = areasOfInterest.filter(interest => {
      const count = categoryCounts[interest] || 0;
      return count === 0;
    });

    if (interestGaps.length > 0) {
      // Add one recommendation per uncovered interest (max 2 to avoid cluttering)
      interestGaps.slice(0, 2).forEach(gap => {
        recommendations.push({
          skill: `${gap} — Your Interest`,
          priority: 'High',
          reason: `You marked "${gap}" as an area of interest but have no certificates in it yet. This is your biggest skill gap!`,
          estimatedTime: '4-6 weeks',
          suggestions: COURSE_SUGGESTIONS[gap] || [`Introduction to ${gap}`, `${gap} Fundamentals`, `Hands-on ${gap} Projects`],
          type: 'interest_gap'
        });
      });
    }

    // Interest areas that DO have some certificates — suggest advancement
    const interestWithCerts = areasOfInterest.filter(interest => (categoryCounts[interest] || 0) > 0);
    interestWithCerts.slice(0, 1).forEach(interest => {
      const count = categoryCounts[interest];
      recommendations.push({
        skill: `Advance in ${interest}`,
        priority: count >= 3 ? 'High' : 'Medium',
        reason: `You have ${count} certificate${count > 1 ? 's' : ''} in "${interest}" which matches your interest. Keep advancing to expert level!`,
        estimatedTime: '6-8 weeks',
        suggestions: (COURSE_SUGGESTIONS[interest] || []).slice(1), // skip beginner suggestion
        type: 'interest_advance'
      });
    });
  }

  // 1. Address biggest gaps first (missing high-value categories)
  const missingHighValue = [];
  if (categoryCounts.Cloud === 0) missingHighValue.push('Cloud');
  if (categoryCounts.Database === 0) missingHighValue.push('Database');
  if (categoryCounts['AI/ML'] === 0 && totalCount >= 5) missingHighValue.push('AI/ML');

  const alreadyCoveredByInterest = recommendations.map(r => r.skill);
  missingHighValue
    .filter(m => !alreadyCoveredByInterest.some(s => s.includes(m)))
    .slice(0, 1)
    .forEach(missingKey => {
      recommendations.push({
        skill: missingKey === 'AI/ML' ? 'AI/ML Fundamentals' : `${missingKey} Management`,
        priority: 'High',
        reason: `You currently have no certificates in ${missingKey}. This is a highly valued skill in the industry.`,
        estimatedTime: '3-5 weeks',
        suggestions: COURSE_SUGGESTIONS[missingKey] || [`Introduction to ${missingKey}`],
        type: 'market_gap'
      });
    });

  // 2. Deepen top category (if not already suggested)
  if (
    topCategoryCount >= 1 &&
    topCategory !== 'Other' &&
    !recommendations.some(r => r.skill.includes(topCategory))
  ) {
    recommendations.push({
      skill: `Advanced ${topCategory}`,
      priority: topCategoryCount >= 3 ? 'High' : 'Medium',
      reason: `You have ${topCategoryCount} certificate${topCategoryCount > 1 ? 's' : ''} in ${topCategory}. Deepening this expertise will accelerate your career.`,
      estimatedTime: '6-8 weeks',
      suggestions: COURSE_SUGGESTIONS[topCategory] || ['Advanced Topics', 'Project-based Learning', 'Open Source Contribution'],
      type: 'deepen'
    });
  }

  // 3. Diversification if too narrow
  if (uniqueCategories < 3 && totalCount >= 4) {
    const have     = Object.entries(categoryCounts).filter(([, v]) => v > 0).map(([k]) => k);
    const dontHave = ['Backend', 'Frontend', 'Cloud', 'Database', 'AI/ML', 'Mobile'].filter(c => !have.includes(c));
    if (dontHave.length > 0) {
      recommendations.push({
        skill: 'Skill Diversification',
        priority: 'Medium',
        reason: `Your certificates focus on ${have.join(', ')}. Expanding to ${dontHave.slice(0, 2).join(' or ')} will make you more versatile.`,
        estimatedTime: '2-3 months',
        suggestions: dontHave.slice(0, 3).map(c => `Introduction to ${c}`),
        type: 'diversify'
      });
    }
  }

  // 4. Skill level progression
  if (skillLevels.Beginner > skillLevels.Intermediate + skillLevels.Advanced && totalCount >= 4) {
    recommendations.push({
      skill: 'Level Up to Intermediate/Advanced',
      priority: 'High',
      reason: `${skillLevels.Beginner} of your ${totalCount} certificates are Beginner level. Progressing will significantly boost your career readiness score.`,
      estimatedTime: '4-6 weeks per course',
      suggestions: [
        `Intermediate ${topCategory} Certification`,
        'Project-Based Advanced Course',
        'Industry Recognized Certification'
      ],
      type: 'level_up'
    });
  }

  // 5. Consistency nudge
  if (features.growthRate < 0.5 && totalCount >= 3) {
    recommendations.push({
      skill: 'Learning Consistency',
      priority: 'Medium',
      reason: `Your average is ${features.growthRate.toFixed(1)} certificates/month. More consistent learning will compound your skills faster.`,
      estimatedTime: 'Ongoing',
      suggestions: ['Set a monthly learning goal', 'Join a study group', 'Use structured learning paths on Coursera/Udemy'],
      type: 'consistency'
    });
  }

  // 6. Programming basics missing
  if (categoryCounts.Programming === 0 && totalCount < 5) {
    recommendations.push({
      skill: 'Programming Fundamentals',
      priority: 'High',
      reason: 'A strong programming foundation is essential for all tech roles.',
      estimatedTime: '4-6 weeks',
      suggestions: ['Python for Beginners', 'JavaScript Essentials', 'Data Structures & Algorithms'],
      type: 'foundation'
    });
  }

  return recommendations.slice(0, 6); // return up to 6 (extra slot for interest-gap)
}

function generateGrowthChart(certificates) {
  if (!certificates || certificates.length === 0) return [];
  const sorted = [...certificates].sort((a, b) => new Date(a.issueDate) - new Date(b.issueDate));
  const chartData = [];
  let cumulative = 0;
  sorted.forEach(cert => {
    cumulative++;
    chartData.push({
      date: new Date(cert.issueDate).toISOString().split('T')[0],
      count: cumulative,
      category: cert.category
    });
  });
  return chartData;
}

function generatePeerComparison(features, userDepartment) {
  const departmentAverage = 8;
  const topPerformer = 25;
  const userCount = features.totalCount;
  const percentile = Math.min(99, Math.round((userCount / topPerformer) * 100));
  return {
    userCertificates: userCount,
    departmentAverage,
    topPerformer,
    percentile,
    ranking: percentile >= 75 ? 'Top 25%' : percentile >= 50 ? 'Top 50%' : 'Below Average'
  };
}

function performMLAnalysis(certificates, userDepartment, areasOfInterest = []) {
  const features = extractFeatures(certificates, areasOfInterest);
  if (!features) {
    return { error: 'Insufficient data', message: 'Upload at least one certificate to view growth analysis' };
  }
  const careerReadiness = calculateCareerReadiness(features);
  const skillLevel = calculateSkillLevel(features);
  const careerRoles = predictCareerRole(features);
  const recommendations = generateRecommendations(features);
  const growthChart = generateGrowthChart(certificates);
  const peerComparison = generatePeerComparison(features, userDepartment);

  return {
    skillLevelScore: skillLevel,
    careerReadinessScore: careerReadiness.score,
    careerReadinessBreakdown: careerReadiness.breakdown,
    predictedRoles: careerRoles,
    recommendations,
    growthChart,
    peerComparison,
    features: {
      totalCertificates: features.totalCount,
      categoryCounts: features.categoryCounts,
      uniqueCategories: features.uniqueCategories,
      averageTimeGap: Math.round(features.avgTimeGap),
      growthRate: features.growthRate.toFixed(2),
      monthsActive: Math.round(features.monthsActive),
      skillLevels: features.skillLevels,
      topKeywords: features.topKeywords,
      areasOfInterest: features.areasOfInterest
    }
  };
}

module.exports = {
  performMLAnalysis, extractFeatures, calculateCareerReadiness,
  calculateSkillLevel, predictCareerRole, generateRecommendations,
  certDurationMonths, COURSE_SUGGESTIONS
};
