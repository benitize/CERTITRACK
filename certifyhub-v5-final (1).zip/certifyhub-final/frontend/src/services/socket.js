import { io } from 'socket.io-client';

const SOCKET_URL = process.env.REACT_APP_SOCKET_URL || 'http://localhost:5000';

class SocketService {
  constructor() {
    this.socket = null;
    this.callbacks = {};
  }

  connect(userId) {
    if (!this.socket) {
      this.socket = io(SOCKET_URL, {
        transports: ['websocket'],
        reconnection: true,
        reconnectionAttempts: 5,
        reconnectionDelay: 1000
      });

      this.socket.on('connect', () => {
        console.log('✅ Socket connected');
        if (userId) {
          this.socket.emit('user:join', userId);
        }
      });

      this.socket.on('disconnect', () => {
        console.log('❌ Socket disconnected');
      });

      this.socket.on('connect_error', (error) => {
        console.error('Socket connection error:', error);
      });
    }

    return this.socket;
  }

  disconnect() {
    if (this.socket) {
      this.socket.disconnect();
      this.socket = null;
    }
  }

  on(event, callback) {
    if (this.socket) {
      this.socket.on(event, callback);
      this.callbacks[event] = callback;
    }
  }

  off(event) {
    if (this.socket && this.callbacks[event]) {
      this.socket.off(event, this.callbacks[event]);
      delete this.callbacks[event];
    }
  }

  emit(event, data) {
    if (this.socket) {
      this.socket.emit(event, data);
    }
  }

  // Specific notification methods
  markAsRead(userId, notificationId) {
    this.emit('notification:read', { userId, notificationId });
  }

  markAllAsRead(userId) {
    this.emit('notification:read-all', { userId });
  }

  deleteNotification(userId, notificationId) {
    this.emit('notification:delete', { userId, notificationId });
  }
}

export default new SocketService();
