import React, { useState, useEffect, useRef } from 'react';
import { notificationAPI, certificateAPI } from '../services/api';
import socketService from '../services/socket';
import { useAuth } from '../context/AuthContext';

const NotificationBell = () => {
  const [notifications, setNotifications] = useState([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [isOpen, setIsOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [previewCert, setPreviewCert] = useState(null);
  const { user } = useAuth();
  const dropdownRef = useRef(null);

  useEffect(() => {
    if (user) fetchNotifications();

    const handleNew = ({ notification, unreadCount: count }) => {
      setNotifications(prev => [notification, ...prev]);
      setUnreadCount(count);
      if (Notification.permission === 'granted') {
        new Notification('CertifyHub', { body: notification.message, icon: '/logo192.png' });
      }
    };

    socketService.on('notification:new', handleNew);
    if (Notification.permission === 'default') Notification.requestPermission();

    const outside = (e) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target)) setIsOpen(false);
    };
    document.addEventListener('mousedown', outside);
    const poll = setInterval(() => { if (user) fetchNotifications(); }, 30000);

    return () => {
      socketService.off('notification:new', handleNew);
      document.removeEventListener('mousedown', outside);
      clearInterval(poll);
    };
  }, [user]);

  const fetchNotifications = async () => {
    setLoading(true);
    try {
      const res = await notificationAPI.getNotifications();
      setNotifications(res.data.notifications || []);
      setUnreadCount(res.data.unreadCount || 0);
    } catch (e) { console.error(e); }
    finally { setLoading(false); }
  };

  const markAsRead = async (id) => {
    try {
      await notificationAPI.markAsRead(id);
      setNotifications(prev => prev.map(n => n._id === id ? { ...n, isRead: true } : n));
      setUnreadCount(prev => Math.max(0, prev - 1));
    } catch (e) { }
  };

  const markAllAsRead = async () => {
    try {
      await notificationAPI.markAllAsRead();
      setNotifications(prev => prev.map(n => ({ ...n, isRead: true })));
      setUnreadCount(0);
    } catch (e) { }
  };

  const deleteNotification = async (id, e) => {
    e.stopPropagation();
    try {
      const notif = notifications.find(n => n._id === id);
      await notificationAPI.deleteNotification(id);
      setNotifications(prev => prev.filter(n => n._id !== id));
      if (notif && !notif.isRead) setUnreadCount(prev => Math.max(0, prev - 1));
    } catch (e) { }
  };

  const clearAll = async () => {
    try { await notificationAPI.clearAll(); setNotifications([]); setUnreadCount(0); } catch (e) { }
  };

  // Click notification → open cert preview with token-in-URL (fixes auth error in iframe)
  const handleNotificationClick = (notif) => {
    if (!notif.isRead) markAsRead(notif._id);
    if (!notif.certificateId) return;
    setIsOpen(false);
    // Use viewIframe which embeds token in query param – works inside <iframe src>
    const iframeUrl = certificateAPI.viewIframe(notif.certificateId);
    setPreviewCert({
      iframeUrl,
      message: notif.message,
      studentName: notif.studentName,
      studentDept: notif.studentDept
    });
  };

  const timeAgo = (date) => {
    const diff = Date.now() - new Date(date).getTime();
    const mins = Math.floor(diff / 60000);
    if (mins < 1) return 'Just now';
    if (mins < 60) return `${mins}m ago`;
    const hours = Math.floor(mins / 60);
    if (hours < 24) return `${hours}h ago`;
    return `${Math.floor(hours / 24)}d ago`;
  };

  return (
    <>
      <div className="nb-wrap" ref={dropdownRef}>
        <button
          className="nb-btn"
          onClick={() => { setIsOpen(!isOpen); if (!isOpen) fetchNotifications(); }}
          title="Notifications"
        >
          <svg width="22" height="22" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
              d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
          </svg>
          {unreadCount > 0 && (
            <span className="nb-badge">{unreadCount > 99 ? '99+' : unreadCount}</span>
          )}
        </button>

        {isOpen && (
          <div className="nb-dropdown">
            {/* Header */}
            <div className="nb-header">
              <div className="nb-header-left">
                <svg width="16" height="16" fill="none" stroke="#6366f1" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
                    d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
                </svg>
                <span className="nb-title">Notifications</span>
                {unreadCount > 0 && <span className="nb-count-pill">{unreadCount} new</span>}
              </div>
              <div className="nb-header-actions">
                {unreadCount > 0 && (
                  <button onClick={markAllAsRead} className="nb-action-btn nb-mark-read">Mark all read</button>
                )}
                {notifications.length > 0 && (
                  <button onClick={clearAll} className="nb-action-btn nb-clear">Clear all</button>
                )}
              </div>
            </div>

            {/* List */}
            <div className="nb-list">
              {loading ? (
                <div className="nb-empty">
                  <div className="nb-spinner" />
                  <p>Loading...</p>
                </div>
              ) : notifications.length === 0 ? (
                <div className="nb-empty">
                  <svg width="40" height="40" fill="none" stroke="#d1d5db" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5}
                      d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
                  </svg>
                  <p>No notifications yet</p>
                  <span>Alerts appear when dept students upload certificates</span>
                </div>
              ) : (
                notifications.map(notif => (
                  <div
                    key={notif._id}
                    className={`nb-item ${!notif.isRead ? 'nb-item-unread' : ''} ${notif.certificateId ? 'nb-item-clickable' : ''}`}
                    onClick={() => handleNotificationClick(notif)}
                    title={notif.certificateId ? 'Click to view certificate' : ''}
                  >
                    {!notif.isRead && <span className="nb-dot" />}
                    <div className="nb-item-body">
                      <p className={`nb-item-msg ${!notif.isRead ? 'nb-item-msg-unread' : ''}`}>{notif.message}</p>
                      {notif.studentDept && (
                        <p className="nb-item-dept">🏫 {notif.studentDept}</p>
                      )}
                      {notif.studentName && (
                        <p className="nb-item-sub">👤 {notif.studentName}</p>
                      )}
                      {notif.certificateId && (
                        <p className="nb-item-link">
                          <svg width="11" height="11" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                          </svg>
                          Click to view certificate
                        </p>
                      )}
                      <p className="nb-item-time">{timeAgo(notif.createdAt)}</p>
                    </div>
                    <button
                      className="nb-delete-btn"
                      onClick={(e) => deleteNotification(notif._id, e)}
                      title="Dismiss"
                    >
                      <svg width="14" height="14" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                      </svg>
                    </button>
                  </div>
                ))
              )}
            </div>

            {notifications.length > 0 && (
              <div className="nb-footer">
                <button onClick={fetchNotifications} className="nb-refresh-btn">
                  <svg width="12" height="12" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                  </svg>
                  Refresh
                </button>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Certificate Preview Modal - uses token-in-URL to avoid auth errors */}
      {previewCert && (
        <div className="nb-modal-overlay" onClick={() => setPreviewCert(null)}>
          <div className="nb-modal" onClick={e => e.stopPropagation()}>
            <div className="nb-modal-header">
              <div className="nb-modal-title-row">
                <svg width="18" height="18" fill="none" stroke="white" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
                    d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                </svg>
                <div>
                  <h3 className="nb-modal-title">Certificate Preview</h3>
                  {previewCert.studentName && (
                    <p className="nb-modal-sub">
                      Uploaded by {previewCert.studentName}
                      {previewCert.studentDept && ` · ${previewCert.studentDept}`}
                    </p>
                  )}
                </div>
              </div>
              <div className="nb-modal-header-actions">
                <a
                  href={previewCert.iframeUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="nb-modal-open-btn"
                  onClick={e => e.stopPropagation()}
                >
                  <svg width="13" height="13" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
                      d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
                  </svg>
                  Open full
                </a>
                <button className="nb-modal-close" onClick={() => setPreviewCert(null)}>
                  <svg width="16" height="16" fill="none" stroke="white" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </button>
              </div>
            </div>
            <div className="nb-modal-body">
              <p className="nb-modal-msg">{previewCert.message}</p>
              <iframe
                src={previewCert.iframeUrl}
                className="nb-modal-iframe"
                title="Certificate Preview"
              />
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default NotificationBell;
