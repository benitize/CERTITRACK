import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { certificateAPI, feedbackAPI, authAPI } from '../services/api';
import { getErrorMessage } from '../utils/helpers';
import CertificateCard from '../components/CertificateCard';
import { useAuth } from '../context/AuthContext';

const ALL_INTERESTS = ['Programming','Backend','Frontend','Database','Cloud','AI/ML','Mobile','Other'];
const ISSUERS       = ['','Coursera','Udemy','LinkedIn','Google','Microsoft','AWS','Other'];
const EMPTY_FORM    = {
  title:'', description:'', issueDate:'', certificateId:'',
  issuer:'', qrCodeData:'',
  certificateType:'course',
  courseStartDate:'', courseEndDate:'',
  internshipStartDate:'', internshipEndDate:'',
  file: null
};

const StudentDashboard = () => {
  const navigate   = useNavigate();
  const { user }   = useAuth();

  const [activeTab,      setActiveTab]      = useState('certificates');
  const [certificates,   setCertificates]   = useState([]);
  const [loading,        setLoading]        = useState(false);
  const [uploading,      setUploading]      = useState(false);
  const [error,          setError]          = useState('');
  const [success,        setSuccess]        = useState('');
  const [showUploadForm, setShowUploadForm] = useState(false);

  /* OCR */
  const [ocrRunning, setOcrRunning] = useState(false);
  const [ocrResult,  setOcrResult]  = useState(null);

  /* Feedback inbox */
  const [feedbacks,       setFeedbacks]       = useState([]);
  const [feedbackUnread,  setFeedbackUnread]  = useState(0);
  const [loadingFeedback, setLoadingFeedback] = useState(false);

  /* Interests */
  const [selectedInterests, setSelectedInterests] = useState(user?.areasOfInterest || []);
  const [interestSaving,    setInterestSaving]    = useState(false);
  const [interestMsg,       setInterestMsg]       = useState('');

  const [formData, setFormData] = useState(EMPTY_FORM);
  const fileInputRef = useRef(null);

  useEffect(() => { fetchCertificates(); fetchFeedback(); }, []); // eslint-disable-line

  /* ── Fetchers ── */
  const fetchCertificates = async () => {
    setLoading(true);
    try {
      const res = await certificateAPI.getMyCertificates();
      setCertificates(res.data.certificates || []);
    } catch(e) { setError(getErrorMessage(e)); }
    finally    { setLoading(false); }
  };

  const fetchFeedback = async () => {
    setLoadingFeedback(true);
    try {
      const res = await feedbackAPI.getReceived();
      setFeedbacks(res.data.feedbacks || []);
      setFeedbackUnread(res.data.unreadCount || 0);
    } catch(e) { console.error(e); }
    finally    { setLoadingFeedback(false); }
  };

  /* ── OCR: fires automatically when file is selected ── */
  const handleFileChange = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const allowed = ['application/pdf','image/jpeg','image/jpg','image/png'];
    if (!allowed.includes(file.type)) { setError('Only PDF, JPG, and PNG files are allowed'); e.target.value=''; return; }
    if (file.size > 10*1024*1024)     { setError('File size must be less than 10 MB');         e.target.value=''; return; }

    setFormData(prev => ({ ...prev, file }));
    setError('');
    setOcrRunning(true);
    setOcrResult(null);

    try {
      const fd = new FormData();
      fd.append('certificate', file);
      const res       = await certificateAPI.ocrExtract(fd);
      const extracted = res.data;
      setOcrResult(extracted);
      /* Auto-fill only still-empty fields */
      setFormData(prev => ({
        ...prev, file,
        title:         prev.title         || extracted.title         || '',
        description:   prev.description   || extracted.description   || '',
        issueDate:     prev.issueDate      || extracted.issueDate     || '',
        certificateId: prev.certificateId || extracted.certificateId || '',
        issuer:        prev.issuer        || extracted.issuer        || '',
        qrCodeData:    prev.qrCodeData    || extracted.qrCodeData    || '',
      }));
    } catch(err) {
      console.warn('OCR failed:', err.message);
      setOcrResult({ error:'Could not auto-extract data — please fill in the fields manually.' });
    } finally { setOcrRunning(false); }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  /* ── Upload submit ── */
  const handleSubmit = async (e) => {
    e.preventDefault();
    setError(''); setSuccess('');
    if (!formData.title || !formData.description || !formData.issueDate || !formData.file) {
      setError('Please fill in all required fields'); return;
    }
    setUploading(true);
    try {
      const data = new FormData();
      data.append('title',           formData.title);
      data.append('description',     formData.description);
      data.append('issueDate',       formData.issueDate);
      data.append('certificate',     formData.file);
      data.append('certificateType', formData.certificateType || 'course');
      if (formData.certificateId)       data.append('certificateId',      formData.certificateId);
      if (formData.issuer)              data.append('issuer',              formData.issuer);
      if (formData.qrCodeData)          data.append('qrCodeData',          formData.qrCodeData);
      if (formData.courseStartDate)     data.append('courseStartDate',     formData.courseStartDate);
      if (formData.courseEndDate)       data.append('courseEndDate',       formData.courseEndDate);
      if (formData.internshipStartDate) data.append('internshipStartDate', formData.internshipStartDate);
      if (formData.internshipEndDate)   data.append('internshipEndDate',   formData.internshipEndDate);

      const res  = await certificateAPI.upload(data);
      const autoV = res.data?.autoVerification;
      let msg = 'Certificate uploaded successfully! Your teacher has been notified.';
      if (autoV?.status === 'verified')  msg += ` ✅ Auto-verified via ${autoV.method}.`;
      else if (autoV?.extractedId)       msg += ` 🔍 Extracted ID: ${autoV.extractedId} — pending verification.`;
      else if (autoV?.extractedQR)       msg += ` 📷 QR code detected — pending issuer verification.`;

      setSuccess(msg);
      setFormData(EMPTY_FORM);
      setOcrResult(null);
      if (fileInputRef.current) fileInputRef.current.value = '';
      setShowUploadForm(false);
      fetchCertificates();
    } catch(e) { setError(getErrorMessage(e)); }
    finally    { setUploading(false); }
  };

  const handleDownload = async (certId) => {
    try {
      const res = await certificateAPI.download(certId);
      const url = window.URL.createObjectURL(new Blob([res.data]));
      const a   = document.createElement('a');
      a.href = url; a.download = `certificate-${certId}.pdf`; a.click();
      window.URL.revokeObjectURL(url);
    } catch(e) { alert(getErrorMessage(e)); }
  };

  const handleDelete = async (certId) => {
    if (!window.confirm('Delete this certificate?')) return;
    try {
      await certificateAPI.delete(certId);
      setCertificates(prev => prev.filter(c => c._id !== certId));
      setSuccess('Certificate deleted.');
    } catch(e) { alert(getErrorMessage(e)); }
  };

  /* ── Feedback ── */
  const handleMarkFeedbackRead = async (id) => {
    try {
      await feedbackAPI.markRead(id);
      setFeedbacks(prev => prev.map(f => f._id===id ? { ...f, isRead:true } : f));
      setFeedbackUnread(prev => Math.max(0, prev-1));
    } catch(e) { console.error(e); }
  };
  const handleMarkAllFeedbackRead = async () => {
    try {
      await feedbackAPI.markAllRead();
      setFeedbacks(prev => prev.map(f => ({ ...f, isRead:true })));
      setFeedbackUnread(0);
    } catch(e) { console.error(e); }
  };

  /* ── Interests ── */
  const toggleInterest = (i) =>
    setSelectedInterests(prev => prev.includes(i) ? prev.filter(x=>x!==i) : [...prev,i]);

  const handleSaveInterests = async () => {
    setInterestSaving(true); setInterestMsg('');
    try {
      await authAPI.updateInterests(selectedInterests);
      setInterestMsg('✅ Areas of interest saved!');
    } catch { setInterestMsg('❌ Failed to save. Try again.'); }
    finally { setInterestSaving(false); }
  };

  /* ── Computed ── */
  const verified = certificates.filter(c => c.verificationStatus === 'verified').length;
  const pending  = certificates.length - verified;
  const typeLabels = { general:'💬 General', certificate:'📄 Certificate', encouragement:'🌟 Encouragement', improvement:'🔧 Improvement' };
  const typeColors = { general:'fb-type-general', certificate:'fb-type-certificate', encouragement:'fb-type-encourage', improvement:'fb-type-improve' };
  const fmtDate = d => new Date(d).toLocaleDateString('en-US',{ year:'numeric', month:'short', day:'numeric' });

  return (
    <div className="sd-root">

      {/* ═══ HEADER ═══ */}
      <div className="sd-hero">
        <div className="sd-hero-inner">
          <div className="sd-hero-left">
            <h1 className="sd-hero-title">My Certificates</h1>
            <p className="sd-hero-sub">Track your learning journey and achievements</p>
          </div>
          <div className="sd-hero-stats">
            {[{ label:'Total', val:certificates.length, color:'#6366f1' },
              { label:'Verified', val:verified, color:'#10b981' },
              { label:'Pending', val:pending, color:'#f59e0b' }].map(s => (
              <div key={s.label} className="sd-stat-card">
                <span className="sd-stat-val" style={{ color:s.color }}>{s.val}</span>
                <span className="sd-stat-label">{s.label}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="sd-tabs">
          {[
            { id:'certificates', d:'M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z', label:'Certificates' },
            { id:'interests',    d:'M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z', label:'My Interests', badge:selectedInterests.length },
            { id:'feedback',     d:'M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z', label:'Feedback Inbox', badge:feedbackUnread },
          ].map(tab => (
            <button key={tab.id} className={`sd-tab ${activeTab===tab.id?'sd-tab-active':''}`} onClick={()=>setActiveTab(tab.id)}>
              <svg width="15" height="15" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d={tab.d}/>
              </svg>
              {tab.label}
              {tab.badge > 0 && <span className="sd-tab-badge">{tab.badge}</span>}
            </button>
          ))}
        </div>
      </div>

      <div className="sd-container">

        {/* ═══════════════ CERTIFICATES TAB ═══════════════ */}
        {activeTab === 'certificates' && (
          <>
            {error   && <div className="sd-error">{error}</div>}
            {success && <div className="sd-success">{success}</div>}

            <div className="sd-actions">
              <button className="sd-upload-btn" onClick={()=>{ setShowUploadForm(v=>!v); setError(''); setSuccess(''); }}>
                <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4"/>
                </svg>
                {showUploadForm ? 'Cancel' : 'Upload Certificate'}
              </button>
              {certificates.length > 0 && (
                <button className="sd-analysis-btn" onClick={()=>navigate('/ml-analysis')}>
                  <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"/>
                  </svg>
                  View AI Growth Analysis
                </button>
              )}
            </div>

            {/* Upload Form */}
            {showUploadForm && (
              <div className="sd-upload-form">
                <h2 className="sd-form-title">Upload Certificate</h2>

                <div className="sd-ocr-banner">
                  <svg width="16" height="16" fill="none" stroke="#6366f1" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z"/>
                  </svg>
                  <span><strong>Smart OCR:</strong> Upload your file first — we'll automatically scan and fill in the title, date, and certificate ID for you.</span>
                </div>

                <form onSubmit={handleSubmit} className="sd-form-grid">

                  {/* FILE — first, triggers OCR */}
                  <div className="sd-field sd-field-full">
                    <label className="sd-label">Certificate File (PDF / JPG / PNG, max 10 MB) <span>*</span></label>
                    <input ref={fileInputRef} type="file" id="certificate-file"
                      accept=".pdf,.jpg,.jpeg,.png" onChange={handleFileChange} className="sd-file-input" required/>
                    {ocrRunning && (
                      <div className="sd-ocr-status sd-ocr-running">
                        <div className="sd-ocr-spinner"/> Scanning certificate with OCR...
                      </div>
                    )}
                    {ocrResult && !ocrRunning && (
                      <div className={`sd-ocr-status ${ocrResult.error ? 'sd-ocr-warn' : 'sd-ocr-ok'}`}>
                        {ocrResult.error ? `⚠️ ${ocrResult.error}` : '✅ Data extracted — fields auto-filled below. Edit if needed.'}
                      </div>
                    )}
                    {formData.file && !ocrRunning && (
                      <p className="sd-file-name">✓ {formData.file.name} ({(formData.file.size/1024/1024).toFixed(2)} MB)</p>
                    )}
                  </div>

                  <div className="sd-field sd-field-full">
                    <label className="sd-label">Certificate Title <span>*</span>
                      {ocrResult?.title && !ocrResult.error && <span className="sd-ocr-badge">OCR</span>}
                    </label>
                    <input type="text" name="title" value={formData.title} onChange={handleInputChange}
                      placeholder="e.g., Python for Data Science" className="sd-input" required/>
                  </div>

                  <div className="sd-field sd-field-full">
                    <label className="sd-label">Description <span>*</span></label>
                    <textarea name="description" value={formData.description} onChange={handleInputChange}
                      placeholder="Describe what you learned" rows={3} className="sd-textarea" required/>
                  </div>

                  <div className="sd-field">
                    <label className="sd-label">Issue Date <span>*</span>
                      {ocrResult?.issueDate && !ocrResult.error && <span className="sd-ocr-badge">OCR</span>}
                    </label>
                    <input type="date" name="issueDate" value={formData.issueDate} onChange={handleInputChange}
                      max={new Date().toISOString().split('T')[0]} className="sd-input" required/>
                  </div>

                  <div className="sd-field">
                    <label className="sd-label">Certificate Type</label>
                    <select name="certificateType" value={formData.certificateType} onChange={handleInputChange} className="sd-select">
                      <option value="course">Course</option>
                      <option value="internship">Internship</option>
                      <option value="other">Other</option>
                    </select>
                  </div>

                  {formData.certificateType === 'course' && (<>
                    <div className="sd-field">
                      <label className="sd-label">Course Start Date</label>
                      <input type="date" name="courseStartDate" value={formData.courseStartDate} onChange={handleInputChange}
                        max={new Date().toISOString().split('T')[0]} className="sd-input"/>
                    </div>
                    <div className="sd-field">
                      <label className="sd-label">Course End Date</label>
                      <input type="date" name="courseEndDate" value={formData.courseEndDate} onChange={handleInputChange}
                        max={new Date().toISOString().split('T')[0]} className="sd-input"/>
                    </div>
                  </>)}

                  {formData.certificateType === 'internship' && (<>
                    <div className="sd-field">
                      <label className="sd-label">Internship Start Date</label>
                      <input type="date" name="internshipStartDate" value={formData.internshipStartDate} onChange={handleInputChange}
                        max={new Date().toISOString().split('T')[0]} className="sd-input"/>
                    </div>
                    <div className="sd-field">
                      <label className="sd-label">Internship End Date</label>
                      <input type="date" name="internshipEndDate" value={formData.internshipEndDate} onChange={handleInputChange}
                        max={new Date().toISOString().split('T')[0]} className="sd-input"/>
                    </div>
                  </>)}

                  <div className="sd-field">
                    <label className="sd-label">Issuer
                      {ocrResult?.issuer && !ocrResult.error && <span className="sd-ocr-badge">OCR</span>}
                    </label>
                    <select name="issuer" value={formData.issuer} onChange={handleInputChange} className="sd-select">
                      {ISSUERS.map(i => <option key={i} value={i}>{i || 'Select Issuer'}</option>)}
                    </select>
                  </div>

                  <div className="sd-field">
                    <label className="sd-label">Certificate ID
                      {ocrResult?.certificateId && !ocrResult.error && <span className="sd-ocr-badge">OCR</span>}
                    </label>
                    <input type="text" name="certificateId" value={formData.certificateId} onChange={handleInputChange}
                      placeholder="Auto-extracted or enter manually" className="sd-input"/>
                  </div>

                  <div className="sd-field">
                    <label className="sd-label">QR Code Data
                      {ocrResult?.qrCodeData && !ocrResult.error && <span className="sd-ocr-badge">QR</span>}
                    </label>
                    <input type="text" name="qrCodeData" value={formData.qrCodeData} onChange={handleInputChange}
                      placeholder="Auto-detected or enter verification URL" className="sd-input"/>
                  </div>

                  <div className="sd-form-buttons sd-field-full">
                    <button type="button" className="sd-cancel-btn"
                      onClick={()=>{ setShowUploadForm(false); setFormData(EMPTY_FORM); setOcrResult(null); }}>
                      Cancel
                    </button>
                    <button type="submit" disabled={uploading||ocrRunning} className="sd-submit-btn">
                      {uploading ? 'Uploading…' : ocrRunning ? 'Scanning…' : 'Upload Certificate'}
                    </button>
                  </div>
                </form>
              </div>
            )}

            {/* Certificates list */}
            {loading ? (
              <div className="sd-loading"><div className="sd-spinner"/><p>Loading certificates...</p></div>
            ) : certificates.length === 0 ? (
              <div className="sd-empty">
                <svg width="60" height="60" fill="none" stroke="#d1d5db" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
                </svg>
                <h3 className="sd-empty-title">No Certificates Yet</h3>
                <p className="sd-empty-sub">Upload your first certificate to start building your portfolio!</p>
                <button className="sd-upload-btn" onClick={()=>setShowUploadForm(true)}>Upload Your First Certificate</button>
              </div>
            ) : (
              <div>
                <h2 className="sd-cert-heading">Your Certificates ({certificates.length})</h2>
                <div className="certificates-grid">
                  {certificates.map(cert => (
                    <CertificateCard key={cert._id} certificate={cert} showStudent={false} userRole="student"
                      onDownload={handleDownload} onDelete={handleDelete}/>
                  ))}
                </div>
              </div>
            )}
          </>
        )}

        {/* ═══════════════ INTERESTS TAB ═══════════════ */}
        {activeTab === 'interests' && (
          <div className="sd-interests-panel">
            <h2 className="sd-form-title">🎯 My Areas of Interest</h2>
            <p style={{ color:'#6b7280', marginBottom:'1.2rem', fontSize:'0.95rem' }}>
              Select the tech areas you're passionate about. The AI engine will identify your skill gaps and
              suggest targeted courses to fill them in the Growth Analysis.
            </p>
            <div className="sd-interest-grid">
              {ALL_INTERESTS.map(interest => {
                const certCount  = certificates.filter(c => c.category === interest).length;
                const isSelected = selectedInterests.includes(interest);
                return (
                  <button key={interest} onClick={()=>toggleInterest(interest)}
                    className={`sd-interest-chip ${isSelected?'sd-interest-chip--selected':''}`}>
                    <span className="sd-interest-label">{interest}</span>
                    {certCount > 0
                      ? <span className="sd-interest-count sd-interest-count--has">{certCount} cert{certCount>1?'s':''}</span>
                      : <span className="sd-interest-count sd-interest-count--gap">No certs — Gap!</span>}
                    {isSelected && <span className="sd-interest-check">✓</span>}
                  </button>
                );
              })}
            </div>
            {selectedInterests.length > 0 && (
              <p style={{ marginTop:'1rem', color:'#4f46e5', fontWeight:600, fontSize:'0.92rem' }}>
                Selected: {selectedInterests.join(', ')}
              </p>
            )}
            <div style={{ marginTop:'1.2rem', display:'flex', alignItems:'center', gap:'1rem' }}>
              <button onClick={handleSaveInterests} disabled={interestSaving} className="sd-submit-btn">
                {interestSaving ? 'Saving...' : '💾 Save Interests'}
              </button>
              {interestMsg && (
                <span style={{ fontSize:'0.9rem', color:interestMsg.startsWith('✅')?'#10b981':'#ef4444' }}>
                  {interestMsg}
                </span>
              )}
            </div>
            <div style={{ marginTop:'2rem', background:'#f0fdf4', borderRadius:12, padding:'1rem 1.5rem', border:'1px solid #bbf7d0' }}>
              <h3 style={{ color:'#166534', fontWeight:700, marginBottom:'0.5rem' }}>How this works</h3>
              <ul style={{ color:'#15803d', fontSize:'0.9rem', paddingLeft:'1.2rem', lineHeight:1.8 }}>
                <li>Interests with <strong>no certificates</strong> → 🔥 <em>Interest Gap</em> — High Priority in AI Analysis.</li>
                <li>Interests with <strong>existing certificates</strong> → ⭐ advanced course suggestions.</li>
                <li>The Random Forest model weighs your interests alongside your full certificate history.</li>
              </ul>
            </div>
          </div>
        )}

        {/* ═══════════════ FEEDBACK INBOX TAB ═══════════════ */}
        {activeTab === 'feedback' && (
          <div className="fb-inbox-root">
            <div className="fb-inbox-header">
              <div className="fb-inbox-title-row">
                <svg width="20" height="20" fill="none" stroke="#6366f1" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z"/>
                </svg>
                <h2 className="fb-inbox-title">Feedback from Teachers</h2>
                {feedbackUnread > 0 && <span className="fb-inbox-unread-badge">{feedbackUnread} unread</span>}
              </div>
              {feedbackUnread > 0 && (
                <button onClick={handleMarkAllFeedbackRead} className="fb-mark-all-btn">Mark all as read</button>
              )}
            </div>

            {loadingFeedback ? (
              <div className="fb-loading"><div className="fb-spinner"/><p>Loading feedback...</p></div>
            ) : feedbacks.length === 0 ? (
              <div className="fb-empty">
                <svg width="52" height="52" fill="none" stroke="#d1d5db" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z"/>
                </svg>
                <p>No feedback yet</p>
                <span>Your teachers' feedback will appear here</span>
              </div>
            ) : (
              <div className="fb-inbox-list">
                {feedbacks.map(fb => (
                  <div key={fb._id} className={`fb-inbox-item ${!fb.isRead?'fb-inbox-item-unread':''}`}
                    onClick={()=>!fb.isRead&&handleMarkFeedbackRead(fb._id)}>
                    {!fb.isRead && <span className="fb-inbox-dot"/>}
                    <div className="fb-inbox-avatar">{fb.teacher?.name?.[0]?.toUpperCase()||'T'}</div>
                    <div className="fb-inbox-body">
                      <div className="fb-inbox-meta">
                        <span className="fb-inbox-teacher">{fb.teacher?.name||'Teacher'}</span>
                        {fb.teacher?.department && <span className="fb-inbox-dept">{fb.teacher.department}</span>}
                        <span className={`fb-type-pill ${typeColors[fb.type]||'fb-type-general'}`}>{typeLabels[fb.type]||fb.type}</span>
                        <span className="fb-inbox-date">{fmtDate(fb.createdAt)}</span>
                      </div>
                      {fb.certificate && (
                        <div className="fb-inbox-cert-ref">
                          <svg width="12" height="12" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
                          </svg>
                          Re: {fb.certificate.title}
                        </div>
                      )}
                      <p className="fb-inbox-msg">{fb.message}</p>
                      {!fb.isRead && <span className="fb-inbox-new-badge">NEW</span>}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

      </div>
    </div>
  );
};

export default StudentDashboard;
