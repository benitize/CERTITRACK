import React, { useState, useEffect } from 'react';
import { adminAPI, certificateAPI } from '../services/api';
import { formatDate, getErrorMessage } from '../utils/helpers';
import CertificateCard from '../components/CertificateCard';

const AdminDashboard = () => {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [stats, setStats] = useState(null);
  const [pendingUsers, setPendingUsers] = useState([]);
  const [allUsers, setAllUsers] = useState([]);
  const [allCertificates, setAllCertificates] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [userFilter, setUserFilter] = useState('all');

  useEffect(() => {
    if (activeTab === 'dashboard') {
      fetchDashboardStats();
    } else if (activeTab === 'approvals') {
      fetchPendingApprovals();
    } else if (activeTab === 'users') {
      fetchAllUsers();
    } else if (activeTab === 'certificates') {
      fetchAllCertificates();
    }
  }, [activeTab]);

  const fetchDashboardStats = async () => {
    setLoading(true);
    try {
      const response = await adminAPI.getDashboardStats();
      setStats(response.data);
    } catch (error) {
      setError(getErrorMessage(error));
    } finally {
      setLoading(false);
    }
  };

  const fetchPendingApprovals = async () => {
    setLoading(true);
    try {
      const response = await adminAPI.getPendingApprovals();
      setPendingUsers(response.data.pendingUsers);
    } catch (error) {
      setError(getErrorMessage(error));
    } finally {
      setLoading(false);
    }
  };

  const fetchAllUsers = async () => {
    setLoading(true);
    try {
      const response = await adminAPI.getUsers({ role: userFilter === 'all' ? '' : userFilter });
      setAllUsers(response.data.users);
    } catch (error) {
      setError(getErrorMessage(error));
    } finally {
      setLoading(false);
    }
  };

  const fetchAllCertificates = async () => {
    setLoading(true);
    try {
      const response = await certificateAPI.getAllCertificates();
      setAllCertificates(response.data.certificates);
    } catch (error) {
      setError(getErrorMessage(error));
    } finally {
      setLoading(false);
    }
  };

  const handleApprove = async (userId) => {
    try {
      await adminAPI.approveUser(userId);
      setPendingUsers(pendingUsers.filter(u => u._id !== userId));
      alert('User approved successfully');
      fetchDashboardStats();
    } catch (error) {
      alert(getErrorMessage(error));
    }
  };

  const handleReject = async (userId) => {
    if (window.confirm('Are you sure you want to reject this user?')) {
      try {
        await adminAPI.rejectUser(userId);
        setPendingUsers(pendingUsers.filter(u => u._id !== userId));
        alert('User rejected successfully');
        fetchDashboardStats();
      } catch (error) {
        alert(getErrorMessage(error));
      }
    }
  };

  const handleDeleteUser = async (userId) => {
    if (window.confirm('Are you sure you want to delete this user? This action cannot be undone.')) {
      try {
        await adminAPI.deleteUser(userId);
        setAllUsers(allUsers.filter(u => u._id !== userId));
        alert('User deleted successfully');
      } catch (error) {
        alert(getErrorMessage(error));
      }
    }
  };

  const handleDownloadCertificate = async (certId) => {
    try {
      const response = await certificateAPI.download(certId);
      const blob = new Blob([response.data]);
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `certificate-${certId}.pdf`;
      link.click();
    } catch (error) {
      alert(getErrorMessage(error));
    }
  };

  const handleDeleteCertificate = async (certId) => {
    try {
      await certificateAPI.delete(certId);
      setAllCertificates(allCertificates.filter(c => c._id !== certId));
      alert('Certificate deleted successfully');
    } catch (error) {
      alert(getErrorMessage(error));
    }
  };

  const handleVerifyCertificate = async (certId) => {
    try {
      await certificateAPI.verify(certId);
      setAllCertificates(allCertificates.map(cert =>
        cert._id === certId
          ? { ...cert, verificationStatus: 'verified', verificationMethod: 'manual', verifiedAt: new Date() }
          : cert
      ));
      alert('Certificate verified successfully!');
    } catch (error) {
      alert(getErrorMessage(error));
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Admin Dashboard</h1>
          <p className="text-gray-600 mt-2">Manage users, approvals, and certificates</p>
        </div>

        {/* Tabs */}
        <div className="bg-white rounded-lg shadow mb-6">
          <div className="border-b border-gray-200">
            <nav className="flex -mb-px">
              <button
                onClick={() => setActiveTab('dashboard')}
                className={`px-6 py-4 text-sm font-medium ${
                  activeTab === 'dashboard'
                    ? 'border-b-2 border-blue-500 text-blue-600'
                    : 'text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                Dashboard
              </button>
              <button
                onClick={() => setActiveTab('approvals')}
                className={`px-6 py-4 text-sm font-medium ${
                  activeTab === 'approvals'
                    ? 'border-b-2 border-blue-500 text-blue-600'
                    : 'text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                Pending Approvals
                {stats && stats.pendingApprovals > 0 && (
                  <span className="ml-2 bg-red-100 text-red-600 px-2 py-0.5 rounded-full text-xs">
                    {stats.pendingApprovals}
                  </span>
                )}
              </button>
              <button
                onClick={() => setActiveTab('users')}
                className={`px-6 py-4 text-sm font-medium ${
                  activeTab === 'users'
                    ? 'border-b-2 border-blue-500 text-blue-600'
                    : 'text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                Manage Users
              </button>
              <button
                onClick={() => setActiveTab('certificates')}
                className={`px-6 py-4 text-sm font-medium ${
                  activeTab === 'certificates'
                    ? 'border-b-2 border-blue-500 text-blue-600'
                    : 'text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                All Certificates
              </button>
            </nav>
          </div>

          {/* Tab Content */}
          <div className="p-6">
            {error && (
              <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
                {error}
              </div>
            )}

            {loading ? (
              <div className="text-center py-12">
                <div className="inline-block animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
                <p className="mt-4 text-gray-600">Loading...</p>
              </div>
            ) : (
              <>
                {/* Dashboard Tab */}
                {activeTab === 'dashboard' && stats && (
                  <div>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                      <div className="bg-blue-50 rounded-lg p-6">
                        <div className="flex items-center justify-between">
                          <div>
                            <p className="text-blue-600 text-sm font-medium">Total Students</p>
                            <p className="text-3xl font-bold text-blue-900 mt-2">{stats.totalStudents}</p>
                          </div>
                          <div className="bg-blue-100 rounded-full p-3">
                            <svg className="w-8 h-8 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" />
                            </svg>
                          </div>
                        </div>
                      </div>

                      <div className="bg-green-50 rounded-lg p-6">
                        <div className="flex items-center justify-between">
                          <div>
                            <p className="text-green-600 text-sm font-medium">Total Teachers</p>
                            <p className="text-3xl font-bold text-green-900 mt-2">{stats.totalTeachers}</p>
                          </div>
                          <div className="bg-green-100 rounded-full p-3">
                            <svg className="w-8 h-8 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                            </svg>
                          </div>
                        </div>
                      </div>

                      <div className="bg-yellow-50 rounded-lg p-6">
                        <div className="flex items-center justify-between">
                          <div>
                            <p className="text-yellow-600 text-sm font-medium">Pending Approvals</p>
                            <p className="text-3xl font-bold text-yellow-900 mt-2">{stats.pendingApprovals}</p>
                          </div>
                          <div className="bg-yellow-100 rounded-full p-3">
                            <svg className="w-8 h-8 text-yellow-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                            </svg>
                          </div>
                        </div>
                      </div>

                      <div className="bg-purple-50 rounded-lg p-6">
                        <div className="flex items-center justify-between">
                          <div>
                            <p className="text-purple-600 text-sm font-medium">Total Certificates</p>
                            <p className="text-3xl font-bold text-purple-900 mt-2">{stats.totalCertificates}</p>
                          </div>
                          <div className="bg-purple-100 rounded-full p-3">
                            <svg className="w-8 h-8 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                            </svg>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Recent Activity */}
                    <div className="bg-white rounded-lg border border-gray-200 p-6">
                      <h3 className="text-lg font-semibold mb-4">Recent Activity</h3>
                      <div className="space-y-3">
                        {stats.recentActivity && stats.recentActivity.length > 0 ? (
                          stats.recentActivity.map((activity, index) => (
                            <div key={index} className="flex items-center justify-between py-2 border-b last:border-b-0">
                              <div className="flex items-center">
                                <div className={`w-2 h-2 rounded-full mr-3 ${activity.isApproved ? 'bg-green-500' : 'bg-yellow-500'}`}></div>
                                <div>
                                  <p className="font-medium">{activity.name}</p>
                                  <p className="text-sm text-gray-500">
                                    {activity.role} • {activity.isApproved ? 'Approved' : 'Pending'}
                                  </p>
                                </div>
                              </div>
                              <span className="text-sm text-gray-500">{formatDate(activity.registeredAt)}</span>
                            </div>
                          ))
                        ) : (
                          <p className="text-gray-500 text-center py-4">No recent activity</p>
                        )}
                      </div>
                    </div>
                  </div>
                )}

                {/* Pending Approvals Tab */}
                {activeTab === 'approvals' && (
                  <div>
                    {pendingUsers.length === 0 ? (
                      <div className="text-center py-12">
                        <svg className="w-16 h-16 text-gray-400 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                        </svg>
                        <p className="text-gray-600">No pending approvals</p>
                      </div>
                    ) : (
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        {pendingUsers.map((user) => (
                          <div key={user._id} className="bg-white border rounded-lg p-6 hover:shadow-md transition-shadow">
                            <div className="flex justify-between items-start mb-4">
                              <div>
                                <h3 className="text-lg font-semibold">{user.name}</h3>
                                <p className="text-sm text-gray-600">{user.email}</p>
                              </div>
                              <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                                user.role === 'student' ? 'bg-blue-100 text-blue-800' : 'bg-green-100 text-green-800'
                              }`}>
                                {user.role}
                              </span>
                            </div>

                            <div className="space-y-2 mb-4">
                              {user.rollNumber && (
                                <p className="text-sm"><span className="font-medium">Roll No:</span> {user.rollNumber}</p>
                              )}
                              {user.department && (
                                <p className="text-sm"><span className="font-medium">Department:</span> {user.department}</p>
                              )}
                              {user.subject && (
                                <p className="text-sm"><span className="font-medium">Subject:</span> {user.subject}</p>
                              )}
                              <p className="text-sm text-gray-500">Registered: {formatDate(user.registeredAt)}</p>
                            </div>

                            <div className="flex gap-2">
                              <button
                                onClick={() => handleApprove(user._id)}
                                className="flex-1 bg-green-600 text-white px-4 py-2 rounded-md hover:bg-green-700 transition-colors"
                              >
                                Approve
                              </button>
                              <button
                                onClick={() => handleReject(user._id)}
                                className="flex-1 bg-red-600 text-white px-4 py-2 rounded-md hover:bg-red-700 transition-colors"
                              >
                                Reject
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                )}

                {/* Manage Users Tab */}
                {activeTab === 'users' && (
                  <div>
                    <div className="mb-4">
                      <select
                        value={userFilter}
                        onChange={(e) => setUserFilter(e.target.value)}
                        className="px-4 py-2 border border-gray-300 rounded-md"
                      >
                        <option value="all">All Users</option>
                        <option value="student">Students Only</option>
                        <option value="teacher">Teachers Only</option>
                      </select>
                    </div>

                    {allUsers.length === 0 ? (
                      <p className="text-center py-12 text-gray-600">No users found</p>
                    ) : (
                      <div className="overflow-x-auto">
                        <table className="min-w-full bg-white border border-gray-200">
                          <thead className="bg-gray-50">
                            <tr>
                              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Name</th>
                              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Email</th>
                              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Role</th>
                              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Details</th>
                              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Certificates</th>
                              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-gray-200">
                            {allUsers.map((user) => (
                              <tr key={user._id}>
                                <td className="px-6 py-4 whitespace-nowrap">{user.name}</td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">{user.email}</td>
                                <td className="px-6 py-4 whitespace-nowrap">
                                  <span className={`px-2 py-1 rounded-full text-xs ${
                                    user.role === 'student' ? 'bg-blue-100 text-blue-800' : 'bg-green-100 text-green-800'
                                  }`}>
                                    {user.role}
                                  </span>
                                </td>
                                <td className="px-6 py-4 text-sm">
                                  {user.rollNumber && <div>Roll: {user.rollNumber}</div>}
                                  {user.department && <div>Dept: {user.department}</div>}
                                  {user.subject && <div>Subject: {user.subject}</div>}
                                </td>
                                <td className="px-6 py-4 whitespace-nowrap">
                                  {user.certificateCount || 0}
                                </td>
                                <td className="px-6 py-4 whitespace-nowrap">
                                  <button
                                    onClick={() => handleDeleteUser(user._id)}
                                    className="text-red-600 hover:text-red-800"
                                  >
                                    Delete
                                  </button>
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    )}
                  </div>
                )}

                {/* All Certificates Tab */}
                {activeTab === 'certificates' && (
                  <div>
                    {allCertificates.length === 0 ? (
                      <p className="text-center py-12 text-gray-600">No certificates found</p>
                    ) : (
                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        {allCertificates.map((cert) => (
                          <CertificateCard
                            key={cert._id}
                            certificate={cert}
                            showStudent={true}
                            userRole="admin"
                            onDownload={handleDownloadCertificate}
                            onDelete={handleDeleteCertificate}
                            onVerify={handleVerifyCertificate}
                          />
                        ))}
                      </div>
                    )}
                  </div>
                )}
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;
