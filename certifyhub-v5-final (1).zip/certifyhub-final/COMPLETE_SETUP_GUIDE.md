# CertifyHub - Complete Setup & Installation Guide

## 📦 What You're Getting

A complete full-stack MERN application with:
- ✅ Backend API with Express.js, MongoDB, Socket.io
- ✅ ML Growth Analysis (Random Forest with 5 Decision Trees)
- ✅ NLP Search Engine (Natural.js + Compromise.js)
- ✅ Certificate Verification System
- ✅ Real-time Notifications
- ✅ Role-based Authentication (Admin, Teacher, Student)
- ✅ React Frontend (To be completed by you using the structure provided)

## 🚀 Quick Start (5 Minutes)

### Step 1: Install Prerequisites

```bash
# Install Node.js (v14+)
# Download from: https://nodejs.org/

# Install MongoDB (v4.4+)
# macOS:
brew tap mongodb/brew
brew install mongodb-community

# Ubuntu:
sudo apt-get install mongodb

# Or use Docker:
docker run -d -p 27017:27017 --name mongodb mongo:latest
```

### Step 2: Setup Backend

```bash
cd certifyhub/backend

# Install dependencies
npm install

# Start MongoDB
brew services start mongodb-community  # macOS
# OR
sudo systemctl start mongod  # Linux

# Create admin account
npm run create-admin
# Enter admin details when prompted

# Start backend server
npm run dev
```

Backend will run on: `http://localhost:5000`

### Step 3: Setup Frontend (React)

The frontend structure is provided. To complete it:

```bash
cd certifyhub/frontend

# Install dependencies
npm install

# Start React app
npm start
```

Frontend will run on: `http://localhost:3000`

## 📋 Backend Features (FULLY IMPLEMENTED)

### ✅ Complete Backend Implementation

#### Authentication System
- JWT-based auth with bcrypt hashing
- Role-based access (Admin, Teacher, Student)
- Admin approval workflow
- Protected routes with middleware

#### Certificate Management
- Upload with automatic categorization
- NLP keyword extraction
- Certificate verification (QR/Certificate ID)
- Download/Delete functionality
- File validation (PDF, JPG, PNG)

#### NLP Search Engine
- Natural.js for tokenization
- Compromise.js for semantic analysis
- Keyword extraction algorithm
- Smart categorization (8 categories)
- Relevance-based ranking

#### ML Growth Analysis
**Random Forest Algorithm:**
- 5 Decision Trees
- 11 Feature Extraction
- Career Readiness Score (0-100)
- Skill Level Prediction
- Role Prediction with Confidence
- AI-powered Recommendations

**Trees Breakdown:**
1. Certificate Volume Analysis (5-25 pts)
2. Skill Diversity Analysis (0-20 pts)
3. Learning Progression (0-25 pts)
4. Growth Rate Consistency (0-15 pts)
5. Specialization Bonuses (0-15 pts)

#### Real-time Notifications
- Socket.io integration
- Teacher notifications on uploads
- Notification management
- Real-time badge updates

#### Admin Dashboard
- Statistics cards
- Pending approvals
- User management
- Certificate moderation

## 🏗️ Frontend Structure (TO BE IMPLEMENTED)

The frontend requires React components for:

### Pages Needed:
1. **Login/Register** - Authentication forms
2. **Admin Dashboard** - Stats, approvals, user management
3. **Teacher Dashboard** - Student list, certificate search, notifications
4. **Student Dashboard** - Upload certificates, view analysis
5. **Growth Analysis** - ML predictions, charts, recommendations

### Key Features to Implement:
- React Router for navigation
- Context API for state management
- Axios for API calls
- Socket.io client for real-time features
- Recharts for data visualization
- Form handling and validation
- Responsive design with Tailwind CSS

## 🔧 Environment Configuration

### Backend .env
```env
PORT=5000
MONGODB_URI=mongodb://localhost:27017/certifyhub
JWT_SECRET=your_super_secret_key_change_this
JWT_EXPIRE=7d
NODE_ENV=development
FRONTEND_URL=http://localhost:3000
```

## 🧪 Testing the System

### 1. Create Admin
```bash
cd backend
npm run create-admin
```

### 2. Test API
```bash
# Health check
curl http://localhost:5000/api/health

# Register a student
curl -X POST http://localhost:5000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Test Student",
    "email": "student@test.com",
    "password": "password123",
    "role": "student",
    "rollNumber": "CS2024001",
    "department": "CSE"
  }'

# Login as admin
curl -X POST http://localhost:5000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "admin@certifyhub.com",
    "password": "your_admin_password"
  }'
```

### 3. Use Postman Collection
Import the API endpoints into Postman for easy testing.

## 📊 Database Schema

### User Collection
```javascript
{
  name: String,
  email: String (unique),
  password: String (hashed),
  role: Enum['student', 'teacher', 'admin'],
  rollNumber: String (students),
  department: Enum (students),
  subject: String (teachers),
  isApproved: Boolean,
  notifications: Array (teachers),
  createdAt: Date
}
```

### Certificate Collection
```javascript
{
  student: ObjectId (ref: User),
  title: String,
  description: String,
  issueDate: Date,
  fileName: String,
  filePath: String,
  fileType: Enum['pdf', 'jpg', 'jpeg', 'png'],
  certificateId: String,
  issuer: Enum,
  qrCodeData: String,
  isVerified: Boolean,
  verificationMethod: String,
  verifiedBy: ObjectId,
  verificationDate: Date,
  keywords: Array[String],
  category: Enum,
  uploadDate: Date
}
```

## 🎯 User Flows

### Student Flow
1. Register → Wait for approval
2. Login (after approval)
3. Upload certificates with metadata
4. View own certificates
5. Check growth analysis
6. Download certificates

### Teacher Flow
1. Register → Wait for approval
2. Login (after approval)
3. View all students
4. Search certificates (NLP)
5. Filter by year/status
6. Receive real-time notifications
7. Verify certificates
8. View own growth analysis

### Admin Flow
1. Login (created via script)
2. View dashboard stats
3. Approve/Reject registrations
4. Manage users
5. View all certificates
6. Delete users/certificates

## 🚨 Common Issues & Solutions

### MongoDB Connection Failed
```bash
# Check MongoDB status
brew services list  # macOS
sudo systemctl status mongod  # Linux

# Start MongoDB
brew services start mongodb-community
```

### Port Already in Use
```bash
# Find and kill process
lsof -i :5000
kill -9 <PID>
```

### JWT Token Issues
- Check JWT_SECRET in .env
- Ensure token is included in Authorization header
- Format: `Bearer <token>`

### File Upload Issues
- Check file size (max 10MB)
- Verify file type (PDF, JPG, PNG)
- Ensure uploads directory exists

## 📈 Performance Optimization

### Backend
- Indexed MongoDB fields for fast queries
- Efficient NLP algorithms
- Optimized ML feature extraction
- Socket.io room-based notifications

### Frontend (Recommendations)
- Lazy load components
- Memoize expensive computations
- Debounce search inputs
- Paginate large lists
- Cache API responses

## 🔒 Security Best Practices

✅ Implemented:
- Password hashing with bcrypt
- JWT authentication
- Role-based authorization
- File type validation
- Admin approval system

📝 Recommended:
- Rate limiting
- HTTPS in production
- Input sanitization
- CORS configuration
- Security headers

## 🚀 Deployment Guide

### Backend Deployment
```bash
# Build for production
NODE_ENV=production npm start

# Environment variables
# Set JWT_SECRET, MONGODB_URI, FRONTEND_URL
```

### Recommended Platforms
- **Backend**: Heroku, Railway, Render, AWS EC2
- **Database**: MongoDB Atlas (Free tier available)
- **Frontend**: Vercel, Netlify, AWS S3 + CloudFront

## 📚 API Documentation

Full API documentation available in `backend/README.md`

**Key Endpoints:**
- Auth: `/api/auth/*`
- Certificates: `/api/certificates/*`
- Admin: `/api/admin/*`
- ML Analysis: `/api/ml/*`
- Notifications: `/api/notifications/*`

## 🆘 Support & Resources

- Backend README: Detailed API documentation
- Project Structure: See `PROJECT_STRUCTURE.md`
- NLP Service: `backend/utils/nlpService.js`
- ML Service: `backend/utils/mlService.js`

## ✅ Verification Checklist

Before deployment, verify:
- [ ] MongoDB is running
- [ ] Admin account created
- [ ] Environment variables set
- [ ] Backend server starts without errors
- [ ] Can register and login users
- [ ] File uploads work
- [ ] Socket.io connections established
- [ ] ML analysis generates results
- [ ] NLP search returns relevant results

## 🎓 Learning Resources

- **MERN Stack**: MongoDB, Express, React, Node.js
- **NLP**: Natural.js, Compromise.js documentation
- **ML**: Random Forest algorithm theory
- **WebSockets**: Socket.io guides
- **Authentication**: JWT best practices

---

## 🏁 Next Steps

1. ✅ Backend is complete and production-ready
2. 📝 Implement React frontend components
3. 🎨 Design UI/UX with Tailwind CSS
4. 🧪 Test all features thoroughly
5. 🚀 Deploy to production

**Backend Status**: ✅ 100% Complete
**Frontend Status**: 🏗️ Structure provided, needs implementation

Good luck with your CertifyHub project! 🎓🚀
