# CertifyHub - AI-Powered Certificate Management System

A full-stack MERN application with Machine Learning growth analysis, NLP-powered search, and real-time notifications.

## 🎯 Features

### Core Functionality
- **3 User Roles**: Admin, Teacher, Student with role-based access control
- **Certificate Management**: Upload, verify, search, and download certificates
- **ML Growth Analysis**: Random Forest algorithm for career predictions
- **NLP Search**: Natural language certificate search using Natural.js + Compromise.js
- **Real-time Notifications**: Socket.io for instant updates
- **Certificate Verification**: Multi-issuer verification system (Coursera, Udemy, LinkedIn, Google, Microsoft, AWS)

### Admin Features
- Dashboard with statistics
- Approve/reject student and teacher registrations
- View all users and certificates
- Content moderation capabilities

### Teacher Features
- View all students with certificate counts
- NLP-powered certificate search across all students
- Filter by year and verification status
- Download certificates
- Real-time notifications for new uploads
- View ML growth analysis

### Student Features
- Upload certificates with metadata
- View all uploaded certificates
- ML-powered growth analysis with career predictions
- Download certificates
- Track verification status

## 📋 Prerequisites

- Node.js (v14 or higher)
- MongoDB (v4.4 or higher)
- npm or yarn

## 🚀 Installation

### 1. Clone and Setup

```bash
# Navigate to the project directory
cd certifyhub

# Install backend dependencies
cd backend
npm install

# Install frontend dependencies
cd ../frontend
npm install
```

### 2. Environment Configuration

Create a `.env` file in the `backend` directory:

```env
PORT=5000
MONGODB_URI=mongodb://localhost:27017/certifyhub
JWT_SECRET=your-super-secret-jwt-key-change-this-in-production-make-it-long-and-random
NODE_ENV=development
CLIENT_URL=http://localhost:3000
```

### 3. Database Setup

Make sure MongoDB is running:

```bash
# Start MongoDB (if not running as service)
mongod

# Or if using MongoDB service
sudo systemctl start mongod
```

### 4. Create Admin Account

```bash
cd backend
npm run create-admin
```

Follow the prompts to create your admin account.

### 5. Start the Application

**Terminal 1 - Backend:**
```bash
cd backend
npm run dev
```

**Terminal 2 - Frontend:**
```bash
cd frontend
npm start
```

The application will be available at:
- Frontend: http://localhost:3000
- Backend API: http://localhost:5000

## 📁 Project Structure

```
certifyhub/
├── backend/
│   ├── models/
│   │   ├── User.js              # User schema with roles and notifications
│   │   └── Certificate.js       # Certificate schema with verification
│   ├── routes/
│   │   ├── auth.js              # Authentication routes
│   │   ├── certificates.js      # Certificate CRUD operations
│   │   ├── admin.js             # Admin management routes
│   │   └── ml.js                # ML analysis routes
│   ├── services/
│   │   ├── nlpService.js        # NLP categorization and search
│   │   ├── mlService.js         # Random Forest ML analysis
│   │   └── verificationService.js # Certificate verification
│   ├── middleware/
│   │   ├── auth.js              # JWT authentication
│   │   └── upload.js            # File upload configuration
│   ├── scripts/
│   │   └── createAdmin.js       # Admin creation script
│   ├── uploads/                 # Certificate files
│   ├── server.js                # Main server with Socket.io
│   ├── package.json
│   └── .env
├── frontend/
│   ├── src/
│   │   ├── components/          # Reusable components
│   │   ├── pages/               # Page components
│   │   │   ├── Login.js
│   │   │   ├── Register.js
│   │   │   ├── AdminDashboard.js
│   │   │   ├── TeacherDashboard.js
│   │   │   ├── StudentDashboard.js
│   │   │   └── MLAnalysis.js
│   │   ├── services/
│   │   │   ├── api.js           # API service
│   │   │   └── socket.js        # Socket.io client
│   │   ├── context/
│   │   │   └── AuthContext.js   # Authentication context
│   │   ├── App.js
│   │   └── index.js
│   └── package.json
└── README.md
```

## 🔑 Default Login Credentials

After creating an admin account with the script:

**Admin:**
- Email: (the one you created)
- Password: (the one you created)

**Test Users:**
You need to register students and teachers through the registration page, then approve them via the admin dashboard.

## 📊 ML Growth Analysis Features

The Random Forest-based analysis provides:

1. **Skill Level Score (0-100)**
   - Based on certificate volume, diversity, and progression
   
2. **Career Readiness Score (0-100)**
   - 5 Decision Trees:
     - Tree 1: Certificate volume (0-25 points)
     - Tree 2: Skill diversity (0-20 points)
     - Tree 3: Learning progression (0-25 points)
     - Tree 4: Growth rate consistency (0-15 points)
     - Tree 5: Specialization bonus (0-15 points)

3. **Career Role Predictions**
   - Backend Developer
   - Frontend Developer
   - Full Stack Developer
   - Cloud Engineer
   - Data Scientist/ML Engineer
   - Mobile App Developer
   - With confidence percentages

4. **AI Recommendations**
   - Skill gap analysis
   - Priority levels (High, Medium, Low)
   - Estimated learning time
   - Personalized suggestions

5. **Visualizations**
   - Growth chart (cumulative certificates over time)
   - Peer comparison within department
   - Skill distribution

## 🔍 NLP Search Features

- Keyword extraction from titles and descriptions
- Automatic categorization (8 categories):
  - Programming
  - Backend
  - Frontend
  - Database
  - Cloud
  - AI/ML
  - Mobile
  - Other

- Skill level detection:
  - Beginner
  - Intermediate
  - Advanced

- Natural language queries:
  - "Java internship"
  - "React course"
  - "Machine learning certification"

## 🔔 Real-Time Notifications

- Instant notifications when students upload certificates
- Notification bell with unread count
- Mark as read/unread
- Mark all as read
- Delete notifications
- Persistent storage

## ✅ Certificate Verification

Supported verification methods:
1. QR Code verification
2. Certificate ID verification
3. Manual verification (by teacher/admin)

Supported issuers:
- Coursera
- Udemy
- LinkedIn Learning
- Google
- Microsoft
- AWS

## 🔒 Security Features

- JWT-based authentication
- Bcrypt password hashing (10 rounds)
- Role-based access control
- Approval workflow for students and teachers
- Protected routes
- File upload validation
- CORS protection

## 🛠️ API Endpoints

### Authentication
- `POST /api/auth/register` - Register new user
- `POST /api/auth/login` - Login
- `GET /api/auth/me` - Get current user
- `GET /api/auth/verify-token` - Verify JWT token

### Certificates
- `POST /api/certificates/upload` - Upload certificate (Students)
- `GET /api/certificates/my-certificates` - Get own certificates (Students)
- `GET /api/certificates/all` - Get all certificates (Teachers/Admins)
- `GET /api/certificates/search` - NLP search (Teachers/Admins)
- `GET /api/certificates/download/:id` - Download certificate
- `DELETE /api/certificates/:id` - Delete certificate
- `PUT /api/certificates/verify/:id` - Manual verification (Teachers/Admins)

### Admin
- `GET /api/admin/pending-approvals` - Get pending users
- `PUT /api/admin/approve/:userId` - Approve user
- `DELETE /api/admin/reject/:userId` - Reject user
- `GET /api/admin/users` - Get all users
- `GET /api/admin/students` - Get all students
- `DELETE /api/admin/users/:userId` - Delete user
- `GET /api/admin/dashboard/stats` - Dashboard statistics

### ML Analysis
- `GET /api/ml/growth-analysis` - Get own ML analysis (Students)
- `GET /api/ml/growth-analysis/:studentId` - Get student analysis (Teachers/Admins)

### Notifications
- `GET /api/notifications` - Get user notifications

## 🧪 Testing

### Manual Testing Steps

1. **Create Admin Account**
   ```bash
   npm run create-admin
   ```

2. **Register Test Users**
   - Register 2-3 students with different departments
   - Register 1-2 teachers
   
3. **Admin Approval**
   - Login as admin
   - Navigate to "Pending Approvals"
   - Approve students and teachers

4. **Upload Certificates**
   - Login as student
   - Upload 5-10 certificates with varying:
     - Issue dates
     - Categories (Backend, Frontend, etc.)
     - Verification data

5. **Test ML Analysis**
   - Click "View AI Growth Analysis"
   - Verify all scores and predictions

6. **Test NLP Search**
   - Login as teacher
   - Search for "Python", "React", etc.
   - Test year filters

7. **Test Notifications**
   - Have student upload certificate
   - Verify teacher receives real-time notification

## 📈 Performance Considerations

- Indexed database queries for fast searches
- Pagination recommended for large datasets (not implemented in v1)
- File size limit: 10MB per certificate
- Socket.io connection pooling

## 🐛 Troubleshooting

### MongoDB Connection Error
```
Error: connect ECONNREFUSED 127.0.0.1:27017
```
**Solution:** Make sure MongoDB is running:
```bash
sudo systemctl start mongod
```

### Port Already in Use
```
Error: listen EADDRINUSE :::5000
```
**Solution:** Change PORT in `.env` or kill process using port 5000

### CORS Error
```
Access to XMLHttpRequest has been blocked by CORS policy
```
**Solution:** Verify `CLIENT_URL` in backend `.env` matches frontend URL

### Socket.io Not Connecting
**Solution:** Check that both frontend and backend are running and CORS is properly configured

## 🚧 Future Enhancements

- [ ] Email notifications for approvals
- [ ] Bulk certificate upload
- [ ] Export analysis as PDF
- [ ] Advanced analytics dashboard
- [ ] Certificate templates
- [ ] OCR for automatic data extraction
- [ ] Mobile app
- [ ] Multi-language support

## 📝 License

This project is for educational purposes.

## 👥 Support

For issues and questions:
1. Check the troubleshooting section
2. Review the API documentation
3. Check console logs for errors

## 🙏 Acknowledgments

- Natural.js for NLP capabilities
- Compromise.js for text processing
- Recharts for data visualization
- Socket.io for real-time features

---

**Built with ❤️ using MERN Stack**
