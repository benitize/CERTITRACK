const express     = require('express');
const router      = express.Router();
const Certificate = require('../models/Certificate');
const User        = require('../models/User');
const { auth }    = require('../middleware/auth');
const { performMLAnalysis } = require('../services/mlService');

/* GET /api/ml/growth-analysis  (own — student) */
router.get('/growth-analysis', auth, async (req, res) => {
  try {
    if (req.userRole !== 'student') return res.status(200).json({ message:'ML Analysis available for students only', userRole:req.userRole });

    const student = await User.findById(req.userId).select('department areasOfInterest');
    const certs   = await Certificate.find({ student: req.userId }).lean();
    if (!certs || certs.length === 0) return res.status(200).json({ message:'No certificates found. Upload certificates to view growth analysis.', hasData:false });

    const analysis = performMLAnalysis(certs, student.department, student.areasOfInterest || []);
    if (analysis.error) return res.status(200).json(analysis);
    res.json({ hasData:true, analysis, generatedAt:new Date() });
  } catch(e) { console.error('ML error:', e); res.status(500).json({ error:'Server error during ML analysis' }); }
});

/* GET /api/ml/growth-analysis/:studentId  (teacher/admin) */
router.get('/growth-analysis/:studentId', auth, async (req, res) => {
  try {
    if (req.userRole !== 'teacher' && req.userRole !== 'admin') return res.status(403).json({ error:'Access denied' });
    const student = await User.findById(req.params.studentId).select('name department areasOfInterest role');
    if (!student || student.role !== 'student') return res.status(404).json({ error:'Student not found' });

    const certs = await Certificate.find({ student: req.params.studentId }).lean();
    if (!certs || certs.length === 0) return res.status(200).json({ message:'No certificates for this student.', hasData:false, studentName:student.name });

    const analysis = performMLAnalysis(certs, student.department, student.areasOfInterest || []);
    res.json({ hasData:true, studentName:student.name, studentDepartment:student.department, analysis, generatedAt:new Date() });
  } catch(e) { console.error('ML error:', e); res.status(500).json({ error:'Server error during ML analysis' }); }
});

module.exports = router;
