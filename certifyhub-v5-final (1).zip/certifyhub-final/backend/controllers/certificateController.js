const Certificate = require('../models/Certificate');
const User = require('../models/User');
const nlpService = require('../utils/nlpService');
const verificationService = require('../utils/verificationService');
const path = require('path');
const fs = require('fs');

// @desc    Upload certificate
// @route   POST /api/certificates
// @access  Private (Student)
exports.uploadCertificate = async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({
        success: false,
        message: 'Please upload a certificate file'
      });
    }

    const { title, description, issueDate, certificateId, issuer, qrCodeData } = req.body;

    // Validate required fields
    if (!title || !description || !issueDate) {
      // Delete uploaded file if validation fails
      fs.unlinkSync(req.file.path);
      return res.status(400).json({
        success: false,
        message: 'Please provide title, description, and issue date'
      });
    }

    // Extract keywords and categorize using NLP
    const keywords = nlpService.extractKeywords(`${title} ${description}`);
    const category = nlpService.categorize(title, description);

    // Auto-verify if verification data provided
    let verificationResult = { isVerified: false, method: 'Not Verified' };
    if ((certificateId || qrCodeData) && issuer && issuer !== 'Other') {
      verificationResult = await verificationService.autoVerify({
        issuer,
        certificateId,
        qrCodeData
      });
    }

    // Create certificate
    const certificate = await Certificate.create({
      student: req.user.id,
      title,
      description,
      issueDate: new Date(issueDate),
      fileName: req.file.filename,
      filePath: req.file.path,
      fileType: path.extname(req.file.filename).substring(1).toLowerCase(),
      certificateId: certificateId || undefined,
      issuer: issuer || 'Other',
      qrCodeData: qrCodeData || undefined,
      isVerified: verificationResult.isVerified,
      verificationMethod: verificationResult.method,
      verificationDate: verificationResult.verificationDate || undefined,
      keywords,
      category
    });

    // Populate student info
    await certificate.populate('student', 'name rollNumber department');

    // Send real-time notification to all teachers (handled by socket.io in server.js)
    const io = req.app.get('io');
    if (io) {
      const teachers = await User.find({ role: 'teacher', isApproved: true });
      
      for (const teacher of teachers) {
        // Add notification to teacher's notifications array
        teacher.notifications.push({
          message: `${req.user.name} uploaded a new certificate: ${title}`,
          certificateId: certificate._id,
          studentId: req.user.id,
          studentName: req.user.name
        });
        await teacher.save();

        // Emit socket event
        io.to(`user_${teacher._id}`).emit('newCertificate', {
          message: `${req.user.name} uploaded a new certificate: ${title}`,
          certificate: certificate,
          student: {
            id: req.user.id,
            name: req.user.name,
            rollNumber: req.user.rollNumber
          }
        });
      }
    }

    res.status(201).json({
      success: true,
      message: 'Certificate uploaded successfully',
      certificate
    });
  } catch (error) {
    console.error('Upload error:', error);
    // Delete file if database operation fails
    if (req.file && fs.existsSync(req.file.path)) {
      fs.unlinkSync(req.file.path);
    }
    res.status(500).json({
      success: false,
      message: error.message || 'Failed to upload certificate'
    });
  }
};

// @desc    Get all certificates for student (own)
// @route   GET /api/certificates
// @access  Private (Student)
exports.getMyCertificates = async (req, res) => {
  try {
    const certificates = await Certificate.find({ student: req.user.id })
      .sort({ issueDate: -1 })
      .populate('student', 'name rollNumber department');

    res.status(200).json({
      success: true,
      count: certificates.length,
      certificates
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Failed to fetch certificates'
    });
  }
};

// @desc    Get single certificate
// @route   GET /api/certificates/:id
// @access  Private
exports.getCertificate = async (req, res) => {
  try {
    const certificate = await Certificate.findById(req.params.id)
      .populate('student', 'name rollNumber department email')
      .populate('verifiedBy', 'name role');

    if (!certificate) {
      return res.status(404).json({
        success: false,
        message: 'Certificate not found'
      });
    }

    // Authorization check
    if (req.user.role === 'student' && certificate.student._id.toString() !== req.user.id) {
      return res.status(403).json({
        success: false,
        message: 'Not authorized to view this certificate'
      });
    }

    res.status(200).json({
      success: true,
      certificate
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Failed to fetch certificate'
    });
  }
};

// @desc    Download certificate file
// @route   GET /api/certificates/:id/download
// @access  Private
exports.downloadCertificate = async (req, res) => {
  try {
    const certificate = await Certificate.findById(req.params.id);

    if (!certificate) {
      return res.status(404).json({
        success: false,
        message: 'Certificate not found'
      });
    }

    // Authorization check
    if (req.user.role === 'student' && certificate.student.toString() !== req.user.id) {
      return res.status(403).json({
        success: false,
        message: 'Not authorized to download this certificate'
      });
    }

    // Check if file exists
    if (!fs.existsSync(certificate.filePath)) {
      return res.status(404).json({
        success: false,
        message: 'Certificate file not found'
      });
    }

    // Send file
    res.download(certificate.filePath, certificate.fileName);
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Failed to download certificate'
    });
  }
};

// @desc    Delete certificate
// @route   DELETE /api/certificates/:id
// @access  Private (Student - own, Admin - any)
exports.deleteCertificate = async (req, res) => {
  try {
    const certificate = await Certificate.findById(req.params.id);

    if (!certificate) {
      return res.status(404).json({
        success: false,
        message: 'Certificate not found'
      });
    }

    // Authorization check
    if (req.user.role === 'student' && certificate.student.toString() !== req.user.id) {
      return res.status(403).json({
        success: false,
        message: 'Not authorized to delete this certificate'
      });
    }

    // Delete file
    if (fs.existsSync(certificate.filePath)) {
      fs.unlinkSync(certificate.filePath);
    }

    // Delete from database
    await certificate.deleteOne();

    res.status(200).json({
      success: true,
      message: 'Certificate deleted successfully'
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Failed to delete certificate'
    });
  }
};

// @desc    Search certificates using NLP
// @route   GET /api/certificates/search
// @access  Private (Teacher, Admin)
exports.searchCertificates = async (req, res) => {
  try {
    const { query, year, verified, studentId } = req.query;

    let filter = {};

    // Filter by student (if provided)
    if (studentId) {
      filter.student = studentId;
    }

    // Filter by year
    if (year) {
      const startDate = new Date(`${year}-01-01`);
      const endDate = new Date(`${year}-12-31`);
      filter.issueDate = { $gte: startDate, $lte: endDate };
    }

    // Filter by verification status
    if (verified === 'verified') {
      filter.isVerified = true;
    } else if (verified === 'unverified') {
      filter.isVerified = false;
    }

    // Get certificates
    let certificates = await Certificate.find(filter)
      .populate('student', 'name rollNumber department email')
      .populate('verifiedBy', 'name role')
      .sort({ issueDate: -1 });

    // Apply NLP search if query provided
    if (query && query.trim()) {
      certificates = nlpService.searchCertificates(certificates, query);
    }

    res.status(200).json({
      success: true,
      count: certificates.length,
      certificates
    });
  } catch (error) {
    console.error('Search error:', error);
    res.status(500).json({
      success: false,
      message: 'Search failed'
    });
  }
};

// @desc    Get certificates by student
// @route   GET /api/certificates/student/:studentId
// @access  Private (Teacher, Admin)
exports.getCertificatesByStudent = async (req, res) => {
  try {
    const certificates = await Certificate.find({ student: req.params.studentId })
      .sort({ issueDate: -1 })
      .populate('student', 'name rollNumber department email');

    res.status(200).json({
      success: true,
      count: certificates.length,
      certificates
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Failed to fetch certificates'
    });
  }
};

// @desc    Manually verify certificate
// @route   PUT /api/certificates/:id/verify
// @access  Private (Teacher, Admin)
exports.verifyCertificate = async (req, res) => {
  try {
    const certificate = await Certificate.findById(req.params.id);

    if (!certificate) {
      return res.status(404).json({
        success: false,
        message: 'Certificate not found'
      });
    }

    certificate.isVerified = true;
    certificate.verificationMethod = 'Manual';
    certificate.verificationDate = new Date();
    certificate.verifiedBy = req.user.id;

    await certificate.save();
    await certificate.populate('verifiedBy', 'name role');

    res.status(200).json({
      success: true,
      message: 'Certificate verified successfully',
      certificate
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Verification failed'
    });
  }
};

// @desc    Get search suggestions
// @route   GET /api/certificates/suggestions
// @access  Private (Teacher, Admin)
exports.getSearchSuggestions = async (req, res) => {
  try {
    const certificates = await Certificate.find({});
    const suggestions = nlpService.getSearchSuggestions(certificates);

    res.status(200).json({
      success: true,
      suggestions
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Failed to get suggestions'
    });
  }
};
