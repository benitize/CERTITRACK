const User = require('../models/User');
const Certificate = require('../models/Certificate');
const fs = require('fs');

// @desc    Get dashboard statistics
// @route   GET /api/admin/stats
// @access  Private (Admin)
exports.getDashboardStats = async (req, res) => {
  try {
    const approvedStudents = await User.countDocuments({ role: 'student', isApproved: true });
    const approvedTeachers = await User.countDocuments({ role: 'teacher', isApproved: true });
    const pendingStudents = await User.countDocuments({ role: 'student', isApproved: false });
    const pendingTeachers = await User.countDocuments({ role: 'teacher', isApproved: false });
    const totalCertificates = await Certificate.countDocuments({});
    const verifiedCertificates = await Certificate.countDocuments({ isVerified: true });

    // Recent activity (last 10 registrations and certificate uploads)
    const recentUsers = await User.find({})
      .sort({ createdAt: -1 })
      .limit(5)
      .select('name email role isApproved createdAt');

    const recentCertificates = await Certificate.find({})
      .sort({ uploadDate: -1 })
      .limit(5)
      .populate('student', 'name rollNumber')
      .select('title student uploadDate');

    res.status(200).json({
      success: true,
      stats: {
        approvedStudents,
        approvedTeachers,
        pendingApprovals: pendingStudents + pendingTeachers,
        pendingStudents,
        pendingTeachers,
        totalCertificates,
        verifiedCertificates
      },
      recentActivity: {
        users: recentUsers,
        certificates: recentCertificates
      }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Failed to fetch dashboard statistics'
    });
  }
};

// @desc    Get pending approvals (students and teachers)
// @route   GET /api/admin/pending
// @access  Private (Admin)
exports.getPendingApprovals = async (req, res) => {
  try {
    const pendingStudents = await User.find({ role: 'student', isApproved: false })
      .sort({ createdAt: -1 })
      .select('name email rollNumber department createdAt');

    const pendingTeachers = await User.find({ role: 'teacher', isApproved: false })
      .sort({ createdAt: -1 })
      .select('name email subject createdAt');

    res.status(200).json({
      success: true,
      pending: {
        students: pendingStudents,
        teachers: pendingTeachers,
        total: pendingStudents.length + pendingTeachers.length
      }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Failed to fetch pending approvals'
    });
  }
};

// @desc    Approve user
// @route   PUT /api/admin/approve/:userId
// @access  Private (Admin)
exports.approveUser = async (req, res) => {
  try {
    const user = await User.findById(req.params.userId);

    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found'
      });
    }

    if (user.isApproved) {
      return res.status(400).json({
        success: false,
        message: 'User is already approved'
      });
    }

    user.isApproved = true;
    await user.save();

    res.status(200).json({
      success: true,
      message: `${user.role.charAt(0).toUpperCase() + user.role.slice(1)} approved successfully`,
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        role: user.role,
        isApproved: user.isApproved
      }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Failed to approve user'
    });
  }
};

// @desc    Reject user
// @route   DELETE /api/admin/reject/:userId
// @access  Private (Admin)
exports.rejectUser = async (req, res) => {
  try {
    const user = await User.findById(req.params.userId);

    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found'
      });
    }

    if (user.role === 'admin') {
      return res.status(403).json({
        success: false,
        message: 'Cannot reject admin users'
      });
    }

    await user.deleteOne();

    res.status(200).json({
      success: true,
      message: 'User rejected and deleted successfully'
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Failed to reject user'
    });
  }
};

// @desc    Get all users with certificate counts
// @route   GET /api/admin/users
// @access  Private (Admin)
exports.getAllUsers = async (req, res) => {
  try {
    const { role } = req.query;

    let filter = { role: { $ne: 'admin' } };
    if (role && role !== 'all') {
      filter.role = role;
    }

    const users = await User.find(filter)
      .sort({ createdAt: -1 })
      .select('-password');

    // Get certificate counts for students
    const usersWithCounts = await Promise.all(
      users.map(async (user) => {
        const userObj = user.toObject();
        if (user.role === 'student') {
          const certCount = await Certificate.countDocuments({ student: user._id });
          userObj.certificateCount = certCount;
        }
        return userObj;
      })
    );

    res.status(200).json({
      success: true,
      count: usersWithCounts.length,
      users: usersWithCounts
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Failed to fetch users'
    });
  }
};

// @desc    Delete user
// @route   DELETE /api/admin/users/:userId
// @access  Private (Admin)
exports.deleteUser = async (req, res) => {
  try {
    const user = await User.findById(req.params.userId);

    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found'
      });
    }

    if (user.role === 'admin') {
      return res.status(403).json({
        success: false,
        message: 'Cannot delete admin users'
      });
    }

    // If student, delete their certificates and files
    if (user.role === 'student') {
      const certificates = await Certificate.find({ student: user._id });
      
      // Delete certificate files
      for (const cert of certificates) {
        if (fs.existsSync(cert.filePath)) {
          fs.unlinkSync(cert.filePath);
        }
      }

      // Delete certificates from database
      await Certificate.deleteMany({ student: user._id });
    }

    await user.deleteOne();

    res.status(200).json({
      success: true,
      message: 'User deleted successfully'
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Failed to delete user'
    });
  }
};

// @desc    Get all certificates with student info
// @route   GET /api/admin/certificates
// @access  Private (Admin)
exports.getAllCertificates = async (req, res) => {
  try {
    const { studentId } = req.query;

    let filter = {};
    if (studentId) {
      filter.student = studentId;
    }

    const certificates = await Certificate.find(filter)
      .populate('student', 'name email rollNumber department')
      .populate('verifiedBy', 'name role')
      .sort({ uploadDate: -1 });

    res.status(200).json({
      success: true,
      count: certificates.length,
      certificates
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Failed to fetch certificates'
    });
  }
};

// @desc    Get all students (for student list view)
// @route   GET /api/admin/students
// @access  Private (Admin, Teacher)
exports.getStudents = async (req, res) => {
  try {
    const students = await User.find({ role: 'student', isApproved: true })
      .sort({ name: 1 })
      .select('name email rollNumber department');

    // Add certificate counts
    const studentsWithCounts = await Promise.all(
      students.map(async (student) => {
        const certCount = await Certificate.countDocuments({ student: student._id });
        return {
          ...student.toObject(),
          certificateCount: certCount
        };
      })
    );

    res.status(200).json({
      success: true,
      count: studentsWithCounts.length,
      students: studentsWithCounts
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Failed to fetch students'
    });
  }
};
