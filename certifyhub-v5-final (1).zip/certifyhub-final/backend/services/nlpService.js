const natural = require('natural');
const compromise = require('compromise');

// Initialize tokenizer and TF-IDF
const tokenizer = new natural.WordTokenizer();
const TfIdf = natural.TfIdf;

// Category keywords
const categoryKeywords = {
  Backend: ['java', 'python', 'node', 'nodejs', 'spring', 'django', 'flask', 'express', 'api', 'rest', 'graphql', 'backend', 'server', 'ruby', 'php', 'laravel', 'dotnet', 'asp.net'],
  Frontend: ['react', 'angular', 'vue', 'html', 'css', 'javascript', 'typescript', 'frontend', 'ui', 'ux', 'bootstrap', 'tailwind', 'sass', 'webpack', 'nextjs', 'next.js'],
  Database: ['sql', 'mysql', 'postgresql', 'mongodb', 'database', 'redis', 'cassandra', 'oracle', 'sqlite', 'mariadb', 'dynamodb', 'firestore'],
  Cloud: ['aws', 'azure', 'cloud', 'docker', 'kubernetes', 'k8s', 'devops', 'gcp', 'google cloud', 'heroku', 'terraform', 'jenkins', 'ci/cd'],
  'AI/ML': ['machine learning', 'ml', 'deep learning', 'ai', 'artificial intelligence', 'neural network', 'tensorflow', 'pytorch', 'data science', 'nlp', 'computer vision', 'scikit'],
  Mobile: ['android', 'ios', 'flutter', 'react native', 'mobile', 'app development', 'swift', 'kotlin', 'xamarin'],
  Programming: ['programming', 'coding', 'algorithm', 'data structure', 'dsa', 'competitive', 'leetcode', 'hackerrank', 'c++', 'cpp', 'c', 'rust', 'go', 'golang']
};

// Skill level keywords
const skillLevelKeywords = {
  Beginner: ['beginner', 'introduction', 'intro', 'basic', 'fundamentals', 'getting started', 'starter', '101'],
  Intermediate: ['intermediate', 'advanced beginner', 'practical', 'hands-on', 'real-world'],
  Advanced: ['advanced', 'expert', 'professional', 'master', 'senior', 'architect', 'specialist', 'deep dive']
};

// Extract keywords from text
function extractKeywords(text) {
  const lowerText = text.toLowerCase();
  const tokens = tokenizer.tokenize(lowerText);
  
  // Use compromise for better NLP
  const doc = compromise(text);
  const nouns = doc.nouns().out('array');
  const verbs = doc.verbs().out('array');
  
  // Combine tokens, nouns, and verbs
  const allKeywords = [...new Set([...tokens, ...nouns, ...verbs])];
  
  return allKeywords.filter(word => word.length > 2);
}

// Categorize certificate based on title and description
function categorizeCertificate(title, description) {
  const combinedText = `${title} ${description}`.toLowerCase();
  
  let bestCategory = 'Other';
  let maxScore = 0;
  
  for (const [category, keywords] of Object.entries(categoryKeywords)) {
    let score = 0;
    for (const keyword of keywords) {
      if (combinedText.includes(keyword)) {
        score += 1;
      }
    }
    
    if (score > maxScore) {
      maxScore = score;
      bestCategory = category;
    }
  }
  
  return bestCategory;
}

// Determine skill level
function determineSkillLevel(title, description) {
  const combinedText = `${title} ${description}`.toLowerCase();
  
  for (const [level, keywords] of Object.entries(skillLevelKeywords)) {
    for (const keyword of keywords) {
      if (combinedText.includes(keyword)) {
        return level;
      }
    }
  }
  
  return 'Beginner'; // Default
}

// Search certificates using NLP
function searchCertificates(certificates, query) {
  if (!query || query.trim() === '') {
    return certificates;
  }
  
  const queryLower = query.toLowerCase();
  const queryKeywords = extractKeywords(query);
  
  // Score each certificate
  const scoredCerts = certificates.map(cert => {
    let score = 0;
    const certText = `${cert.title} ${cert.description}`.toLowerCase();
    
    // Exact phrase match (highest priority)
    if (certText.includes(queryLower)) {
      score += 10;
    }
    
    // Keyword matching
    for (const keyword of queryKeywords) {
      if (certText.includes(keyword)) {
        score += 2;
      }
    }
    
    // Category match
    if (cert.category && queryLower.includes(cert.category.toLowerCase())) {
      score += 5;
    }
    
    // Keywords array match
    if (cert.keywords && cert.keywords.length > 0) {
      for (const certKeyword of cert.keywords) {
        if (queryKeywords.includes(certKeyword.toLowerCase())) {
          score += 3;
        }
      }
    }
    
    return { ...cert._doc || cert, score };
  });
  
  // Filter and sort by score
  return scoredCerts
    .filter(cert => cert.score > 0)
    .sort((a, b) => b.score - a.score)
    .map(cert => {
      const { score, ...certData } = cert;
      return certData;
    });
}

// Generate search suggestions
function generateSuggestions(query) {
  const suggestions = [];
  const queryLower = query.toLowerCase();
  
  // Category suggestions
  for (const category of Object.keys(categoryKeywords)) {
    if (category.toLowerCase().includes(queryLower)) {
      suggestions.push(category);
    }
  }
  
  // Common search terms
  const commonTerms = ['internship', 'course', 'certification', 'bootcamp', 'workshop', 'training'];
  for (const term of commonTerms) {
    if (term.includes(queryLower)) {
      suggestions.push(term);
    }
  }
  
  return suggestions.slice(0, 5);
}

module.exports = {
  extractKeywords,
  categorizeCertificate,
  determineSkillLevel,
  searchCertificates,
  generateSuggestions
};
