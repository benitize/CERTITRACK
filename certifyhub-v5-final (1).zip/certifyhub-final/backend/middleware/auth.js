const jwt = require('jsonwebtoken');
const User = require('../models/User');

// Verify JWT token
const auth = async (req, res, next) => {
  try {
    const token = req.header('Authorization')?.replace('Bearer ', '');
    
    if (!token) {
      return res.status(401).json({ error: 'No authentication token provided' });
    }

    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const user = await User.findById(decoded.userId);

    if (!user) {
      return res.status(401).json({ error: 'User not found' });
    }

    // Check if user is approved (except admins)
    if (user.role !== 'admin' && !user.isApproved) {
      return res.status(403).json({ error: 'Your account is pending approval' });
    }

    req.user = user;
    req.userId = user._id;
    req.userRole = user.role;
    next();
  } catch (error) {
    res.status(401).json({ error: 'Invalid or expired token' });
  }
};

// Role-based middleware
const authorize = (...roles) => {
  return (req, res, next) => {
    if (!req.user) {
      return res.status(401).json({ error: 'Unauthorized' });
    }

    if (!roles.includes(req.userRole)) {
      return res.status(403).json({ 
        error: `Access denied. Required roles: ${roles.join(', ')}` 
      });
    }

    next();
  };
};

// Admin only
const adminOnly = authorize('admin');

// Teacher or Admin
const teacherOrAdmin = authorize('teacher', 'admin');

// Student only
const studentOnly = authorize('student');

// Any authenticated user
const anyUser = auth;

module.exports = {
  auth,
  authorize,
  adminOnly,
  teacherOrAdmin,
  studentOnly,
  anyUser
};
