const mongoose = require('mongoose');
const bcrypt   = require('bcryptjs');

const userSchema = new mongoose.Schema({
  name:     { type: String, required: true, trim: true },
  email:    { type: String, required: true, unique: true, lowercase: true, trim: true },
  password: { type: String, required: true },
  role:     { type: String, enum: ['admin', 'teacher', 'student'], required: true },

  /* ── Student fields ── */
  rollNumber:       { type: String, sparse: true },
  department:       { type: String, trim: true },   // student's dept  e.g. "IT"
  areasOfInterest:  { type: [String], default: [] }, // e.g. ['AI/ML','Cloud']

  /* ── Teacher fields ──
     'department' stores the teacher's dept (same field name as students so one
     query works for both: teacher.department === student.department)
     'subject'    kept for backward-compat, holds dept label entered at register  */
  subject:          { type: String, trim: true },   // kept for BC

  /* Approval */
  isApproved: { type: Boolean, default: false },

  /* Notifications */
  notifications: [{
    message:       String,
    certificateId: { type: mongoose.Schema.Types.ObjectId, ref: 'Certificate' },
    studentName:   String,
    isRead:        { type: Boolean, default: false },
    createdAt:     { type: Date, default: Date.now }
  }],

  registeredAt: { type: Date, default: Date.now }
}, { timestamps: true });

/* Password hashing hook */
userSchema.pre('save', async function(next) {
  if (!this.isModified('password')) return next();
  if (this.password && !this.password.startsWith('$2')) {
    this.password = await bcrypt.hash(this.password, 10);
  }
  next();
});

userSchema.methods.matchPassword = async function(entered) {
  return bcrypt.compare(entered, this.password);
};

/* For teachers: department is stored in `subject` at register time.
   We copy it to `department` so the dept-match logic is uniform. */
userSchema.pre('save', function(next) {
  if (this.role === 'teacher' && this.subject && !this.department) {
    this.department = this.subject;
  }
  next();
});

userSchema.index({ email: 1 });
userSchema.index({ role: 1, isApproved: 1 });
userSchema.index({ department: 1 });

module.exports = mongoose.model('User', userSchema);
